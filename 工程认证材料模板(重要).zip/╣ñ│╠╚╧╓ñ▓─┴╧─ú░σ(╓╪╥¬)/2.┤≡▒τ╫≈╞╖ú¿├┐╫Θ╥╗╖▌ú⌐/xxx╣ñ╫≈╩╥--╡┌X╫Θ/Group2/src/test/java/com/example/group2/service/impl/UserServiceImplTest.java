package com.example.group2.service.impl;

import com.example.group2.pojo.User;
import com.example.group2.service.UserService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.*;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;


public class UserServiceImplTest {

    @Autowired
    private UserService userService;

    @Test
    void userRegister() {
    }

    @Test
    void userLogin() {
        User user=new User();
        //user.setUsername("1234561122");
        user.setUsername("12345611220");
        //user.setPassword("123456");
        user.setPassword("1234560");
        //System.out.println(userService.userLogin(user));
    }

    @Test
    void testUserLogin() {
        User user=new User();
        user.setPhone("18279520615");
       // System.out.println(userService.userLogin(user,""));
        String s="C:\\Users\\zwl\\Desktop\\作业\\工作室\\builderms\\Group2C:\\Users\\zwl123456";
        System.out.println(Arrays.toString(s.split("C:\\\\Users\\\\zwl",3)));
    }

    @Test
    void tee() throws IOException {
        Map<String,Integer> map=new HashMap<>();
        BufferedReader in= new BufferedReader(new FileReader("C:\\Users\\zwl\\Downloads\\wc.txt"));
        String line;
        while ((line=in.readLine())!=null){
            String []s=line.split(",");
            for (String sss:s){
                if (map.containsKey(sss)) {
                    map.put(sss, map.get(sss)+1);
                } else {
                    map.put(sss, 1);
                }
            }
        }
        Arrays.sort(map.values().toArray());
        System.out.println(map);
    }





}