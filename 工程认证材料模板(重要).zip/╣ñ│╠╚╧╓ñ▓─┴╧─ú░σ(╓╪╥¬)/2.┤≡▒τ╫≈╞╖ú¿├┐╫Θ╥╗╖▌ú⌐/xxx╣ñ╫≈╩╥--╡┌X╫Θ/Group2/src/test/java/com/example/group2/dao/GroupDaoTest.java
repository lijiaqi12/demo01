package com.example.group2.dao;

import com.example.group2.pojo.Group;
import com.example.group2.pojo.User;
import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.BlobTypeHandler;
import org.apache.ibatis.type.JdbcType;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.Blob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@RunWith(SpringRunner.class)
@SpringBootTest
public class GroupDaoTest {

    @Autowired
    private GroupDao groupDao;
    @Test
    void update() throws IOException, ClassNotFoundException {
        Group group=new Group();
        group.setId(2);
        group.dataToBytes(new Group.Data(new User(1),new Group.Data.Power(true,false)));
        groupDao.updateData(group);

    }

    @Test
    void select() throws IOException, ClassNotFoundException {
        Group group=new Group();
        group.setId(20);
        group=groupDao.select(group);
        //Group.Data data=Group.bytesToData(group.getData());
        System.out.println(group);
    }

    @Test
    void selectByFounderId() {

        User user= new User(1);
        List<Group> group=groupDao.selectByFounderId(new Group(user));
        System.out.println(group);


    }
    @Test
    void addGroup() throws IOException {
        /*Group group=new Group();
        User user=new User(1);
        group.setFounder(user);
        Map<User, Group.Data.Power> map=new HashMap<>();
        map.put(user,new Group.Data.Power());
        group.dataToBytes(new Group.Data(map));
        //group.setData(new byte[]{'1', '2'});
        groupDao.addGroup(group);*/
    }


}