package com.example.group2.service.impl;

import com.example.group2.service.HadoopService;
import org.apache.hadoop.fs.LocatedFileStatus;
import org.apache.hadoop.fs.Path;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
public class HadoopServiceImplTest {

    @Autowired
    private HadoopService hadoopService;
    @Test
    void select() throws IOException {
        /*List<HadoopServiceImpl.FileStatusUtil> fs=hadoopService.select("/jxnuss/private/1", "1");
        System.out.println("ddd");*/
    }
    @Test
    void exit() throws IOException {
        HadoopServiceImpl hadoopService=new HadoopServiceImpl();
        System.out.println(hadoopService.getFileSystem().exists(new Path("/jxnuss/private/1/新建文件夹1/新建文本文档.txt")));
    }

    @Test
    void exddit() throws IOException {
       String s =hadoopService.readKey("/jxnuss/key/private/pri.pem");
    System.out.println(s);

    }


}