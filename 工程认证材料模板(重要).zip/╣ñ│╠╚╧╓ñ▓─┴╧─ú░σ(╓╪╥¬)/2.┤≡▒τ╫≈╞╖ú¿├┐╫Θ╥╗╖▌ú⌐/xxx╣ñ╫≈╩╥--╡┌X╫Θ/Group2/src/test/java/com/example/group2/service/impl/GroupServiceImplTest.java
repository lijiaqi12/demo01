package com.example.group2.service.impl;

import com.example.group2.pojo.Group;
import com.example.group2.pojo.User;
import com.example.group2.service.GroupService;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;
@RunWith(SpringRunner.class)
@SpringBootTest
public class GroupServiceImplTest {

    @Autowired
    private GroupService groupService;
    @Test
    void createGroup() {
        //groupService.createGroup(new User(5));
    }

    @Test
    void joinGroup() throws IOException, ClassNotFoundException {
        groupService.joinGroup(new Group(30),new User(10),new Group.Data.Power(false,true));
    }

    @Test
    void setPower() {
    }
    @Test
    void getGroupMember() throws IOException, ClassNotFoundException {
        Group group=new Group(4);
        System.out.println(groupService.getGroupMember(group));
    }
    @Test
    void findJoinedGroup(){
        User user=new User(5);
        System.out.println(groupService.findJoinedGroup(user));;
    }
    @Test
    void findMyGroup(){
        User user=new User(1);
        System.out.println(groupService.findMyGroup(user));;
    }
}