package com.example.group2.dao;

import com.example.group2.pojo.Sign;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.mapping.FetchType;

import java.util.List;

@Mapper
public interface SignDao {
    @Select("SELECT * FROM `sign` WHERE id=#{id}")
    @Result(column = "initiate_group_id", property = "group", one = @One(select = "com.example.group2.dao.GroupDao.select", fetchType = FetchType.EAGER))
    public Sign select(Sign sign);

    @Select("SELECT * FROM `sign` WHERE initiate_group_id=#{group.id}")
    @Result(column = "initiate_group_id", property = "group", one = @One(select = "com.example.group2.dao.GroupDao.select", fetchType = FetchType.EAGER))
    public List<Sign> selectGroupAllSignInfo(Sign sign);

    @Insert("INSERT INTO `sign` (initiate_group_id,`data`,end_time)VALUES(#{group.id},#{data,typeHandler=org.apache.ibatis.type.BlobTypeHandler},#{endTime})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    public void addSignInfo(Sign sign);

    @Update("UPDATE `sign` SET `data`= #{data} WHERE id= #{id}")
    public void updateSignInfo(Sign sign);
}
