package com.example.group2.service;

import com.example.group2.pojo.User;


public interface UserService {
    /**
     * 用户注册
     *
     * @param user 用户注册信息
     * @author zwl
     * @date 2021/8/16
     **/
    public void userRegister(User user);

    /**
     * 通过用户名密码登录
     *
     * @return user   用户数据
     * @author zwl
     * @date 2021/8/14 10:56
     * @Param: user  用户输入的用户名和密码封装
     * @Param: code  用户输入的验证码
     * @Param: request  请求数据，用于验证码校验
     */
    public User login(User user);

    /**
     * 通过手机或邮箱登录
     *
     * @return user  用户数据
     * @author zwl
     * @date 2021/8/14 10:57
     * @Param: user  用户手机号或邮箱封装
     * @Param: code  用户输入的验证码
     */
    public User fastLogin(User user, String code);

    public User getUserData(User user);

    public void resetPassword(User user, String code);

    /**
     * @author zwl
     * @date 2021/8/15 10:05
     * @Param: user
     * @Param: username 用户名
     * @Param: password  原密码
     * @Param: newPwd  新密码
     */
    public void alterPassword(User user, String newPwd);

    public void updateHeadImage(User user);

    public void updateUserInfo(User user);


}
