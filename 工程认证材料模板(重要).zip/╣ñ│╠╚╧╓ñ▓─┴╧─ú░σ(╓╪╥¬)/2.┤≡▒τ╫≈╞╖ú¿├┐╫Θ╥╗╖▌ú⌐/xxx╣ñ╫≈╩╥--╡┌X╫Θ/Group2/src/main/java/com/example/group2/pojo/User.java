package com.example.group2.pojo;


import com.example.group2.pojo.check.EmailCheck;
import com.example.group2.pojo.check.PasswordCheck;
import com.example.group2.pojo.check.PhoneCheck;
import com.example.group2.pojo.check.UsernameCheck;
import com.fasterxml.jackson.annotation.JsonFormat;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

public class User implements Serializable {
    private static final long serialVersionUID=123456789123L;
    //用户Id
    private int id;
    //用户名
    @NotBlank(message = "请输入用户名!", groups = {UsernameCheck.class})
    @Pattern(regexp = "^.{6,12}$", message = "用户名长度应为6-12位", groups = {UsernameCheck.class})
    private String username;
    //密码
    @NotBlank(message = "请输入密码!", groups = {PasswordCheck.class})
    @Pattern(regexp = "^.{6,18}$", message = "密码长度应为6-18位", groups = {PasswordCheck.class})
    private String password;
    //手机号
    @NotBlank(message = "请输入手机号", groups = {PhoneCheck.class})
    @Pattern(regexp = "^(13[0-9]|14[579]|15[0-3,5-9]|16[6]|17[0135678]|18[0-9]|19[89])\\d{8}$", message = "手机号码格式不正确！", groups = {PhoneCheck.class})
    private String phone;
    //邮箱
    @NotBlank(message = "请输入邮箱", groups = {EmailCheck.class})
    @Email(message = "邮箱格式错误", groups = {EmailCheck.class})
    private String email;

    //昵称
    private String nickname;
    //头像
    private String headImage;
    //注册时间
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date regTime;
    //修改时间
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date updateTime;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getRegTime() {
        return regTime;
    }

    public void setRegTime(Date regTime) {
        this.regTime = regTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Date getTime(){
        return new Date();
    }
    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getHeadImage() {
        return headImage;
    }

    public void setHeadImage(String headImage) {
        this.headImage = headImage;
    }

    public User() {
    }

    public User(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", phone='" + phone + '\'' +
                ", email='" + email + '\'' +
                ", nickname='" + nickname + '\'' +
                ", headImage='" + headImage + '\'' +
                ", regTime=" + regTime +
                ", updateTime=" + updateTime +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return id == user.id || (username!=null&&Objects.equals(username, user.username)) || (phone!=null&&Objects.equals(phone, user.phone)) || (email!=null&&Objects.equals(email, user.email));
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
