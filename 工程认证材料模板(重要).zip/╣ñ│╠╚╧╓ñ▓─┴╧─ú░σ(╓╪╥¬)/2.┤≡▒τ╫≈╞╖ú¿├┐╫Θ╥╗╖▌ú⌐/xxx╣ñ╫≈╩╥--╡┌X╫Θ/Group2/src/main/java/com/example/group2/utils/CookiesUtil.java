package com.example.group2.utils;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

public class CookiesUtil {
    public static Cookie CreateCookie(String key, String value, int age) {//创建token cookies
        Cookie cookie = new Cookie(key, value);
        cookie.setPath("/");
        cookie.setDomain("localhost");
        cookie.setSecure(true);
        cookie.setMaxAge(age);
        return cookie;
    }

    public static Cookie[] DeleteCookie(String... keys) {//清空cookies
        Cookie[] cookies = new Cookie[keys.length];
        for (int i = 0; i < keys.length; i++) {
            cookies[i] = new Cookie(keys[i], null);
            cookies[i].setPath("/");
            cookies[i].setMaxAge(0);
        }
        return cookies;
    }

    public static String getToken(HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        for (Cookie cookie : cookies) {
            if (cookie.getName().equals("token")) {
                return cookie.getValue();
            }
        }
        return null;
    }
}
