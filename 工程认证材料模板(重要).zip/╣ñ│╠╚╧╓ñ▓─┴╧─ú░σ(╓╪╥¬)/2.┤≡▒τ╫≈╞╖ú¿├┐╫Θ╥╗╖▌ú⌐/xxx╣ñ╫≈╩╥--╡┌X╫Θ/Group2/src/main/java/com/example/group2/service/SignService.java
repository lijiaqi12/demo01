package com.example.group2.service;

import com.example.group2.pojo.Sign;
import com.example.group2.pojo.User;

import java.util.Date;
import java.util.List;
import java.util.Map;

public interface SignService {
    public Sign getSignInfo(Sign sign);
    public void createSignInfo(Sign sign,User user);
    public void sign(Sign sign,User user);
    public List<Sign> getGroupAllSignInfo(Sign sign);
    public Map<User, Date> getFriendsSignInfo(Sign sign);
    public int getUserSignInfo(Sign sign,User user);
    public Map<Sign,Integer> getUserAllSignInfo(User user);
}
