package com.example.group2.pojo;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.io.*;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Sign {
    private int id;
    private Group group;
    private byte[] data;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date startTime;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date endTime;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date updateTime;

    public Sign() {
    }

    public Sign(int id) {
        this.id=id;
    }

    public Sign(Group group) {
        this.group = group;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Group getGroup() {
        return group;
    }

    public void setGroup(Group group) {
        this.group = group;
    }

    public byte[] getData() {
        return data;
    }


    public void setData(byte[] data) {
        this.data = data;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }


    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        return "Sign{" +
                "id=" + id +
                ", group=" + group +
                ", data=" + Arrays.toString(data) +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                ", updateTime=" + updateTime +
                '}';
    }

    public void dataToBytes(Data data) {
    /*关键步骤：将对象变成二进制数组。使用对象输出流将对象
   	写入ByteArrayOutputStream里再使用toByteArry()变成byte数组 */
        ByteArrayOutputStream byt = new ByteArrayOutputStream();
        ObjectOutputStream obj = null;
        try {
            obj = new ObjectOutputStream(byt);
            obj.writeObject(data);
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.data = byt.toByteArray();
    }

    public  Data bytesToData(byte[] bytes) {
        ByteArrayInputStream in = new ByteArrayInputStream(bytes);
        ObjectInputStream sIn = null;
        try {
            sIn = new ObjectInputStream(in);
            return (Data) sIn.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return new Data();
        }
    }

    public static class Data implements Serializable{
        private Map<User, Date> map = new HashMap<>();

        public Data() {
        }

        public Data(Map<User, Date> map) {
            this.map = map;
        }
        public Data(User user,Date date) {
            map=new HashMap<>();
            map.put(user,date);
        }
        public Map<User, Date> getMap() {
            return map;
        }

        public void setMap(Map<User, Date> map) {
            this.map = map;
        }
    }

}
