package com.example.group2.pojo;


import com.fasterxml.jackson.annotation.JsonFormat;

import java.io.*;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Group implements Serializable {
    private int id;
    private String name;
    private String code;
    private User founder;
    private byte[] data;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date regTime;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date updateTime;

    public Group(int id) {
        this.id = id;
    }

    public Group(User founder) {
        this.founder = founder;
    }

    public Group() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public User getFounder() {
        return founder;
    }

    public void setFounder(User founder) {
        this.founder = founder;
    }

    public byte[] getData() {
        return data;
    }

    public void setData(byte[] data) {
        this.data = data;
    }

    public Date getRegTime() {
        return regTime;
    }

    public void setRegTime(Date regTime) {
        this.regTime = regTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void dataToBytes(Data data) {
    /*关键步骤：将对象变成二进制数组。使用对象输出流将对象
   	写入ByteArrayOutputStream里再使用toByteArry()变成byte数组 */
        ByteArrayOutputStream byt = new ByteArrayOutputStream();
        ObjectOutputStream obj = null;
        try {
            obj = new ObjectOutputStream(byt);
            obj.writeObject(data);
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.data = byt.toByteArray();
    }

    public  Data bytesToData(byte[] bytes) {
        ByteArrayInputStream in = new ByteArrayInputStream(bytes);
        ObjectInputStream sIn = null;
        try {
            sIn = new ObjectInputStream(in);
            return (Data) sIn.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return new Data();
        }


    }

    @Override
    public String toString() {
        return "Group{" +
                "id=" + id +
                ", founder=" + founder +
                ", data=" + Arrays.toString(data) +
                ", regTime=" + regTime +
                ", updateTime=" + updateTime +
                '}';
    }

    public static class Data implements Serializable {
        //组员集合
        private Map<User, Power> map = new HashMap<>();

        public Data() {
        }

        public Data(Map<User, Power> map) {
            this.map = map;
        }

        public Data(User user, Power power) {
            map.put(user, power);
        }

        public Map<User, Power> getMap() {
            return map;
        }

        public void setMap(Map<User, Power> map) {
            this.map = map;
        }

        public static class Power implements Serializable {
            private static final long serialVersionUID = -123456789876543210L;
            //上传权限
            private boolean uploadPower = true;
            //下载权限
            private boolean downloadPower = true;
            //创建文件夹权限
            private boolean mkdirPower = false;
            //删除权限
            private boolean deletePower = false;
            //修改权限
            private boolean updatePower = false;

            public Power() {
            }

            public Power(boolean uploadPower, boolean downloadPower) {
                this.uploadPower = uploadPower;
                this.downloadPower = downloadPower;
            }

            public boolean isMkdirPower() {
                return mkdirPower;
            }

            public void setMkdirPower(boolean mkdirPower) {
                this.mkdirPower = mkdirPower;
            }

            public boolean isDeletePower() {
                return deletePower;
            }

            public void setDeletePower(boolean deletePower) {
                this.deletePower = deletePower;
            }

            public boolean isUpdatePower() {
                return updatePower;
            }

            public void setUpdatePower(boolean updatePower) {
                this.updatePower = updatePower;
            }

            public boolean isUploadPower() {
                return uploadPower;
            }

            public void setUploadPower(boolean uploadPower) {
                this.uploadPower = uploadPower;
            }

            public boolean isDownloadPower() {
                return downloadPower;
            }

            public void setDownloadPower(boolean downloadPower) {
                this.downloadPower = downloadPower;
            }
        }
    }
}
