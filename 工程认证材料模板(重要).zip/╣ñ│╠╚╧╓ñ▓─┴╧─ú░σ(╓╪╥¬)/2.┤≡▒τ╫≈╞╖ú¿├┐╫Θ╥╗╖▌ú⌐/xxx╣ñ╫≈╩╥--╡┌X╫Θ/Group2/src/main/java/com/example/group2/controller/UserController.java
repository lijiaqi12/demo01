package com.example.group2.controller;

import com.alibaba.fastjson.JSONObject;
import com.example.group2.handlerInterceptor.PassToken;
import com.example.group2.pojo.User;
import com.example.group2.pojo.check.EmailCheck;
import com.example.group2.pojo.check.PasswordCheck;
import com.example.group2.pojo.check.PhoneCheck;
import com.example.group2.pojo.check.UsernameCheck;
import com.example.group2.service.HadoopService;
import com.example.group2.service.UserService;
import com.example.group2.service.impl.HadoopServiceImpl;
import com.example.group2.utils.JwtToken;
import com.example.group2.utils.UUIDUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Controller
@CrossOrigin(origins = "${netDisk.web.path}", allowedHeaders = "*", allowCredentials = "true")
public class UserController {

    private UserService userService;
    private HadoopService hadoopService;

    @Autowired
    public void setUserService(UserService userService) {
        this.userService = userService;
    }

    @Autowired
    public void setHadoopService(HadoopService hadoopService) {
        this.hadoopService = hadoopService;
    }

    /**
     * 通过手机号重置（找回）密码
     * @param user  用户名、密码和手机号
     * @param result 参数未通过校验的结果集
     * @param rPwd  第二次输入的密码
     * @param code  验证码
     * @return com.alibaba.fastjson.JSONObject
     * @author zwl
     * @date 2021/8/22
     **/
    @RequestMapping(value = "/resetPasswordByPhone")
    @ResponseBody
    @PassToken
    public JSONObject resetPasswordByPhone(@Validated(value = {UsernameCheck.class, PhoneCheck.class, PasswordCheck.class}) User user, BindingResult result, @RequestParam(value = "tPassword") String rPwd, String code) {
        Map<String, Object> map = new HashMap<>();
        //如果有参数未通过校验，将其加入result中
        if (result.hasErrors()) {
            result.getAllErrors().forEach(v -> map.put("errMsg", map.containsKey("errMsg") ? map.get("errMsg") + " " + v.getDefaultMessage() : v.getDefaultMessage()));
        } else {
            //如果两次输入的密码不一致
            if (!user.getPassword().equals(rPwd)) {
                map.put("errMsg", "两次输入的密码不一致");
            } else {
                try {
                    //清空邮箱，防止干扰
                    user.setEmail(null);
                    //重置密码
                    userService.resetPassword(user, code);
                    map.put("code", 0);
                    map.put("message", "密码重置成功");
                } catch (RuntimeException e) {
                    map.put("errMsg", e.getMessage());
                }
            }
        }
        if (!map.containsKey("code")) {
            map.put("code", -1);
        }
        return new JSONObject(map);
    }
    /**
     * 通过邮箱重置密码
     * @param user  用户名。密码、邮箱
     * @param result  参数未通过校验的结果集
     * @param rPwd  第二次输入的密码
     * @param code   验证码
     * @return com.alibaba.fastjson.JSONObject
     * @author zwl
     * @date 2021/8/22
     **/
    @RequestMapping(value = "/resetPasswordByEmail")
    @ResponseBody
    @PassToken
    public JSONObject resetPasswordByEmail(@Validated(value = {EmailCheck.class, PasswordCheck.class}) User user, BindingResult result, @RequestParam(value = "tPassword") String rPwd, String code) {
        Map<String, Object> map = new HashMap<>();
        //如果有参数未通过校验，将其加入result中
        if (result.hasErrors()) {
            result.getAllErrors().forEach(v -> map.put("errMsg", map.containsKey("errMsg") ? map.get("errMsg") + "," + v.getDefaultMessage() : v.getDefaultMessage()));
        } else {
            //如果两次输入的密码不同
            if (!user.getPassword().equals(rPwd)) {
                map.put("errMsg", "两次输入的密码不一致");
            } else {
                try {
                    //清空手机号，防止干扰
                    user.setPhone("");
                    //重置密码
                    userService.resetPassword(user, code);
                    map.put("code", 0);
                    map.put("message", "密码重置成功");
                } catch (RuntimeException e) {
                    map.put("errMsg", e.getMessage());
                }
            }

        }
        if (!map.containsKey("code")) {
            map.put("code", -1);
        }
        return new JSONObject(map);
    }
    /**
     * 修改密码
     * @param tempUser  用户名和原始密码、  修改后的密码和重复的新密码
     * @param result     参数未通过校验的结果集
     * @return com.alibaba.fastjson.JSONObject
     * @author zwl
     * @date 2021/8/22
     **/
    @RequestMapping(value = "/alterPassword")
    @ResponseBody
    @PassToken
    public JSONObject alterPassword(@Validated(value = {UsernameCheck.class, PasswordCheck.class}) TempUser tempUser, BindingResult result) {
        Map<String, Object> map = new HashMap<>();
        //如果有参数未通过校验，将其加入result中
        if (result.hasErrors()) {
            result.getAllErrors().forEach(v -> map.put("errMsg", map.containsKey("errMsg") ? map.get("errMsg") + " " + v.getDefaultMessage() : v.getDefaultMessage()));
            //判断两次输入的新密码是否相同
        } else if (!tempUser.newPwd.equals(tempUser.tNewPwd)) {
            map.put("errMsg", "两次输入的密码不一致");
            //判断新密码和输入的原始密码是否相同
        } else if (tempUser.newPwd.equals(tempUser.user.getPassword())) {
            map.put("errMsg", "新密码不能和原密码一致");
        } else {
            try {
                //修改密码
                userService.alterPassword(tempUser.user, tempUser.newPwd);
                map.put("code", 0);
                map.put("message", "修改成功");
            } catch (RuntimeException e) {
                map.put("errMsg", e.getMessage());
            }
        }
        if (!map.containsKey("code")) {
            map.put("code", -1);
        }
        return new JSONObject(map);
    }
    @RequestMapping(value = "/alterHeadImage")
    @ResponseBody
    public JSONObject alterHeadImage(HttpServletRequest request, MultipartFile file){
        Map<String, Object> map = new HashMap<>();
        User user=new User();
        user.setId((Integer) request.getAttribute("id"));
        user.setUsername((String) request.getAttribute("username"));
        String headImage= UUIDUtil.getUUID()+".jpg";
        user.setHeadImage(headImage);
        try {
            hadoopService.upload(file, HadoopServiceImpl.HadoopUtil.amendPath("/"+headImage,user.getId(), HadoopServiceImpl.FileType.userProfilePicture),false);
            userService.updateHeadImage(user);
            map.put("code",0);
            map.put("message","修改成功");
        } catch (IOException e) {
            map.put("errMsg","头像上传失败");
        }
        if (!map.containsKey("code")) {
            map.put("code", -1);
        }
        return new JSONObject(map);
    }

    @RequestMapping(value = "/getUserHeadImage")
    @ResponseBody
    public JSONObject getUserHeadImage(HttpServletRequest request, HttpServletResponse response){
        Map<String, Object> map = new HashMap<>();
        User user=new User();
        user.setId((Integer) request.getAttribute("id"));
        user.setId(1);
        user.setHeadImage(userService.getUserData(user).getHeadImage());
        try {
            hadoopService.download(HadoopServiceImpl.HadoopUtil.amendPath("/"+user.getHeadImage(), user.getId(), HadoopServiceImpl.FileType.userProfilePicture),response.getOutputStream());
            map.put("code",0);
            map.put("message","读取完成");
        } catch (IOException e) {
            map.put("errMsg","读取用户头像失败");
        }
        if (!map.containsKey("code")) {
            map.put("code", -1);
        }
        return new JSONObject(map);
    }

    //正式上线记得删除
    @RequestMapping(value = "/createToken")
    @ResponseBody
    @PassToken
    public JSONObject createToken(Integer id){

        String username="";
        Map<String, Object> map = new HashMap<>();
        if (id==null){
            map.put("errMsg","ID不能为空");
            map.put("code",-1);
            return new JSONObject(map);
        }
        Map<String,Object> subMap=new HashMap<>();
        subMap.put("id",id);
        subMap.put("username",username);
        map.put("token",JwtToken.GenerateToken(new JSONObject(subMap).toJSONString(), 365L *24*60*60*1000));
        return new JSONObject(map);
    }

    @RequestMapping(value = "/alterUserInfo")
    @ResponseBody
    public JSONObject alterUserInfo(HttpServletRequest request, String name, String email){
        Map<String, Object> map = new HashMap<>();
        User user=new User();
        user.setId((Integer) request.getAttribute("id"));
        user.setUsername((String) request.getAttribute("username"));
        user.setEmail(email);
        user.setNickname(name);
         userService.updateUserInfo(user);
        map.put("code",0);
        map.put("message","修改成功");
        return new JSONObject(map);
    }

    @RequestMapping(value = "/getUserInfo")
    @ResponseBody
    public JSONObject getUserInfo(HttpServletRequest request){
        Map<String, Object> map = new HashMap<>();
        User user=new User();
        user.setId((Integer) request.getAttribute("id"));
        user.setUsername((String) request.getAttribute("username"));
        try {
            user=userService.getUserData(user);
            user.setPassword("");
            map.put("data",user);
            map.put("code",0);
            map.put("message","修改成功");
        }catch (RuntimeException e){
            map.put("code",-1);
            map.put("errMsg",e.getMessage());
        }
        return new JSONObject(map);
    }
    static class TempUser {
        @NotBlank(message = "请输入密码!", groups = {PasswordCheck.class})
        @Pattern(regexp = "^.{6,18}$", message = "密码长度应为6-18位", groups = {PasswordCheck.class})
        private String newPwd;
        @NotBlank(message = "请输入密码!", groups = {PasswordCheck.class})
        @Pattern(regexp = "^.{6,18}$", message = "密码长度应为6-18位", groups = {PasswordCheck.class})
        private String tNewPwd;
        @Valid
        private User user;

        public String getNewPwd() {
            return newPwd;
        }

        public void setNewPwd(String newPwd) {
            this.newPwd = newPwd;
        }

        public String getTNewPwd() {
            return tNewPwd;
        }

        public void setTNewPwd(String tNewPwd) {
            this.tNewPwd = tNewPwd;
        }

        public User getUser() {
            return user;
        }

        public void setUser(User user) {
            this.user = user;
        }


    }
}
