package com.example.group2.service;

import com.example.group2.pojo.Group;
import com.example.group2.pojo.User;

import java.io.IOException;
import java.util.List;

public interface GroupService {

    /**
     * 创建群组
     *
     * @return int 创建的群组Id
     * @Param: user 创始人
     * @author zwl
     * @date 2021/8/17
     **/
    public int createGroup(User user,String name,String code);

    //获取群组信息
    public Group getGroupInfo(Group group);

    //加入群组
    public void joinGroup(Group group, User user, Group.Data.Power power);

    //退出群组
    public void exitGroup(Group group, User user);

    //解散群组
    public void dismissGroup(Group group, User user);

    //设置用户在当前群组的权限
    public void setPower(Group group, User user, Group.Data.Power power);

    //获取用户在当前群组的权限
    public Group.Data.Power getPower(Group group, User user);

    //获取我创建的群组
    public List<Group> findMyGroup(User user);

    //获取我加入的群组
    public List<Group> findJoinedGroup(User user);

    //获取群组所有成员（包括群主）信息
    public List<User> getGroupMember(Group group);

    //获取群主信息
    public User getGroupOwner(Group group);


    //获取群员列表
    public List<User> getGroupFriends(Group group);


}
