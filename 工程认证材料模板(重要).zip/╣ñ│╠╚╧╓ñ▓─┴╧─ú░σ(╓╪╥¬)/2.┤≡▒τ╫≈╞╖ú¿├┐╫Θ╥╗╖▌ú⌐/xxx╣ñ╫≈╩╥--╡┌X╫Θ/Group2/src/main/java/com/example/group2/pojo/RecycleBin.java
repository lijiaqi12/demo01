package com.example.group2.pojo;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;

public class RecycleBin {
    private int id;
    //删除文件名
    private String deleteFileName;
    //原始路径
    private String originalAddress;
    //文件大小
    private long  size;
    //所属用户
    private User user;
    //删除时间
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date deleteTime;

    public RecycleBin() {
    }

    public RecycleBin(int id) {
        this.id=id;
    }

    public RecycleBin(User user) {
        this.user = user;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDeleteFileName() {
        return deleteFileName;
    }

    public void setDeleteFileName(String deleteFileName) {
        this.deleteFileName = deleteFileName;
    }

    public String getOriginalAddress() {
        return originalAddress;
    }

    public void setOriginalAddress(String originalAddress) {
        this.originalAddress = originalAddress;
    }

    public long getSize() {
        return size;
    }

    public void setSize(long size) {
        this.size = size;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Date getDeleteTime() {
        return deleteTime;
    }

    public void setDeleteTime(Date deleteTime) {
        this.deleteTime = deleteTime;
    }
}
