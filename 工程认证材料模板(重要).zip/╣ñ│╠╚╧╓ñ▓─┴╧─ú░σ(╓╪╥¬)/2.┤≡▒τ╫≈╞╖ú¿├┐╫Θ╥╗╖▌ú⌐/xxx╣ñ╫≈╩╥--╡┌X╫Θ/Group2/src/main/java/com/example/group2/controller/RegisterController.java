package com.example.group2.controller;

import com.alibaba.fastjson.JSONObject;
import com.example.group2.handlerInterceptor.PassToken;
import com.example.group2.pojo.User;
import com.example.group2.pojo.check.EmailCheck;
import com.example.group2.pojo.check.PasswordCheck;
import com.example.group2.pojo.check.PhoneCheck;
import com.example.group2.pojo.check.UsernameCheck;
import com.example.group2.service.UserService;
import com.example.group2.utils.CodeUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.Map;

@Controller
@CrossOrigin(origins = "${netDisk.web.path}", allowedHeaders = "*", allowCredentials = "true")
public class RegisterController {

    private UserService userService;

    @Autowired
    public void setUserService(UserService userService) {
        this.userService = userService;
    }

    /**
     * 1.手机号注册
     *
     * @return com.alibaba.fastjson.JSONObject  json对象 包含注册成功或失败的信息，成功会返回用户注册数据。
     * @author zwl
     * @date 2021/8/14 10:38
     * @Param: user  用户注册信息
     * @Param: username 要注册的用户名
     * @Param: password 用户的密码
     * @Param: phone  注册的手机号
     * @Param: result  参数未通过校验的结果集
     * @Param: rPwd  二次输入的密码
     * @Param: code  用户输入的验证码
     */
    @RequestMapping(value = "/registerByPhone")
    @ResponseBody
    @PassToken
    public JSONObject registerByPhone(@Validated(value = {PhoneCheck.class, UsernameCheck.class, PasswordCheck.class}) User user, BindingResult result, @RequestParam(value = "tPassword") String rPwd, String code) {
        Map<String, Object> map = new HashMap<>();
        //如果有参数未通过校验，将其加入result中
        if (result.hasErrors()) {
            result.getAllErrors().forEach(v -> map.put("errMsg", map.containsKey("errMsg") ? map.get("errMsg") + " " + v.getDefaultMessage() : v.getDefaultMessage()));
        } else {
            //如果两次输入的密码不同
            if (!user.getPassword().equals(rPwd)) {
                map.put("errMsg", "两次输入的密码不一致");
                //判断验证码是否正确
            } else if (CodeUtil.codeCheck(user.getPhone(), code, CodeUtil.CodeTypeEnum.PHONE_CODE)) {
                try {
                    //将邮箱清空，反正干扰注册
                    user.setEmail(null);
                    userService.userRegister(user);
                    //敏感信息清空
                    user.setPassword("");
                    map.put("code", 0);
                    map.put("message", "注册成功");
                    map.put("data", user);
                } catch (RuntimeException e) {
                    map.put("errMsg", e.getMessage());
                }
            } else {
                map.put("errMsg", "验证码错误");
            }
        }
        if (!map.containsKey("code")) {
            map.put("code", -1);
        }
        return new JSONObject(map);
    }

    /**
     * 2.邮箱注册
     *
     * @return com.alibaba.fastjson.JSONObject json对象 包含注册成功或失败的信息，成功会返回用户注册数据。
     * @author zwl
     * @date 2021/8/14 10:42
     * @Param: user  用户注册信息
     * @Param: username 要注册的用户名
     * @Param: password 用户的密码
     * @Param: email  注册的邮箱
     * @Param: result  参数未通过校验的结果集
     * @Param: rPwd  二次输入的密码
     * @Param: code  用户输入的验证码
     */
    @RequestMapping(value = "/registerByEmail")
    @ResponseBody
    @PassToken
    public JSONObject registerByEmail(@Validated(value = {PasswordCheck.class, UsernameCheck.class, EmailCheck.class}) User user, BindingResult result, @RequestParam(value = "tPassword") String rPwd, String code) {
        Map<String, Object> map = new HashMap<>();
        //如果有参数未通过校验，将其加入result中
        if (result.hasErrors()) {
            result.getAllErrors().forEach(v -> map.put("errMsg", map.containsKey("errMsg") ? map.get("errMsg") + " " + v.getDefaultMessage() : v.getDefaultMessage()));
        } else {
            //如果两次输入的密码不同
            if (!user.getPassword().equals(rPwd)) {
                map.put("errMsg", "两次输入的密码不一致");
                //判断验证码是否正确
            } else if (CodeUtil.codeCheck(user.getEmail(), code, CodeUtil.CodeTypeEnum.EMAIL_CODE)) {
                try {
                    //先清空手机号，防止干扰
                    user.setPhone(null);
                    //注册
                    userService.userRegister(user);
                    //清除敏感信息
                    user.setPassword("");
                    map.put("code", 0);
                    map.put("message", "注册成功");
                    map.put("data", user);
                } catch (RuntimeException e) {
                    map.put("errMsg", e.getMessage());
                }
            } else {
                map.put("errMsg", "验证码错误");
            }
        }
        if (!map.containsKey("code")) {
            map.put("code", -1);
        }
        return new JSONObject(map);
    }
}
