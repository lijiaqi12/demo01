package com.example.group2.utils;

import io.jsonwebtoken.*;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Component
public class JwtToken {
    private static String key;
    private static long ttlMillis;
    private static String issuer;
    private RedisTemplate<String, String> redisTemplate;

    @Autowired(required = false)
    public void setRedisTemplate(RedisTemplate<String, String> redisTemplate) {
        this.redisTemplate = redisTemplate;
    }


    @Value(value = "${token.ttlMillis}")
    public void setTtlMillis(String ttlMillis) {
        String []ss=ttlMillis.split("\\*");
        long tempTime=1;
        for (String s:ss){
            tempTime*=Integer.parseInt(s);
        }
        JwtToken.ttlMillis = tempTime;
    }

    @Value(value = "${token.key}")
    public void setKey(String key) {
        JwtToken.key = key;
    }

    @Value(value = "${token.issuer}")
    public void setIssuer(String issuer) {
        JwtToken.issuer = issuer;
    }

    //生成有效时间默认的token
    public static String GenerateToken(String subject) {
        String token = "";
        String jwt_id = UUIDUtil.getUUID();
        token = createJWT(jwt_id, subject, ttlMillis);
        return token;
    }

    //生成自定义时间的token
    public static String GenerateToken(String subject, long ttlMillis) {
        String token = "";
        String jwt_id = UUIDUtil.getUUID();
        token = createJWT(jwt_id, subject, ttlMillis);
        return token;
    }

    /**
     * 解密jwt
     *
     * @param jwt jwt
     */
    public static Claims parseJWT(String jwt) {
        SecretKey key = generalKey();  //签名秘钥，和生成的签名的秘钥一模一样
        return Jwts.parser()  //得到DefaultJwtParser
                .setSigningKey(key)                 //设置签名的秘钥
                .parseClaimsJws(jwt).getBody();
    }

    /**
     * 创建jwt
     *
     * @param id      tokenId
     * @param subject 数据体
     * @return 生成的JWT
     */
    private static String createJWT(String id, String subject, long ttlMillis) {

        // 指定签名的时候使用的签名算法，也就是header那部分，jjwt已经将这部分内容封装好了。
        SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;

        // 生成JWT的时间
        long nowMillis = System.currentTimeMillis();
        Date now = new Date(nowMillis);

        // 创建payload的私有声明（根据特定的业务需要添加，如果要拿这个做验证，一般是需要和jwt的接收方提前沟通好验证方式的）
        Map<String, Object> claims = new HashMap<>();
        //claims.put("userCode", userCode);

        // 生成签名的时候使用的秘钥secret，切记这个秘钥不能外露哦。它就是你服务端的私钥，在任何场景都不应该流露出去。
        // 一旦客户端得知这个secret, 那就意味着客户端是可以自我签发jwt了。
        SecretKey key = generalKey();

        // 下面就是在为payload添加各种标准声明和私有声明了
        JwtBuilder builder = Jwts.builder() // 这里其实就是new一个JwtBuilder，设置jwt的body
                .setClaims(claims)          // 如果有私有声明，一定要先设置这个自己创建的私有的声明，这个是给builder的claim赋值，一旦写在标准的声明赋值之后，就是覆盖了那些标准的声明的
                .setId(id)                  // 设置jti(JWT ID)：是JWT的唯一标识，根据业务需要，这个可以设置为一个不重复的值，主要用来作为一次性token,从而回避重放攻击。
                .setIssuedAt(now)           // iat: jwt的签发时间
                .setIssuer(issuer)          // issuer：jwt签发人
                .setSubject(subject)        // sub(Subject)：代表这个JWT的主体，即它的所有人，这个是一个json格式的字符串，可以存放什么userId，roleId之类的，作为什么用户的唯一标志。
                .signWith(signatureAlgorithm, key); // 设置签名使用的签名算法和签名使用的秘钥

        if (ttlMillis >= 0) {        // 设置过期时间
            long expMillis = nowMillis + ttlMillis;
            Date exp = new Date(expMillis);
            builder.setExpiration(exp);
        }
        return builder.compact();
    }


    /**
     * 由字符串生成加密key
     *
     * @return 加密后的key
     */
    private static SecretKey generalKey() {


        // 本地的密码解码
        byte[] encodedKey = Base64.decodeBase64(key);

        // 根据给定的字节数组使用AES加密算法构造一个密钥

        return new SecretKeySpec(encodedKey, 0, encodedKey.length, "AES");
    }


    /**
     * 检查token是否正确
     *
     * @param token 令牌
     * @return true正确;false失败
     */
    public static Map<String, Object> checkToken(String token) {
        Map<String, Object> map = new HashMap<>();
        Claims claims = null;
        try {
            claims = parseJWT(token);
            map.put("code", 0);
            map.put("claims", claims);
        } catch (ExpiredJwtException e) {
            map.put("code", -1);
            map.put("errMsg", JWT_ErrCode.JWT_ERRCODE_EXPIRE.errInfo);
            return map;
        } catch (SignatureException e) {
            map.put("code", -1);
            map.put("errMsg", JWT_ErrCode.JWT_ERRCODE_SIGNMisMATCH.errInfo);
        } catch (Exception e) {
            map.put("code", -1);
            map.put("errMsg", JWT_ErrCode.JWT_ERRCODE_FAIL.errInfo);
            return map;
        }
        //根据redis进行检查
        //  String r_token = (String)redisTemplate.opsForValue().get(key);
        // 返回检测结果,更新token时间
        /*redisTemplate.opsForValue().set(key, token,
                ttlMillis, TimeUnit.HOURS);*/
        return map;
    }

    /**
     * 注销Token
     *
     * @param token 令牌
     * @return true正确;false失败
     */
    public boolean clearToken(String token) {
        //解析出userId和uuid
        if (token == null || "".equals(token)) {
            return false;
        }
        String[] arr1 = token.split("_");
        if (arr1.length != 2) {
            return false;
        }
        //根据redis进行检查
        String key = arr1[0] + "_token";
        String r_token = redisTemplate.opsForValue().get(key);
        if (r_token == null) {
            return false;
        }
        //注销token
        redisTemplate.delete(key);
        return true;
    }


    public enum JWT_ErrCode {
        JWT_ERRCODE_EXPIRE(1, "登录过期"), JWT_ERRCODE_SIGNMisMATCH(2, "签名不匹配"), JWT_ERRCODE_FAIL(3, "验证失败");
        private final int id;
        private final String errInfo;

        JWT_ErrCode(int id, String errInfo) {
            this.id = id;
            this.errInfo = errInfo;
        }

        public static String getErrInfo(int id) {
            for (JWT_ErrCode jwt : JWT_ErrCode.values()) {
                if (id == jwt.id) {
                    return jwt.errInfo;
                }
            }
            return "未知的错误类型";
        }
    }
}
