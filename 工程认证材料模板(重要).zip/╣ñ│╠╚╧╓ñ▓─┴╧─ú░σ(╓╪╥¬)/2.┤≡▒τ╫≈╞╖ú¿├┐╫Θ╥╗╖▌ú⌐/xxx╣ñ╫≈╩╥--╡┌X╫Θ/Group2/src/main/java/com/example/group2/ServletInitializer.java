package com.example.group2;

import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

//该类在idea开发工具启动springBoot main函数时不会被初始化，在Tomcat启动时才会被初始化
public class ServletInitializer extends SpringBootServletInitializer {
    public ServletInitializer() {
        System.out.println("初始化ServletInitializer");
    }
    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(Group2Application.class);//MyApplication是启动类名
    }
}