package com.example.group2.controller;

import com.alibaba.fastjson.JSONObject;
import com.example.group2.handlerInterceptor.PassToken;
import com.example.group2.pojo.Group;
import com.example.group2.pojo.RecycleBin;
import com.example.group2.pojo.Share;
import com.example.group2.pojo.User;
import com.example.group2.service.GroupService;
import com.example.group2.service.HadoopService;
import com.example.group2.service.RecycleBinService;
import com.example.group2.service.impl.HadoopServiceImpl;
import org.apache.hadoop.fs.FileStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;

@Controller
@Validated
@CrossOrigin(origins = "${netDisk.web.path}", allowedHeaders = "*", allowCredentials = "true")
public class HadoopController {
    private HadoopService hadoopService;
    private GroupService groupService;
    private RecycleBinService recycleBinService;
    //private RsaUtil rsaUtil;


    /*@Autowired
    public void setRsaUtil(RsaUtil rsaUtil) {
        this.rsaUtil = rsaUtil;
    }*/

    @Autowired
    public void setHadoopService(HadoopService hadoopService) {
        this.hadoopService = hadoopService;
    }

    @Autowired
    public void setGroupService(GroupService groupService) {
        this.groupService = groupService;
    }

    @Autowired
    public void setRecycleBinService(RecycleBinService recycleBinService) {
        this.recycleBinService = recycleBinService;
    }

    /**
     * 获取当前路径的所有文件及文件夹
     *
     * @param path    路径
     * @param request 。。
     * @param type    文件类型 /1.私人文件 2.公共文件 3.回收站 4.共享文件  共享文件不接收
     * @return com.alibaba.fastjson.JSONObject
     * @Param groupId  群组Id  type为1，3可以没有  type=2无此参数表示获取加入的群主信息（创建及加入）
     * @author zwl
     * @date 2021/8/16
     **/
    @RequestMapping(value = "/getFileStatus")
    @ResponseBody
    public JSONObject getFileStatus(String path, Integer type, HttpServletRequest request, Integer groupId) {

        Map<String, Object> map = new HashMap<>();
        if (type == null) {
            map.put("errMsg", "无法识别的类型");
        } else {

            User user = new User();
            user.setId((Integer) request.getAttribute("id"));
            user.setUsername((String) request.getAttribute("username"));
            //初始化type，用于后期辨别具体类型
            Enum<HadoopServiceImpl.FileType> fileType = HadoopServiceImpl.FileType.getFileType(type);
            if (fileType == null) {
                map.put("errMsg", "无法识别的类型");
            } else {
                //如果type=2
                if (fileType.equals(HadoopServiceImpl.FileType.publicFile)) {
                    //如果此时未传递groupId
                    if (groupId == null) {
                        //获取用户创建的群组
                        List<Group> myGroups = groupService.findMyGroup(user);
                        //获取用户加入的群组
                        List<Group> joinedGroups = groupService.findJoinedGroup(user);
                        Map<String, List<Group>> groups = new HashMap<>();
                        groups.put("myGroups", myGroups);
                        groups.put("joinedGroups", joinedGroups);
                        map.put("data", groups);
                        map.put("code", 0);
                        map.put("message", "检索完成");
                    } else {

                        try {
                            if (!groupService.getGroupMember(new Group(groupId)).contains(user)) {
                                map.put("errMsg", "你不在当前群组中，无法查看群组文件");
                            } else {
                                //获取该群组当前目录下的文件
                                map.put("data", hadoopService.getFileStatus(HadoopServiceImpl.HadoopUtil.amendPath(path, groupId, fileType)));
                                map.put("code", 0);
                                map.put("message", "检索完成");
                            }
                        } catch (FileNotFoundException e) {
                            map.put("errMsg", "没有找到文件");
                        } catch (IOException e) {
                            map.put("errMsg", "发生异常");
                        }catch (RuntimeException e) {
                            map.put("errMsg", e.getMessage());
                        }
                    }
                } else {
                    try {
                        //否则获取用户输入或回收站文件
                        map.put("data", hadoopService.getFileStatus(HadoopServiceImpl.HadoopUtil.amendPath(path, user.getId(), fileType)));
                        map.put("code", 0);
                        map.put("message", "检索完成");
                    }catch (FileNotFoundException e) {
                        map.put("errMsg", "没有找到文件");
                    } catch (IOException e) {
                        map.put("errMsg", "发生异常");
                    }catch (RuntimeException e){
                        map.put("errMsg",e.getMessage());
                    }
                }
            }
        }
        if (!map.containsKey("code")) {
            map.put("code", -1);
        }
        return new JSONObject(map);
    }

    /**
     * 新建目录
     *
     * @param path    要创建目录的路径
     * @param request 。。
     * @param type    文件类型 /1.私人文件 2.公共文件 3.回收站 4.共享文件 共享文件不接收
     * @return com.alibaba.fastjson.JSONObject
     * @Param: groupId 群组Id 不是 公共文件 不用填
     * @author zwl
     * @date 2021/8/16
     **/
    @RequestMapping(value = "/mkdir")
    @ResponseBody
    public JSONObject mkdir(@RequestParam(value = "newDirPath") String path, HttpServletRequest request, Integer type, Integer groupId) {
        Map<String, Object> map = new HashMap<>();
        {
            User user = new User();
            user.setId((Integer) request.getAttribute("id"));
            user.setUsername((String) request.getAttribute("username"));
            if (type == null) {
                map.put("errMsg", "参数异常");
                map.put("code", -1);
                return new JSONObject(map);
            }
            Enum<HadoopServiceImpl.FileType> fileType = HadoopServiceImpl.FileType.getFileType(type);
            if (fileType == null) {
                map.put("errMsg", "无法识别的类型");
            } else {
                //先判断文件类型
                if (fileType.equals(HadoopServiceImpl.FileType.publicFile)) {
                    //如果是群组文件且未输入群组Id
                    if (groupId == null) {
                        map.put("errMsg", "不能在这里创建文件!!!");
                    } else {
                        //查找当前群组的所有用户
                        List<User> users = new ArrayList<>();
                        try {
                            users = groupService.getGroupMember(new Group(groupId));
                        } catch (RuntimeException e) {
                            map.put("errMsg", e.getMessage());
                        }
                        if (!users.contains(user)) {
                            //如果flag为false说明用户不在当前群组中，直接拒绝创建文件夹请求
                            map.put("errMsg", "不能在未加入的群组创建文件!!!");
                            //如果是创建者,--创建者拥有完全控制权限
                        } else if (users.get(0).equals(user)) {
                            try {
                                //判断创建是否成功
                                if (hadoopService.mkdir(HadoopServiceImpl.HadoopUtil.amendPath(path, groupId, fileType))) {
                                    map.put("code", 0);
                                    map.put("message", "创建成功");
                                    //将创建目录后的文件列表返回
                                    map.put("data", hadoopService.getFileStatus(HadoopServiceImpl.HadoopUtil.amendParentPath(path, groupId, fileType)));
                                } else {
                                    map.put("errMsg", "创建失败");
                                }
                            } catch (IOException e) {
                                map.put("errMsg", "发生不可预知的异常");
                            }
                        } else {
                            //不是创建者
                            //获取用户的权限
                            Group.Data.Power power = groupService.getPower(new Group(groupId), user);
                            //如果没用创建目录权限
                            if (!power.isMkdirPower()) {
                                map.put("errMsg", "没有权限创建目录");
                            } else {
                                //有权限进行创建操作
                                try {
                                    //判断创建是否成功
                                    if (hadoopService.mkdir(HadoopServiceImpl.HadoopUtil.amendPath(path, groupId, fileType))) {
                                        map.put("code", 0);
                                        map.put("message", "创建成功");
                                        //将创建目录后的文件列表返回
                                        map.put("data", hadoopService.getFileStatus(HadoopServiceImpl.HadoopUtil.amendParentPath(path, groupId, fileType)));
                                    } else {
                                        map.put("errMsg", "创建失败");
                                    }
                                } catch (IOException e) {
                                    map.put("errMsg", "发生不可预知的异常");
                                }
                            }
                        }

                    }
                    //否则是私人文件
                } else {
                    try {
                        //判断是否创建成功
                        if (hadoopService.mkdir(HadoopServiceImpl.HadoopUtil.amendPath(path, user.getId(), fileType))) {
                            map.put("code", 0);
                            map.put("message", "创建成功");
                            //将创建目录后的文件列表返回
                            map.put("data", hadoopService.getFileStatus(HadoopServiceImpl.HadoopUtil.amendParentPath(path, user.getId(), fileType)));
                        } else {
                            map.put("errMsg", "创建失败");
                        }
                    } catch (IOException e) {
                        map.put("errMsg", "发生不可预知的异常");
                    }
                }
            }
        }
        if (!map.containsKey("code")) {
            map.put("code", -1);
        }
        return new JSONObject(map);
    }

    /**
     * 删除文件 或文件夹
     *
     * @param path    要删除的文件或文件夹路径
     * @param request 。。
     * @param type    文件类型  /1.私人文件 2.公共文件 3.回收站 4.共享文件 共享文件不走这个方法
     * @return com.alibaba.fastjson.JSONObject
     * @Param: groupId 群组Id   type为1.3时不需要，type=2必须要有
     * @author zwl
     * @date 2021/8/16
     **/
    @RequestMapping(value = "/delete")
    @ResponseBody
    public JSONObject delete(String path, HttpServletRequest request, Integer type, Integer groupId) {
        Map<String, Object> map = new HashMap<>();
        {
            User user = new User();
            user.setId((Integer) request.getAttribute("id"));
            user.setUsername((String) request.getAttribute("username"));
            if (type == null) {
                map.put("errMsg", "参数不合法");
                map.put("code", -1);
                return new JSONObject(map);
            }
            Enum<HadoopServiceImpl.FileType> fileType = HadoopServiceImpl.FileType.getFileType(type);
            if (fileType == null) {
                map.put("errMsg", "无法识别的类型");
            } else {
                //先判断文件类型
                if (fileType.equals(HadoopServiceImpl.FileType.publicFile)) {
                    //如果是群组文件且未输入群组Id
                    if (groupId == null) {
                        map.put("errMsg", "不能删除外部文件!!!");
                    } else {
                        Group group = new Group(groupId);
                        //判断是否在当前群组中
                        AtomicReference<Boolean> flag = new AtomicReference<>(false);
                        try {
                            //遍历群成员与当前用户进行比较，如果在群组中将flag设置为true
                            groupService.getGroupMember(group).forEach(v -> {
                                if (v.equals(user))
                                    flag.set(true);
                            });
                        } catch (RuntimeException e) {
                            map.put("errMsg", e.getMessage());
                            map.put("code", -1);
                            return new JSONObject(map);
                        }
                        if (!flag.get()) {
                            map.put("errMsg", "你不在当前群组中,无法对文件进行操作");
                        } else {
                            //如果是群主，可以随意删除文件----
                            if (groupService.getGroupOwner(group).equals(user)) {
                                try {
                                    //判断是否删除成功
                                    if (hadoopService.delete(HadoopServiceImpl.HadoopUtil.amendPath(path, groupId, fileType))) {
                                        //返回删除后的文件列表
                                        map.put("data", hadoopService.getFileStatus(HadoopServiceImpl.HadoopUtil.getParentPath(HadoopServiceImpl.HadoopUtil.amendPath(path, groupId, fileType))));
                                        map.put("code", 0);
                                        map.put("message", "删除成功");
                                    } else {
                                        map.put("errMsg", "删除失败");
                                    }
                                } catch (IOException e) {
                                    map.put("errMsg", "发生异常");
                                }
                            } else {
                                //否则需要进行权限的确认
                                Group.Data.Power power;
                                try {
                                    //获取用户权限
                                    power = groupService.getPower(group, user);
                                } catch (RuntimeException e) {
                                    map.put("errMsg", e.getMessage());
                                    map.put("code", -1);
                                    return new JSONObject(map);
                                }
                                //如果没有删除权限
                                if (!power.isDeletePower()) {
                                    map.put("errMsg", "没有权限进行删除操作");
                                } else {
                                    try {
                                        //判断删除结果
                                        if (hadoopService.delete(HadoopServiceImpl.HadoopUtil.amendPath(path, groupId, fileType))) {
                                            map.put("code", 0);
                                            map.put("message", "删除成功");
                                            //返回删除后的文件列表
                                            map.put("data", hadoopService.getFileStatus(HadoopServiceImpl.HadoopUtil.getParentPath(HadoopServiceImpl.HadoopUtil.amendPath(path, groupId, fileType))));
                                        } else {
                                            map.put("errMsg", "删除失败");
                                        }
                                    } catch (IOException e) {
                                        map.put("errMsg", "发生异常");
                                    }
                                }
                            }
                        }
                    }
                    //如果是删除回收站文件
                } else if (fileType.equals(HadoopServiceImpl.FileType.recycleBin)) {
                    User owner = new User();
                    try {
                        owner = recycleBinService.getFileOwner(new RecycleBin(HadoopServiceImpl.HadoopUtil.getUserId(path)));
                    } catch (RuntimeException e) {
                        map.put("errMsg", e.getMessage());
                        map.put("code", -1);
                        return new JSONObject(map);
                    }
                    if (!owner.equals(user)) {
                        map.put("errMsg", "删除失败,这不是你的文件");
                    } else {
                        //判断删除结果
                        try {
                            if (hadoopService.delete(HadoopServiceImpl.HadoopUtil.amendPath(path, user.getId(), fileType))) {
                                //返回删除后的文件列表
                                map.put("data", hadoopService.getFileStatus(HadoopServiceImpl.HadoopUtil.getParentPath(HadoopServiceImpl.HadoopUtil.amendPath(path, user.getId(), HadoopServiceImpl.FileType.privateFile))));
                                map.put("code", 0);
                                map.put("message", "删除成功");
                            } else {
                                map.put("errMsg", "删除失败");
                            }
                        } catch (RuntimeException e) {
                            map.put("errMsg", e.getMessage());
                        } catch (IOException e) {
                            map.put("errMsg", "发生不可预知的异常");
                        }
                    }
                } else {
                    //否则是删除个人文件
                    try {
                        //判断删除结果
                        if (hadoopService.delete(HadoopServiceImpl.HadoopUtil.amendPath(path, user.getId(), fileType))) {
                            //返回删除后的文件列表
                            map.put("data", hadoopService.getFileStatus(HadoopServiceImpl.HadoopUtil.getParentPath(HadoopServiceImpl.HadoopUtil.amendPath(path, user.getId(), HadoopServiceImpl.FileType.privateFile))));
                            map.put("code", 0);
                            map.put("message", "删除成功");
                        } else {
                            map.put("errMsg", "删除失败");
                        }
                    } catch (RuntimeException e) {
                        map.put("errMsg", e.getMessage());
                    } catch (IOException e) {
                        map.put("errMsg", "发生不可预知的异常");
                    }
                }
            }
        }

        if (!map.containsKey("code")) {
            map.put("code", -1);
        }
        return new JSONObject(map);
    }

    /**
     * 文件修改/移动
     *
     * @param oldPath 修改前的路径 含文件名
     * @param newPath 修改后的路径 含文件名
     * @param request 请求中的用户信息
     * @param type    文件类型  /1.私人文件 2.公共文件 3.回收站 4.共享文件 共享文件不走这个方法
     * @param groupId 群组Id   type为1.3时不需要，type=2必须要有
     * @return com.alibaba.fastjson.JSONObject
     * @author zwl
     * @date 2021/8/22
     **/
    @RequestMapping(value = "/alter")
    @ResponseBody
    public JSONObject update(@RequestParam(value = "filePath") String oldPath, @RequestParam(value = "alterName") String newPath, HttpServletRequest request, Integer type, Integer groupId) {
        Map<String, Object> map = new HashMap<>();
        {
            User user = new User();
            user.setId((Integer) request.getAttribute("id"));
            user.setUsername((String) request.getAttribute("username"));
            if (type == null) {
                map.put("errMsg", "参数不合法");
                map.put("code", -1);
                return new JSONObject(map);
            }
            Enum<HadoopServiceImpl.FileType> fileType = HadoopServiceImpl.FileType.getFileType(type);
            if (fileType == null) {
                map.put("errMsg", "无法识别的类型");
            } else {
                //先判断文件类型
                if (fileType.equals(HadoopServiceImpl.FileType.publicFile)) {
                    //如果是群组文件且未输入群组Id
                    if (groupId == null) {
                        map.put("errMsg", "不能在这里修改文件!!!");
                    } else {
                        //初始化群组
                        Group group = new Group(groupId);
                        //判断是否在群组中
                        AtomicReference<Boolean> flag = new AtomicReference<>(false);
                        try {
                            //遍历群成员列表。如果在群组中将flag设置为true
                            groupService.getGroupMember(group).forEach(v -> {
                                if (v.equals(user))
                                    flag.set(true);
                            });
                        } catch (RuntimeException e) {
                            map.put("errMsg", e.getMessage());
                        }
                        if (!flag.get()) {
                            map.put("errMsg", "你不在当前群组中,无法对文件进行操作");
                        } else {
                            //如果是群主，可以随意修改文件----
                            if (groupService.getGroupOwner(group).equals(user)) {
                                try {
                                    //判断修改结果
                                    if (hadoopService.update(HadoopServiceImpl.HadoopUtil.amendPath(oldPath, groupId, fileType), HadoopServiceImpl.HadoopUtil.amendPath(newPath, groupId, fileType))) {
                                        map.put("code", 0);
                                        map.put("message", "修改成功");
                                        //返回修改后的文件列表
                                        map.put("data", hadoopService.getFileStatus(HadoopServiceImpl.HadoopUtil.getParentPath(HadoopServiceImpl.HadoopUtil.amendPath(oldPath, groupId, fileType))));
                                    } else {
                                        map.put("errMsg", "修改失败");
                                    }
                                } catch (RuntimeException e) {
                                    map.put("errMsg", e.getMessage());
                                } catch (IOException e) {
                                    map.put("errMsg", "发生不可预知的异常");
                                }
                            } else {
                                //否则需要进行权限的确认
                                Group.Data.Power power;
                                try {
                                    //获取权限
                                    power = groupService.getPower(group, user);
                                } catch (RuntimeException e) {
                                    map.put("errMsg", e.getMessage());
                                    map.put("code", -1);
                                    return new JSONObject(map);
                                }
                                //如果没有修改权限
                                if (!power.isUpdatePower()) {
                                    map.put("errMsg", "没有权限进行修改操作");
                                } else {
                                    //否则有权限
                                    try {
                                        //判断修改结果
                                        if (hadoopService.update(HadoopServiceImpl.HadoopUtil.amendPath(oldPath, groupId, fileType), HadoopServiceImpl.HadoopUtil.amendPath(newPath, groupId, fileType))) {
                                            map.put("code", 0);
                                            map.put("message", "修改成功");
                                            //返回修改后的文件列表
                                            map.put("data", hadoopService.getFileStatus(HadoopServiceImpl.HadoopUtil.getParentPath(HadoopServiceImpl.HadoopUtil.amendPath(oldPath, groupId, fileType))));
                                        } else {
                                            map.put("errMsg", "修改失败");
                                        }
                                    } catch (RuntimeException e) {
                                        map.put("errMsg", e.getMessage());
                                    } catch (IOException e) {
                                        map.put("errMsg", "发生不可预知的异常");
                                    }
                                }
                            }
                        }
                    }
                } else {
                    //否则修改的是个人文件
                    try {
                        //判断修改结果
                        if (hadoopService.update(HadoopServiceImpl.HadoopUtil.amendPath(oldPath, user.getId(), fileType), HadoopServiceImpl.HadoopUtil.amendPath(newPath, user.getId(), fileType))) {
                            map.put("code", 0);
                            map.put("message", "修改成功");
                            //返回修改后的文件列表
                            map.put("data", hadoopService.getFileStatus(HadoopServiceImpl.HadoopUtil.getParentPath(HadoopServiceImpl.HadoopUtil.amendPath(oldPath, user.getId(), fileType))));
                        } else {
                            map.put("errMsg", "修改失败");
                        }
                    } catch (RuntimeException e) {
                        map.put("errMsg", e.getMessage());
                    } catch (IOException e) {
                        map.put("errMsg", "发生不可预知的异常");
                    }
                }

            }
        }

        if (!map.containsKey("code")) {
            map.put("code", -1);
        }
        return new JSONObject(map);
    }

    /**
     * 上传文件
     *
     * @param request 请求中的用户信息
     * @param path    上传的路径
     * @param files    上传的文件
     * @param type    文件类型  /1.私人文件 2.公共文件 3.回收站 4.共享文件 共享文件不走这个方法
     * @param groupId 群组Id   type为1.3时不需要，type=2必须要有
     * @return com.alibaba.fastjson.JSONObject
     * @author zwl
     * @date 2021/8/22
     **/
    @RequestMapping(value = "/upload")
    @ResponseBody
    public JSONObject upload(HttpServletRequest request, String path, @RequestParam(value = "file") MultipartFile []files, Integer type, Integer groupId) {
        Map<String, Object> map = new HashMap<>();
        {
            User user = new User();
            user.setId((Integer) request.getAttribute("id"));
            user.setUsername((String) request.getAttribute("username"));
            if (type == null) {
                map.put("errMsg", "参数不合法");
                map.put("code", -1);
                return new JSONObject(map);
            }
            Enum<HadoopServiceImpl.FileType> fileType = HadoopServiceImpl.FileType.getFileType(type);
            if (fileType == null) {
                map.put("errMsg", "无法识别的类型");
            } else {
                //先判断文件类型
                if (fileType.equals(HadoopServiceImpl.FileType.publicFile)) {
                    //如果是群组文件且未输入群组Id
                    if (groupId == null) {
                        map.put("errMsg", "上传路径有误!!!");
                    } else {
                        Group group = new Group(groupId);
                        //判断是否在群组中
                        AtomicReference<Boolean> flag = new AtomicReference<>(false);
                        try {
                            //遍历群组成员列表，如果在群组中将flag设置为true
                            groupService.getGroupMember(group).forEach(v -> {
                                if (v.equals(user))
                                    flag.set(true);
                            });
                        } catch (RuntimeException e) {
                            map.put("errMsg", e.getMessage());
                        }
                        if (!flag.get()) {
                            map.put("errMsg", "你不在当前群组中,无法对文件进行操作");
                        } else {
                            //如果是群主，可以随意上传文件----
                            if (groupService.getGroupOwner(group).equals(user)) {
                                try {
                                    for (MultipartFile file:files){
                                        hadoopService.upload(file, HadoopServiceImpl.HadoopUtil.amendPath(path, groupId, fileType));
                                    }
                                    map.put("code", 0);
                                    map.put("message", "上传成功");
                                    //返回上传后的文件列表
                                    map.put("data", hadoopService.getFileStatus(HadoopServiceImpl.HadoopUtil.amendPath(path, groupId, fileType)));
                                } catch (RuntimeException e) {
                                    map.put("errMsg", e.getMessage());
                                } catch (IOException e) {
                                    map.put("errMsg", "上传异常");
                                }
                            } else {
                                //否则需要进行权限的确认
                                Group.Data.Power power;
                                try {
                                    //获取权限
                                    power = groupService.getPower(group, user);
                                } catch (RuntimeException e) {
                                    map.put("errMsg", e.getMessage());
                                    map.put("code", -1);
                                    return new JSONObject(map);
                                }
                                //如果没用上传权限
                                if (!power.isUploadPower()) {
                                    map.put("errMsg", "没有权限进行上传操作");
                                } else {
                                    //否则有权限
                                    try {
                                        for (MultipartFile file:files){
                                            hadoopService.upload(file, HadoopServiceImpl.HadoopUtil.amendPath(path, groupId, fileType));
                                        }                                        map.put("code", 0);
                                        map.put("message", "上传成功");
                                        //返回上传后的文件列表
                                        map.put("data", hadoopService.getFileStatus(HadoopServiceImpl.HadoopUtil.amendPath(path, groupId, fileType)));
                                    } catch (RuntimeException e) {
                                        map.put("errMsg", e.getMessage());
                                    } catch (IOException e) {
                                        map.put("errMsg", "发生不可预知的异常");
                                    }
                                }
                            }
                        }
                    }
                } else {
                    //否则是个人文件
                    try {
                        for (MultipartFile file:files){
                            hadoopService.upload(file, HadoopServiceImpl.HadoopUtil.amendPath(path, user.getId(), fileType));
                        }
                        map.put("code", 0);
                        map.put("message", "上传成功");
                        //返回上传后的文件列表
                        map.put("data", hadoopService.getFileStatus(HadoopServiceImpl.HadoopUtil.amendPath(path, user.getId(), fileType)));
                    } catch (RuntimeException e) {
                        map.put("errMsg", e.getMessage());
                    } catch (IOException e) {
                        map.put("errMsg", "发生不可预知的异常");
                    }
                }

            }
        }

        if (!map.containsKey("code")) {
            map.put("code", -1);
        }
        return new JSONObject(map);
    }

    /**
     * 文件下载
     *
     * @param request  下载的用户信息
     * @param response 。。
     * @param path     下载的文件路径
     * @param type     文件类型  /1.私人文件 2.公共文件 3.回收站 4.共享文件 共享文件不走这个方法
     * @param groupId  群组Id   type为1.3时不需要，type=2必须要有
     * @return com.alibaba.fastjson.JSONObject
     * @author zwl
     * @date 2021/8/22
     **/
    @RequestMapping(value = "/download")
    @ResponseBody
    public JSONObject download(HttpServletRequest request, HttpServletResponse response, String[] path, Integer type, Integer groupId) {
        Map<String, Object> map = new HashMap<>();
        FileStatus fs = null;
        response.reset();
        {
            User user = new User();
            user.setId((Integer) request.getAttribute("id"));
            user.setUsername((String) request.getAttribute("username"));
            if (type == null) {
                map.put("errMsg", "参数不合法");
                map.put("code", -1);
            } else {
                Enum<HadoopServiceImpl.FileType> fileType = HadoopServiceImpl.FileType.getFileType(type);
                if (fileType == null) {
                    map.put("errMsg", "无法识别的类型");
                } else {
                    //先判断文件类型
                    if (fileType.equals(HadoopServiceImpl.FileType.publicFile)) {
                        //如果是群组文件且未输入群组Id
                        if (groupId == null) {
                            map.put("errMsg", "下载路径有误!!!");
                        } else {
                            //初始化权限
                            Group group = new Group(groupId);
                            //是否在群组中
                            AtomicReference<Boolean> flag = new AtomicReference<>(false);
                            try {
                                //遍历群组成员列表，如果在将slag设置为true
                                groupService.getGroupMember(group).forEach(v -> {
                                    if (v.equals(user))
                                        flag.set(true);
                                });
                            } catch (RuntimeException e) {
                                map.put("errMsg", e.getMessage());
                            }
                            if (!flag.get()) {
                                map.put("errMsg", "你不在当前群组中,无法对文件进行操作");
                            } else {
                                //如果是群主，可以随意下载文件----
                                if (groupService.getGroupOwner(group).equals(user)) {
                                    try {
                                        //获取文件基本信息
                                        fs = hadoopService.getFile(HadoopServiceImpl.HadoopUtil.amendPath(path[0], groupId, fileType));
                                        //设置响应
                                        response.setHeader("Content-Disposition", "attachment;filename=" + java.net.URLEncoder.encode(fs.getPath().getName(), "UTF-8"));
                                        response.addHeader("Content-Length", "" + fs.getLen());
                                        response.setContentType("application/octet-stream; charset=UTF-8");
                                        //下载文件
                                        hadoopService.download(HadoopServiceImpl.HadoopUtil.amendPath(path[0], groupId, fileType), response.getOutputStream());
                                        map.put("code", 0);
                                    } catch (IOException e) {
                                        map.put("errMsg", "下载异常");
                                    }
                                } else {
                                    //否则需要进行权限的确认
                                    Group.Data.Power power = new Group.Data.Power();
                                    try {
                                        //获取权限
                                        power = groupService.getPower(group, user);
                                    } catch (RuntimeException e) {
                                        map.put("errMsg", e.getMessage());
                                        map.put("code", -1);
                                    }
                                    //如果没用下载权限
                                    if (!power.isDownloadPower()) {
                                        map.put("errMsg", "没有权限进行下载操作");
                                    } else {
                                        //否则有权限
                                        try {
                                            //获取文件信息
                                            fs = hadoopService.getFile(HadoopServiceImpl.HadoopUtil.amendPath(path[0], groupId, fileType));
                                            //设置响应头
                                            response.setHeader("Content-Disposition", "attachment;filename=" + java.net.URLEncoder.encode(fs.getPath().getName(), "UTF-8"));
                                            response.addHeader("Content-Length", "" + fs.getLen());
                                            response.setContentType("application/octet-stream; charset=UTF-8");
                                            //下载文件
                                            hadoopService.download(HadoopServiceImpl.HadoopUtil.amendPath(path[0], groupId, fileType), response.getOutputStream());
                                            map.put("code", 0);
                                        } catch (IOException e) {
                                            map.put("errMsg", "下载异常");
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        //否则是个人文集
                        try {
                            //获取文件信息
                            for (int i = 0; i < path.length; i++) {
                                fs = hadoopService.getFile(HadoopServiceImpl.HadoopUtil.amendPath(path[0], user.getId(), fileType));
                                //设置响应头
                                response.setHeader("Content-Disposition", "attachment;filename=" + java.net.URLEncoder.encode(fs.getPath().getName(), "UTF-8"));
                                response.addHeader("Content-Length", "" + fs.getLen());
                                response.setContentType("application/octet-stream; charset=UTF-8");
                                //下载文件
                                hadoopService.download(HadoopServiceImpl.HadoopUtil.amendPath(path[0], user.getId(), fileType), response.getOutputStream());
                                map.put("code", 0);

                            }

                        } catch (IOException e) {
                            map.put("errMsg", "下载异常，文件可能已经被删除");
                        }
                    }
                }
            }
        }
        if (!map.containsKey("code")) {
            map.put("code", -1);
        }

        return new JSONObject(map);
    }

    /**
     * 文件查找/分类
     *
     * @param path:     要查找路径
     * @param request:
     * @param type:     文件类型  /1.私人文件 2.公共文件 3.回收站 4.共享文件 共享文件不走这个方法
     * @param keywords: 检索关键字
     * @param groupId   群组Id   type为1.3时不需要，type=2必须要有
     * @Date: 2021/8/16
     * @return: com.alibaba.fastjson.JSONObject
     * @Author: zwl
     */
    @RequestMapping(value = "/select")
    @ResponseBody
    public JSONObject select(String path, HttpServletRequest request, Integer type, @RequestParam(value = "keyword") String[] keywords, Integer groupId) {
        Map<String, Object> map = new HashMap<>();
        {
            User user = new User();
            user.setId(1);
            user.setId((Integer) request.getAttribute("id"));
            user.setUsername((String) request.getAttribute("username"));
            if (type == null || keywords == null || keywords.length == 0 || (type == 2 && groupId == null)) {
                map.put("errMsg", "参数不合法");
            } else {
                Enum<HadoopServiceImpl.FileType> fileType = HadoopServiceImpl.FileType.getFileType(type);
                if (fileType == null) {
                    map.put("errMsg", "无法识别的类型");
                } else if (fileType.equals(HadoopServiceImpl.FileType.publicFile)) {
                    //如果是群组文件
                    try {
                        //判断是否在群组中
                        if (!groupService.getGroupMember(new Group(groupId)).contains(user)) {
                            map.put("errMsg", "你不在这个群组中");
                        } else {
                            //获取符合条件的文件
                            List<HadoopServiceImpl.FileStatusUtil> list = new ArrayList<>();
                            for (String keyword : keywords) {
                                list.addAll(hadoopService.select(HadoopServiceImpl.HadoopUtil.amendPath(path, groupId, fileType), keyword,false));
                            }
                            if (list.size() < 1) {
                                map.put("errMsg", "没有符合条件的文件");
                            } else {
                                map.put("data", list);
                                map.put("code", 0);
                                map.put("message", "检索完成");
                            }
                        }
                    } catch (RuntimeException e) {
                        map.put("errMsg", e.getMessage());
                    } catch (IOException e) {
                        map.put("errMsg", "发生异常");
                    }
                } else {
                    //否则是个人文件
                    List<HadoopServiceImpl.FileStatusUtil> list = new ArrayList<>();
                    try {
                        //获取符合条件的文件
                        for (String keyword : keywords) {
                            list.addAll(hadoopService.select(HadoopServiceImpl.HadoopUtil.amendPath(path, groupId, fileType), keyword,false));
                        }
                    } catch (RuntimeException e) {
                        map.put("errMsg", e.getMessage());
                    } catch (FileNotFoundException e) {
                        map.put("errMsg", "文件不存在");
                    } catch (IOException e) {
                        map.put("errMsg", "发生异常");
                    }
                    if (list.size() < 1) {
                        map.put("errMsg", "没有符合条件的文件");
                    } else {
                        map.put("data", list);
                        map.put("code", 0);
                        map.put("message", "检索完成");
                    }

                }
            }

        }
        if (!map.containsKey("code")) {
            map.put("code", -1);
        }
        return new JSONObject(map);
    }

    /**
     * 文件找回
     *
     * @param path 要找回文件的路径
     * @return com.alibaba.fastjson.JSONObject
     * @author zwl
     * @date 2021/8/21
     **/
    @RequestMapping(value = "/reduction")
    @ResponseBody
    public JSONObject fileReduction(HttpServletRequest request, String path) {
        Map<String, Object> map = new HashMap<>();
        User user = new User();
        user.setId((Integer) request.getAttribute("id"));
        user.setUsername((String) request.getAttribute("username"));
        if (path == null || "".equals(path) || path.split("/").length != 2) {

        } else {
            //获取需找回文件的全路径
            String recycleBinFilePath = HadoopServiceImpl.HadoopUtil.amendPath(path, user.getId(), HadoopServiceImpl.FileType.recycleBin);
            try {
                if (hadoopService.reduction(recycleBinFilePath, user)) {
                    map.put("code", 0);
                    map.put("message", "还原成功");
                } else {
                    map.put("errMsg", "还原失败");
                }
            } catch (IOException e) {
                map.put("errMsg", "文件不存在");
            } catch (RuntimeException e) {
                map.put("errMSg", e.getMessage());
            }
        }

        if (!map.containsKey("code")) {
            map.put("code", -1);
        }
        return new JSONObject(map);
    }


   /* @RequestMapping(value = "/getShareFile")
    @ResponseBody
    public JSONObject getShareFile(String path,String code){
        RsaUtil.decrypt(path,RsaUtil.loadPrivateKeyFromFile(hadoopService.getFile()))
    }*/

    /*@RequestMapping(value = "/shareFile")
    @ResponseBody
    public JSONObject shareFile(String path,String code) throws Exception {
        Map<String, Object> map = new HashMap<>();
        User user=new User(1);
        path= HadoopServiceImpl.HadoopUtil.amendPath(path,user.getId(), HadoopServiceImpl.FileType.privateFile);
        System.out.println(rsaUtil.encrypt(path,rsaUtil.loadPublicKeyFromFile()));
        hadoopService.copyFile(path, HadoopServiceImpl.FileType.shareFile.getPath()+"/"+rsaUtil.encrypt(path,rsaUtil.loadPublicKeyFromFile()));
        return new JSONObject(map);
    }

    @RequestMapping(value = "/downShareFile")
    @ResponseBody
    public JSONObject downShareFile(String path,String code,HttpServletResponse response) throws Exception {
        Map<String, Object> map = new HashMap<>();
        User user=new User(1);
        response.setHeader("Content-Disposition", "attachment; filename=" + "12222.txt");
        response.addHeader("Content-Length", "" );
        response.setContentType("application/octet-stream; charset=UTF-8");
        hadoopService.download(HadoopServiceImpl.FileType.shareFile.getPath()+"/"+rsaUtil.decrypt(path,rsaUtil.loadPrivateKeyFromFile()),response.getOutputStream() );
        return new JSONObject(map);
    }*/

    /**
     * 分享文件
     *
     * @param path 分享的文件路径
     * @param code 提前码
     * @param date 过期时间
     * @return com.alibaba.fastjson.JSONObject
     * @author zwl
     * @date 2021/8/22
     **/
    @RequestMapping(value = "/shareFile")
    @ResponseBody
    public JSONObject shareFile(HttpServletRequest request, String path, String code, @RequestParam(value = "data") Date date) {
        Map<String, Object> map = new HashMap<>();
        if (date == null) {
            map.put("code", -1);
            map.put("errMsg", "参数不正确");
            return new JSONObject(map);
        }
        User user = new User();
        user.setId((Integer) request.getAttribute("id"));
        user.setUsername((String) request.getAttribute("username"));
        //获取文件的真实路径
        path = HadoopServiceImpl.HadoopUtil.amendPath(path, user.getId(), HadoopServiceImpl.FileType.privateFile);
        //初始化共享文件
        Share share = new Share();
        share.setCode(code);
        share.setUser(user);
        share.setShareFileName(path.substring(path.lastIndexOf("/")));
        share.setOverdueTime(date);
        try {
            //分享文件
            hadoopService.shareFile(path, share);
            map.put("code", 0);
            map.put("message", "分享成功，快把链接分享给你的好友把");
        } catch (IOException e) {
            map.put("errMsg", "分享出了一点小错误");
            map.put("code", -1);
        }

        return new JSONObject(map);
    }

    /**
     * 获取共享文件信息
     *
     * @param id   共享文件的Id
     * @param code 提取码
     * @return com.alibaba.fastjson.JSONObject
     * @author zwl
     * @date 2021/8/22
     **/
    @RequestMapping(value = "/getShareFile")
    @ResponseBody
    public JSONObject getShareFile(HttpServletRequest request, Integer id, String code) {
        Map<String, Object> map = new HashMap<>();
        if (id == null) {
            map.put("errMsg", "参数不正确");
            map.put("code", -1);
            return new JSONObject(map);
        }
        User user = new User();
        user.setId((Integer) request.getAttribute("id"));
        user.setUsername((String) request.getAttribute("username"));
        Share share = new Share();
        share.setId(id);
        share.setCode(code);
        try {
            //获取共享文件信息
            share = hadoopService.getShareFile(share);
            map.put("data", hadoopService.getFileStatus(HadoopServiceImpl.FileType.shareFile.getPath() + "/" + share.getId()));
            map.put("code", 0);
        } catch (RuntimeException e) {
            map.put("errMsg", e.getMessage());
        } catch (IOException e) {
            map.put("errMsg", "分享的文件不存在");
        }
        if (!map.containsKey("code")) {
            map.put("code", -1);
        }
        return new JSONObject(map);
    }

    /**
     * 下载共享文件
     *
     * @param id       共享文件Id
     * @param request  。。。
     * @param response ，。。
     * @return com.alibaba.fastjson.JSONObject
     * @author zwl
     * @date 2021/8/22
     **/
    @RequestMapping(value = "/downShareFile")
    @ResponseBody
    public JSONObject downShareFile(Integer id, HttpServletRequest request, HttpServletResponse response) throws Exception {
        Map<String, Object> map = new HashMap<>();
        User user = new User();
        user.setId((Integer) request.getAttribute("id"));
        user.setUsername((String) request.getAttribute("username"));
        //获取真实路径
        String path = HadoopServiceImpl.FileType.shareFile.getPath() + "/" + id;
        //获取共享文件列表
        List<HadoopServiceImpl.FileStatusUtil> fileStatusUtils = hadoopService.getFileStatus(path);
        //设置响应头
        response.setHeader("Content-Disposition", "attachment;filename=" + java.net.URLEncoder.encode(fileStatusUtils.get(0).getName(), "UTF-8"));
        response.addHeader("Content-Length", "" + fileStatusUtils.get(0).getLength());
        response.setContentType("application/octet-stream; charset=UTF-8");
        //下载共享文件  目前只支持一次下载一个文件
        hadoopService.download(HadoopServiceImpl.FileType.shareFile.getPath() + "/" + id, response.getOutputStream());
        return new JSONObject(map);
    }

    //废弃
    @RequestMapping(value = "/getRecycleBinFile")
    @ResponseBody
    public JSONObject getRecycleBinFile(HttpServletRequest request) {
        Map<String, Object> map = new HashMap<>();
        User user = new User();
        user.setId((Integer) request.getAttribute("id"));
        user.setUsername((String) request.getAttribute("username"));
        try {
            map.put("data", hadoopService.getFileStatus(HadoopServiceImpl.HadoopUtil.amendPath("/", user.getId(), HadoopServiceImpl.FileType.recycleBin)));
            map.put("code", 0);
            map.put("message", "成功");
        } catch (IOException e) {
            map.put("errMsg", "发生异常");
        }
        if (!map.containsKey("code")) {
            map.put("code", -1);
        }
        return new JSONObject(map);
    }

    @RequestMapping(value = "/fileClassify")
    @ResponseBody
    public JSONObject fileClassify(HttpServletRequest request,String[]types) {
        Map<String, Object> map = new HashMap<>();
        if (types==null||types.length==0){
            map.put("errMsg","参数异常");
            map.put("code",-1);
        }else {
            User user = new User();
            user.setId((Integer) request.getAttribute("id"));
            user.setUsername((String) request.getAttribute("username"));
            List<HadoopServiceImpl.FileStatusUtil> fileStatusUtilList=new ArrayList<>();
            for (String s:types){
                try {
                    fileStatusUtilList.addAll(hadoopService.select(HadoopServiceImpl.HadoopUtil.amendPath("/",user.getId(), HadoopServiceImpl.FileType.privateFile),s,true));
                } catch (IOException e) {
                    map.put("errMsg","文件异常");
                    map.put("code",-1);
                    return new JSONObject(map);
                }
            }
            map.put("code",0);
            map.put("message","分类完成");
            map.put("data",fileStatusUtilList);
        }

        return new JSONObject(map);
    }

    @RequestMapping(value = "/parsePath")
    @ResponseBody
    @PassToken
    public JSONObject parsePath(HttpServletRequest request,String path) {
        Map<String, Object> map = new HashMap<>();
        map.put("data",parsePath(path));
        return new JSONObject(map);
    }

    @PassToken
    private String[][] parsePath(String s){
        Map<String, Integer> map=new HashMap<>();
        if ("".equals(s))
            s="/";
        String s1=s;
        while (s1.contains("/")){
            map.put("num",map.containsKey("num")?map.get("num")+1:1);
            s1=s1.substring(s1.indexOf("/")+1);
        }
        String [][]ss=new String[map.getOrDefault("num", 1)][2];
        for (int i=0;i<ss.length;i++){
            ss[i][0]=s;
            ss[i][1]=s.substring(s.lastIndexOf("/")+1);
            s=s.substring(0,s.lastIndexOf("/"));
        }
        return ss;
    }

    //正式上线记得删除
    @RequestMapping(value = "/forceDeleteFile")
    @ResponseBody
    @PassToken
    public JSONObject forceDeleteFile(String path) throws IOException {
        Map<String, Object> map = new HashMap<>();
        hadoopService.completelyDelete(path);
        map.put("code",0);
        map.put("message","删除成功");
        return new JSONObject(map);
    }

    //正式上线记得删除
    @RequestMapping(value = "/forceDeleteRecycleBin")
    @ResponseBody
    @PassToken
    public JSONObject forceDeleteRecycleBin() throws IOException {
        Map<String, Object> map = new HashMap<>();
        hadoopService.completelyDelete(HadoopServiceImpl.FileType.recycleBin.getPath());
        map.put("code",0);
        map.put("message","删除成功");
        return new JSONObject(map);
    }
}
