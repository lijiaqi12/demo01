package com.example.group2.service;


import com.example.group2.pojo.RecycleBin;
import com.example.group2.pojo.Share;
import com.example.group2.pojo.User;
import com.example.group2.service.impl.HadoopServiceImpl;
import org.apache.hadoop.fs.FileStatus;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

public interface HadoopService {
    public FileStatus getFile(String path) throws IOException;

    public List<HadoopServiceImpl.FileStatusUtil> getFileStatus(String path) throws IOException;

    public boolean exists(String path) throws IOException;

    public boolean mkdir(String path) throws IOException;

    public boolean delete(String path) throws IOException;

    public boolean delete(RecycleBin recycleBin) throws IOException;

    public boolean reduction(String recyclePath, User user) throws IOException;

    public void completelyDelete(String path) throws IOException;

    public boolean update(String oldPath, String newPath) throws IOException;

    public void copyFile(String path,String copyPath) throws IOException;

    public void download(String path, OutputStream outputStream) throws IOException;

    public void upload(MultipartFile file, String path) throws IOException;

    public void upload(MultipartFile file, String path,boolean autoPath) throws IOException;

    public void upload(String s,String name, String path) throws IOException;

    public List<HadoopServiceImpl.FileStatusUtil> select(String path, String keyword,boolean type) throws IOException;

    public String readKey(String path) throws IOException;

    public void shareFile(String path,Share share) throws IOException;
    public Share getShareFile(Share share);


}
