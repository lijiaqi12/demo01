package com.example.group2.handlerInterceptor;

import com.alibaba.fastjson.JSONObject;
import com.example.group2.utils.JwtToken;
import io.jsonwebtoken.Claims;
import org.apache.commons.lang.StringUtils;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.Method;
import java.util.Map;

public class JWTInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // 如果不是映射到方法直接通过
        if (!(handler instanceof HandlerMethod)) {
            return true;
        }
        HandlerMethod handlerMethod = (HandlerMethod) handler;
        Method method = handlerMethod.getMethod();
        String xReq = request.getHeader("x-requested-with");
        String token;
        //检查是否有PassToken注释，有则跳过认证
        if (method.isAnnotationPresent(PassToken.class)) {
            PassToken passToken = method.getAnnotation(PassToken.class);
            if (passToken.required()) {
                return true;
            }
        }

        if (StringUtils.isNotBlank(xReq) && "XMLHttpRequest".equalsIgnoreCase(xReq)) {
            // 是ajax异步请求
            //获取请求头中的token令牌
            token = request.getHeader("token");
        } else {
            //获取表单中的token令牌
            token = request.getParameter("token");
        }
        Map<String, Object> map = JwtToken.checkToken(token);
        Claims claims = (Claims) map.get("claims");
        if ((int) map.get("code") == 0) {
            JSONObject jsonObject = JSONObject.parseObject(claims.getSubject());
            String username = jsonObject.getString("username");
            int id = Integer.parseInt(jsonObject.getString("id"));
            request.setAttribute("id", id);
            request.setAttribute("username", username);
            return true;
        } else {
            request.setAttribute("id", 1);
            response.setContentType("application/json;charset=UTF-8");
            response.getWriter().println(new JSONObject(map));
            response.addHeader("REDIRECT", "REDIRECT");
            response.addHeader("CONTEXTPATH", "login.html");
            response.addHeader("Access-Control-Expose-Headers", "REDIRECT,CONTEXTPATH");
        }
        return false;
    }
}
