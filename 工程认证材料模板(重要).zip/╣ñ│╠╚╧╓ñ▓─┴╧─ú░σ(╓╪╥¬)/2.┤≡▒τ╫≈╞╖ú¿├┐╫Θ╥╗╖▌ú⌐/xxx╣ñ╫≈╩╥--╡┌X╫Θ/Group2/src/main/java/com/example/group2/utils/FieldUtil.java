package com.example.group2.utils;

import java.lang.reflect.Field;

public class FieldUtil {
    public static String[] getFiledName(Object o) {
        Field[] fields = o.getClass().getDeclaredFields();
        String[] fieldNames = new String[fields.length];
        for (int i = 0; i < fields.length; i++) {
            fieldNames[i] = fields[i].getName();
        }
        return fieldNames;
    }

    public static Object getAttribute(Object o, String fieldName) throws NoSuchFieldException, IllegalAccessException {
        Field field = o.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.get(o);
    }

    public static void setAttribute(Object o, String fieldName, Object value) throws NoSuchFieldException, IllegalAccessException {
        Field field = o.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        if ("int".equals(field.getAnnotatedType().getType().getTypeName())) {
            value = Integer.parseInt(value.toString());
        } else if ("java.lang.String".equals(field.getAnnotatedType().getType().getTypeName())) {
            value = String.valueOf(value);
        } else if ("java.lang.Boolean".equals(field.getAnnotatedType().getType().getTypeName())) {
            //value=value;
        } else {
            String s = field.getAnnotatedType().getType().getTypeName();
            System.out.println(field.getAnnotatedType().getType());
            setAttribute(field, fieldName, value);
        }
        field.set(o, value);
    }
}
