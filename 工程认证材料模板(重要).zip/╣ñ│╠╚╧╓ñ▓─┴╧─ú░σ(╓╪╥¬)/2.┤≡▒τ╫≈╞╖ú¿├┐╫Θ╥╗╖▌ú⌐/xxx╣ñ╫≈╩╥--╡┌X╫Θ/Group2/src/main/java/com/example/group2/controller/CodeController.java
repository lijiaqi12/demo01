package com.example.group2.controller;


import com.alibaba.fastjson.JSONObject;
import com.example.group2.handlerInterceptor.PassToken;
import com.example.group2.pojo.User;
import com.example.group2.pojo.check.EmailCheck;
import com.example.group2.pojo.check.PhoneCheck;
import com.example.group2.utils.CodeUtil;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;


@Controller
@CrossOrigin(origins = "${netDisk.web.path}", allowedHeaders = "*", allowCredentials = "true")
public class CodeController {
    /**
     * 生成图形验证码，请求这个方法后会在请求的地方生成一张验证码图片
     * @param request 。。
     * @param response 。。
     * @author zwl
     * @date 2021/8/22
     **/
    @RequestMapping("/getTextCode")
    @ResponseBody
    @PassToken
    public void getLoginAndRegisterCode(HttpServletRequest request, HttpServletResponse response,String uuid) throws IOException {
        CodeUtil.createTextCode(request.getSession(),response,uuid);
    }

    /**
     * 发送手机验证码
     * @param user  user.phone 要发送的手机号
     * @param result 参数错误信息结果集
     * @return com.alibaba.fastjson.JSONObject
     * @author zwl
     * @date 2021/8/22
     **/
    @RequestMapping(value = "/sendPhoneCode")
    @ResponseBody
    @PassToken
    public JSONObject sendPhoneCode(@Validated(value = {PhoneCheck.class}) User user, BindingResult result) {
        Map<String, Object> map = new HashMap<>();
        if (result.hasErrors()) {
            //将错误信息添加进result中
            result.getAllErrors().forEach(v -> map.put("errMsg", map.containsKey("errMsg") ? map.get("errMsg") + " " + v.getDefaultMessage() : v.getDefaultMessage()));
        } else {
            try {
                //发送验证码
                CodeUtil.createPhoneCode(user.getPhone());
                map.put("code", 0);
                map.put("message", "发送成功");
            } catch (Exception e) {
                map.put("errMsg", "服务器开小差了,请稍后重新发送");
            }
        }
        if (!map.containsKey("code")) {
            map.put("code", -1);
        }
        return new JSONObject(map);
    }


    /**
     * 发送邮箱验证码
     * @param user  email 要发送的邮箱
     * @param result  参数错误信息结果集
     * @return com.alibaba.fastjson.JSONObject
     * @author zwl
     * @date 2021/8/22
     **/
    @RequestMapping(value = "/sendEmailCode")
    @ResponseBody
    @PassToken
    public JSONObject sendEmailCode(@Validated(value = {EmailCheck.class}) User user, BindingResult result) {
        Map<String, Object> map = new HashMap<>();
        if (result.hasErrors()) {
            //将错误信息添加进result中
            result.getAllErrors().forEach(v -> map.put("errMsg", map.containsKey("errMsg") ? map.get("errMsg") + " " + v.getDefaultMessage() : v.getDefaultMessage()));
        } else {
            try {
                //发送邮箱验证码
                CodeUtil.createEmailCode(user.getEmail());
                map.put("code", 0);
                map.put("message", "发送成功");
            } catch (Exception e) {
                map.put("errMsg", "服务器开小差了,请稍后重新发送");
            }
        }
        if (!map.containsKey("code")) {
            map.put("code", -1);
        }
        return new JSONObject(map);
    }
}
