package com.example.group2.service.impl;

import com.example.group2.dao.RecycleBinDao;
import com.example.group2.dao.ShareDao;
import com.example.group2.pojo.RecycleBin;
import com.example.group2.pojo.Share;
import com.example.group2.pojo.User;
import com.example.group2.service.HadoopService;
import com.example.group2.utils.SelfTimeUtil;
import org.apache.commons.io.IOUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.fs.permission.FsPermission;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.*;


@Service
public class HadoopServiceImpl implements HadoopService {
    private static final Configuration conf = new Configuration();

    //主机地址
    @Value(value = "${spring.hadoop.host}")
    private String host;

    //端口号
    @Value(value = "${spring.hadoop.port}")
    private String port;

    private long defaultStorageTime;

    //文件根路径
    private static String rootPath;

    //连接url
    private static String url;

    //私人空间根目录
    private static String privateRootPath;
    //共享空间根目录
    private static String publicRootPath;
    //回收站根目录
    private static String recycleBinRootPath;
    //用头像根目录
    private static String userProfilePictureRootPath;
    //用户分享文件根目录
    private static String shareRootPath;


    private static ShareDao shareDao;

    private static RecycleBinDao recycleBinDao;

    private static RedisTemplate<String, String> redisTemplate;

    @Autowired
    public void setUrl() {
        url = "hdfs://" + host + ":" + port;
    }

    @Value(value = "${spring.hadoop.fileRootPath}")
    public void setRootPath(String rootPath) {
        HadoopServiceImpl.rootPath = rootPath;
    }

    @Value(value = "${spring.hadoop.recycleBin.defaultStorageTime}")
    public void setDefaultStorageTime(String defaultStorageTime) {
        String []ss=defaultStorageTime.split("\\*");
        long defaultTime=1;
        for (String s:ss){
            defaultTime*=Integer.parseInt(s);
        }
        this.defaultStorageTime = defaultTime;
    }

    @Value(value = "${spring.hadoop.private.rootPath}")
    public void setPrivateRootPath(@Value(value = "${spring.hadoop.fileRootPath}") String rootPath, String privateRootPath) {
        HadoopServiceImpl.privateRootPath = rootPath + privateRootPath;
    }


    @Value(value = "${spring.hadoop.public.rootPath}")
    public void setPublicRootPath(@Value(value = "${spring.hadoop.fileRootPath}") String rootPath, String publicRootPath) {
        HadoopServiceImpl.publicRootPath = rootPath + publicRootPath;
    }

    @Value(value = "${spring.hadoop.recycleBin.rootPath}")
    public void setRecycleBinRootPath(@Value(value = "${spring.hadoop.fileRootPath}") String rootPath, String recycleBinRootPath) {
        HadoopServiceImpl.recycleBinRootPath = rootPath + recycleBinRootPath;
    }
    @Value(value = "${spring.hadoop.userProfilePicture.rootPath}")
    public void setUserProfilePictureRootPath(@Value(value = "${spring.hadoop.fileRootPath}") String rootPath, String userProfilePictureRootPath) {
        HadoopServiceImpl.userProfilePictureRootPath = rootPath + userProfilePictureRootPath;
    }

    @Value(value = "${spring.hadoop.shareRootPath.rootPath}")
    public void setShareRootPath(@Value(value = "${spring.hadoop.fileRootPath}") String rootPath,String shareRootPath) {
        HadoopServiceImpl.shareRootPath =rootPath+ shareRootPath;
    }

    @Autowired
    public void setRecycleBinDao(RecycleBinDao recycleBinDao) {
        HadoopServiceImpl.recycleBinDao = recycleBinDao;
    }

    @Autowired(required = false)
    public void setRedisTemplate(RedisTemplate<String, String> redisTemplate) {
        HadoopServiceImpl.redisTemplate = redisTemplate;
    }

    @Autowired
    public void setShareDao(ShareDao shareDao) {
        HadoopServiceImpl.shareDao = shareDao;
    }

    static {
        //设置副本数为2份
        conf.set("dfs.replication", "1");
        conf.set("dfs.client.use.datanode.hostname","true");
    }

    //获取hadoop连接
    public  FileSystem getFileSystem() {
        try {
            return FileSystem.get(URI.create(url), conf, "root");
        } catch (IOException | InterruptedException e) {
            System.out.println("hadoop连接异常");
            e.printStackTrace();
        }
        return null;
    }


    @Override
    public FileStatus getFile(String path) throws IOException {
        FileSystem fileSystem = getFileSystem();
        if (!fileSystem.exists(new Path(path))){
            throw new IOException("文件不存在");
        }
        //fileSystem.exists(new Path(path));
        return  fileSystem.getFileStatus(new Path(path));
    }

    @Override
    public List<FileStatusUtil> getFileStatus(String path) throws IOException {
        FileSystem fileSystem = getFileSystem();
        FileStatus[] fileStatuses = fileSystem.listStatus(new Path(path));
        List<FileStatusUtil> fileStatusUtils = new ArrayList<>();
        for (FileStatus fs:fileStatuses){
            fileStatusUtils.add(new FileStatusUtil(fs));
        }
        fileStatusUtils.sort((o1,o2)->o2.isDir?1: -(o1.isDir ? 1 : 0));
        fileSystem.close();
        return fileStatusUtils;
    }

    @Override
    public boolean exists(String path) throws IOException {
        FileSystem fileSystem = getFileSystem();
        boolean code= fileSystem.exists(new Path(path));
        fileSystem.close();
        return code;
    }

    @Override
    public boolean mkdir(String path) throws IOException {
        FileSystem fileSystem = getFileSystem();
        boolean code = fileSystem.mkdirs(new Path(path));
        fileSystem.close();
        return code;
    }

    @Override
    public boolean delete(String path) throws IOException {
        FileSystem fileSystem = getFileSystem();
        if ("/".equals(HadoopUtil.backAmendPath(path))||"".equals(HadoopUtil.backAmendPath(path)))
            throw new RuntimeException("不能删除根目录");
        if (!fileSystem.exists(new Path(path)))
            throw new RuntimeException("文件不存在,无法删除");
        boolean code=false;
        if (path.startsWith(FileType.publicFile.path)) {
            code = fileSystem.delete(new Path(path), true);
        } else if (path.startsWith(FileType.privateFile.path)) {
                  RecycleBin recycleBin=new RecycleBin();
                  recycleBin.setSize(fileSystem.getFileStatus(new Path(path)).getLen());
                  recycleBin.setUser(new User(HadoopUtil.getUserId(path)));
                  recycleBin.setOriginalAddress(path);
                  recycleBin.setDeleteFileName(path.substring(path.lastIndexOf("/")+1));
                  recycleBinDao.addDeleteRecord(recycleBin);
                String newPath=HadoopUtil.amendPath("/"+recycleBin.getId(),HadoopUtil.getUserId(path),FileType.recycleBin);
                code = update(path,newPath);
                if (code){
                    redisTemplate.boundZSetOps("recycleBin").add(newPath,System.currentTimeMillis()+defaultStorageTime);
                }
        } else if (path.startsWith(FileType.recycleBin.path)){
            RecycleBin recycleBin=new RecycleBin();
            recycleBin.setId(HadoopUtil.getUserId(path));
            code=fileSystem.delete(new Path(path),true);
            if (code){
                recycleBinDao.deleteRecycleRecord(recycleBin);
                redisTemplate.boundZSetOps("recycleBin").remove(path);
            }
        }
        fileSystem.close();
        return code;
    }

    @Override
    public boolean delete(RecycleBin recycleBin) throws IOException {
        FileSystem fileSystem = getFileSystem();
        recycleBin=recycleBinDao.select(recycleBin);
        if (recycleBin==null)
            throw new RuntimeException("回收站中没用这个文件");
        String path=HadoopUtil.amendPath(recycleBin.getOriginalAddress(),recycleBin.getUser().getId(),FileType.privateFile);
        boolean code = fileSystem.delete(new Path(path), true);
            if (code)
                recycleBinDao.deleteRecycleRecord(new RecycleBin(recycleBin.getId()));
            String []split=path.split(FileType.recycleBin.path, 2);
            if (split.length<2){
                mkdir(path);
            }else {
                String[] tempPath = split[1].split("/");
                if (tempPath.length == 1 || (tempPath.length == 2 && ("".equals(tempPath[0]) || "".equals(tempPath[1])))) {
                    mkdir(path);
                }
            }
        return code;
    }

    @Override
    public boolean reduction(String recyclePath, User user) throws IOException {
        RecycleBin recycleBin=new RecycleBin(Integer.parseInt(recyclePath.substring(recyclePath.lastIndexOf("/")+1)));
        recycleBin=recycleBinDao.select(recycleBin);
        if (recycleBin==null)
            throw new RuntimeException("文件不存在！！！");
        if (!recycleBin.getUser().equals(user))
            throw new RuntimeException("这不是你的文件！！！");
        boolean code=update(recyclePath,recycleBin.getOriginalAddress());
        if (code){
            recycleBinDao.deleteRecycleRecord(recycleBin);
            redisTemplate.boundZSetOps("recycleBin").remove(recyclePath);
        }
        return code;
    }

    @Override
    public void completelyDelete(String path) throws IOException {
        FileSystem fileSystem = getFileSystem();
        fileSystem.delete(new Path(path),true);
        fileSystem.close();
    }

    @Override
    public boolean update(String oldPath, String newPath) throws IOException {
        FileSystem fileSystem = getFileSystem();
        if (oldPath.equals(newPath))
            throw new RuntimeException("修改前后的文件一致,无法修改");
        if (!fileSystem.exists(new Path(oldPath)))
            throw new RuntimeException("文件不存在");

        String tempParentPath=HadoopUtil.getParentPath(newPath);
        if (!fileSystem.exists(new Path(tempParentPath))){
            mkdir(newPath);
        }
        String tempPath=newPath;
        if (newPath.startsWith(FileType.recycleBin.path)&&fileSystem.exists(new Path(newPath)))
            fileSystem.delete(new Path(newPath),true);
        for (int i=1;i<0x7fffffff;i++){
            if (!fileSystem.exists(new Path(newPath))){
                break;
            }else {
                newPath=tempPath+"("+i+")";
            }
        }
        boolean code = fileSystem.rename(new Path(oldPath), new Path(newPath));
        fileSystem.close();
        return code;
    }

    @Override
    public void copyFile(String path,String copyPath) throws IOException {
        FileSystem fileSystem = getFileSystem();
        Path tempPath=new Path(path);
        if (!fileSystem.exists(tempPath)){
            throw new IOException("文件不存在");
        }
        FSDataOutputStream out=fileSystem.create(new Path(copyPath));
        FSDataInputStream in=fileSystem.open(tempPath);
        int line=0;
        byte[] b =new byte[1024];
        while ((line=in.read(b))!=-1){
            out.write(b,0,line);
        }
        fileSystem.close();
    }

    @Override
    public void download(String path, OutputStream outputStream) throws IOException {
        FileSystem fileSystem = getFileSystem();
        FSDataInputStream fsInput = fileSystem.open(new Path(path));
        org.apache.hadoop.io.IOUtils.copyBytes(fsInput, outputStream, 4096, false);
        fsInput.close();
        outputStream.flush();
        outputStream.close();
        fileSystem.close();
    }

    @Override
    public void upload(MultipartFile file, String path) throws IOException {
        FileSystem fileSystem = getFileSystem();
        IOUtils.copy(file.getInputStream(), fileSystem.create(new Path(path + "/" + file.getOriginalFilename())));
        fileSystem.close();
    }

    @Override
    public void upload(MultipartFile file, String path, boolean autoPath) throws IOException {
        FileSystem fileSystem = getFileSystem();
        if (autoPath){
            IOUtils.copy(file.getInputStream(), fileSystem.create(new Path(path + "/" + file.getOriginalFilename())));
        }else {
            IOUtils.copy(file.getInputStream(), fileSystem.create(new Path(path)));

        }
        fileSystem.close();
    }

    @Override
    public void upload(String s,String name, String path) throws IOException {
        FileSystem fileSystem = getFileSystem();
        IOUtils.copy(new ByteArrayInputStream(s.getBytes(StandardCharsets.UTF_8)), fileSystem.create(new Path(path + "/" + name)));
        fileSystem.close();
    }

    @Override
    public List<FileStatusUtil> select(String path, String keyword,boolean type) throws IOException {
        FileSystem fileSystem = getFileSystem();
        RemoteIterator<LocatedFileStatus> iter = fileSystem.listFiles(new Path(path), true);
        List<FileStatusUtil> list = new ArrayList<>();
        if (!type){
            while (iter.hasNext()) {
                LocatedFileStatus fs = iter.next();
                if (fs.getPath().getName().contains(keyword)) {
                    list.add(new FileStatusUtil(fs));
                    fs.setPath(new Path(HadoopUtil.backAmendPath(fs.getPath().toString())));
                }
            }
        }else {
            while (iter.hasNext()) {
                LocatedFileStatus fs = iter.next();
                String fileName=fs.getPath().getName();
                if (fileName.contains(".")&&fileName.substring(fileName.lastIndexOf(".")).contains(keyword)) {
                    list.add(new FileStatusUtil(fs));
                    fs.setPath(new Path(HadoopUtil.backAmendPath(fs.getPath().toString())));
                }
            }
        }
        return list;

        /* 递归实现
        FileSystem fileSystem=getFileSystem();
        FileStatus []fs=fileSystem.listStatus(new Path(path));
        for (FileStatus f : fs) {
            if (f.isDirectory()){
                select(f.getPath().toString().split(url,2)[1], Keyword);
            }
            else if (!f.isDirectory()&&f.getPath().getName().contains(Keyword)){
                //此时f为所需文件
                System.out.println(f);
            }
        }
        return fs;*/
    }

    @Override
    public String readKey(String path) throws IOException {
        FileSystem fileSystem = getFileSystem();
        FSDataInputStream fsInput = fileSystem.open(new Path(path));
        byte[] bytes=new byte[1024];
        int line=0;
        StringBuilder stringBuilder=new StringBuilder();
        while ((line=fsInput.read(bytes))!=-1){
            stringBuilder.append(new String(bytes,0,line));
        }
        fileSystem.close();
        return  stringBuilder.toString();
    }

    @Override
    public void shareFile(String path,Share share) throws IOException {
        copyFile(path,shareRootPath+"/"+share.getId());
        shareDao.addShare(share);
    }

    @Override
    public Share getShareFile(Share share) {
        //先取出真实数据
        Share tempShare=shareDao.selectShare(share);
        //判断验证码是否正确
        if (tempShare.getCode()==null||tempShare.getCode().equals(share.getCode()))
            return tempShare;
        else
            throw new RuntimeException("验证码错误");
    }


    public static class HadoopUtil {
        /**
         * 将前端传递的路径修正
         *
         * @return 修正后的路径
         * @author zwl
         * @date 2021/8/15 12:14
         * @Param: path  修正前的路径
         * @Param: id   用户编号
         * @Param: fileType 浏览类型  //privateFile:私人空间  publicFile:公共空间  recycleBin:回收站
         */
        public static String amendPath(String path, int id, Enum<FileType> fileType) {
            if (path == null || "".equals(path)) {
                path = "/";
            }
            path=path.replace(" "," ");
            if (path.contains("//")||path.contains("///")){
                path=path.replace("///","/");
                path=path.replace("//","/");
            }
            if (!path.contains("/") || path.indexOf("/") > 0)
                throw new RuntimeException("路径格式不正确");
            if (fileType.equals(FileType.publicFile)) {
                if (id == 0) {
                    return FileType.getPath(fileType) + "/";
                }
                return FileType.getPath(fileType) + "/" + id + path;
            }
            return FileType.getPath(fileType) + "/" + id + path;
        }

        /**
         * 将前端传递的路径修正并获取上一级目录
         *
         * @return 修正后的路径
         * @author zwl
         * @date 2021/8/15 12:14
         * @Param: path  修正前的路径
         * @Param: id   用户编号
         * @Param: fileType 浏览类型  //privateFile:私人空间  publicFile:公共空间  recycleBin:回收站
         */
        public static String amendParentPath(String path, int id, Enum<FileType> fileType) {
            if (fileType.equals(FileType.recycleBin))
                throw new RuntimeException("回收站只有一个目录");
            if (fileType.equals(FileType.shareFile))
                throw new RuntimeException("分享文件没用这个目录");
            path=path.replace(" "," ");
            if (path.contains("//")||path.contains("///")){
                path=path.replace("///","/");
                path=path.replace("//","/");
            }
            if (fileType.equals(FileType.publicFile)) {
                path = (FileType.getPath(fileType) + "/" + id + path);
                if (id == 0) {
                    return FileType.getPath(fileType);
                } else if ("/".equals(path)) {
                    return FileType.getPath(fileType) + "/" + id;
                }
                return path.substring(0, path.lastIndexOf("/"));
            }
            if ("/".equals(path))
                return FileType.getPath(fileType) + "/" + id;
            path = (FileType.getPath(fileType) + "/" + id + path);
            return path.substring(0, path.lastIndexOf("/"));
        }

        /**
         * 将路径剔除部分后返回
         *
         * @return 剔除后的路径
         * @author zwl
         * @date 2021/8/15 12:14
         * @Param: path  完整路径
         */
        public static String backAmendPath(String path) {
            path=path.replace(" "," ");
            if (path.startsWith(url)) {
                path = path.split(url, 2)[1];
            }
            if (path.startsWith(FileType.shareFile.path)){
                path = path.split(FileType.shareFile.path, 2)[1];
            }else {
                    for (FileType ft : FileType.values()) {
                        if (path.startsWith(ft.path)) {
                            path = path.split(FileType.getPath(ft), 2)[1];
                            path = path.substring(path.indexOf("/") + 1);
                            path = path.substring(path.indexOf("/"));
                        }
                    }

            }
            return path;
        }

        /**
         * 获取移动后的路径  //群组文件没有该功能
         * 私人空间->回收站  回收站->私人空间  私人空间->公共空间 ...
         *
         * @return 移动后的路径
         * @author zwl
         * @date 2021/8/16 1:48
         * @Param: path 完整路径
         * @Param: newType 移动后的文件类型  //privateFile:私人空间  publicFile:公共空间  recycleBin:回收站
         */
        public static String getMovePath(String path, Enum<FileType> newType) throws IOException {
            FileSystem fs=new HadoopServiceImpl().getFileSystem();
            path=path.replace(" "," ");
            String[] temp = {"", ""};
            for (FileType ft : FileType.values()) {
                if (path.startsWith(ft.path)) {
                    if (ft.equals(FileType.recycleBin)){
                        path=path.split(FileType.recycleBin.path)[1];
                        if (path.split("/").length>2)
                            throw new RuntimeException("路径获取异常,请联系管理员");
                        path=path.substring(path.indexOf("/")+1);
                        RecycleBin recycleBin=new RecycleBin(Integer.parseInt(path));
                        recycleBin=recycleBinDao.select(recycleBin);
                        temp[1]=recycleBin.getOriginalAddress().split(FileType.privateFile.path)[1];
                    }else {
                        temp = path.split(FileType.getPath(ft), 2);
                        if ("".equals(temp[0])) {
                            break;
                        }
                    }
                }
            }
            if ("".equals(temp[1]))
                throw new RuntimeException("路径获取异常,请联系管理员");
            String tempPath=FileType.getPath(newType) + temp[1];
            for (int i = 1; i < 0x7fffffff; i++) {
                if (fs.exists(new Path(tempPath))) {
                    tempPath = FileType.getPath(newType)+temp[1] + "(" + i + ")";
                } else {
                    break;
                }
            }
            return tempPath;
        }

        public static Enum<FileType> getFileType(String path){
            for (FileType ft:FileType.values()){
                if (path.startsWith(ft.path))
                    return ft;
            }
            return null;
        }

        public static int getUserId(String path){
            path=path.replace(" "," ");
            int userId;
            if (path.startsWith(url)) {
                path = path.split(url, 2)[1];
            }
            if (path.startsWith(FileType.shareFile.path)){
                return 0;
            }else {
                for (FileType ft:FileType.values()){
                    if (path.startsWith(ft.path)){
                        path=path.split(ft.path,2)[1];
                        break;
                    }
                }
                path=path.split("/")[1];
            }
            try {
                userId=Integer.parseInt(path);
            }catch (NumberFormatException e){
                throw new RuntimeException("路径异常");
            }
            return userId;
        }
        /**
         * 获取对象中不为null的属性
         * * @param  一个对象
         *
         * @return 不为null的字段
         * @author zwl
         * @date 2021/8/17
         **/
        public static String[] getNotNullPropertyNames(Object source) {
            final BeanWrapper src = new BeanWrapperImpl(source);
            java.beans.PropertyDescriptor[] pds = src.getPropertyDescriptors();

            Set<String> emptyNames = new HashSet<>();
            for (java.beans.PropertyDescriptor pd : pds) {
                Object srcValue = src.getPropertyValue(pd.getName());
                if (srcValue != null && !pd.getName().equals("class")) emptyNames.add(pd.getName());
            }
            String[] result = new String[emptyNames.size()];
            return emptyNames.toArray(result);
        }

        // /**/*/xx/yy/zz  /xx
        public static String getParentPath(String path) {
            return path.substring(0, path.lastIndexOf("/"));
        }



    }

    public static class FileStatusUtil implements Serializable {

        private int id;
        private String path;
        private String realPath;
        private String name;
        private long length;
        private boolean isDir;
        private short block_replication;
        private long blockSize;
        private String modification_time;
        private String access_time;
        private FsPermission permission;
        private String owner;
        private String group;
        private Path symlink;

        public String getRealPath() {
            return realPath;
        }

        public void setRealPath(String realPath) {
            this.realPath = realPath;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getPath() {
            return path;
        }

        public void setPath(String path) {
            this.path = path;
        }

        public long getLength() {
            return length;
        }

        public void setLength(long length) {
            this.length = length;
        }

        public boolean isDir() {
            return isDir;
        }

        public void setDir(boolean dir) {
            isDir = dir;
        }

        public short getBlock_replication() {
            return block_replication;
        }

        public void setBlock_replication(short block_replication) {
            this.block_replication = block_replication;
        }

        public long getBlockSize() {
            return blockSize;
        }

        public void setBlockSize(long blockSize) {
            this.blockSize = blockSize;
        }

        public String getModification_time() {
            return modification_time;
        }

        public void setModification_time(String modification_time) {
            this.modification_time = modification_time;
        }

        public String getAccess_time() {
            return access_time;
        }

        public void setAccess_time(String access_time) {
            this.access_time = access_time;
        }

        public FsPermission getPermission() {
            return permission;
        }

        public void setPermission(FsPermission permission) {
            this.permission = permission;
        }

        public String getOwner() {
            return owner;
        }

        public void setOwner(String owner) {
            this.owner = owner;
        }

        public String getGroup() {
            return group;
        }

        public void setGroup(String group) {
            this.group = group;
        }

        public Path getSymlink() {
            return symlink;
        }

        public void setSymlink(Path symlink) {
            this.symlink = symlink;
        }

        public FileStatusUtil(FileStatus fileStatus) throws IOException {

            realPath=fileStatus.getPath().toString();
            path = HadoopServiceImpl.HadoopUtil.backAmendPath(fileStatus.getPath().toString());
            if (fileStatus.getPath().toString().split(url,2)[1].startsWith(FileType.shareFile.path)){
                Share share=new Share();
                String path=fileStatus.getPath().toString().split(FileType.shareFile.path,2)[1];
                path=path.substring(path.indexOf("/")+1);
                if (path.contains("/")){
                    this.path=path.split("/",2)[0];
                    path=this.path;
                }
                int id=Integer.parseInt(path);
                share.setId(id);
                share=shareDao.selectShare(share);
                name=share.getShareFileName();
            }else  if (!fileStatus.getPath().toString().split(url,2)[1].startsWith(FileType.recycleBin.path)){
                name=fileStatus.getPath().getName();
            }

            length = fileStatus.getLen();
            isDir = fileStatus.isDirectory();
            block_replication = fileStatus.getReplication();
            blockSize = fileStatus.getBlockSize();
            modification_time = SelfTimeUtil.stampToTime(String.valueOf(fileStatus.getModificationTime()));
            access_time = SelfTimeUtil.stampToTime(String.valueOf(fileStatus.getAccessTime()));
            permission = fileStatus.getPermission();
            owner = fileStatus.getOwner();
            group = fileStatus.getGroup();
            symlink = fileStatus.isSymlink() ? fileStatus.getSymlink() : null;
            if (fileStatus.getPath().toString().split(url,2)[1].startsWith(FileType.recycleBin.path)){
                RecycleBin recycleBin=new RecycleBin();
                recycleBin.setId(Integer.parseInt(path.substring(path.lastIndexOf("/")+1)));
                recycleBin=recycleBinDao.select(recycleBin);
                if (recycleBin==null)
                    throw new RuntimeException("数据异常");
                name=recycleBin.getDeleteFileName();
                //删除时间
                access_time=SelfTimeUtil.formatTime(recycleBin.getDeleteTime());
                Double d=redisTemplate.boundZSetOps("recycleBin").score(fileStatus.getPath().toString().split(url,2)[1]);
                if (d!=null){
                    long time=d.longValue()-System.currentTimeMillis();
                    modification_time=time/24/60/60/1000>1?time/24/60/60/1000+" 天":time/60/60/1000>1?time/60/60/1000+" 小时":time/60/1000>1?time/60/1000+" 分钟":time/1000>0?time/1000+" 秒":"已到期";
                }else {
                    modification_time="0 天";
                }
                //过期时间

            }

        }


    }

    public enum FileType {
        privateFile(1, privateRootPath), publicFile(2, publicRootPath), recycleBin(3, recycleBinRootPath),
        shareFile(4,shareRootPath),userProfilePicture(5,userProfilePictureRootPath);
        private final int id;
        private final String path;

        FileType(int id, String path) {
            this.id = id;
            this.path = path;
        }

        public int getId() {
            return id;
        }

        public String getUrl() {
            return url;
        }

        public String getPath() {
            return path;
        }

        public static String getPath(Enum<FileType> type) {
            for (FileType fileType : FileType.values()) {
                if (fileType.equals(type)) {
                    return fileType.path;
                }
            }
            return "null";
        }

        public static String getPath(int id) {
            for (FileType fileType : FileType.values()) {
                if (fileType.id == id) {
                    return fileType.path;
                }
            }
            return "null";
        }

        public static Enum<FileType> getFileType(int id) {
            for (FileType fileType : FileType.values()) {
                if (fileType.id == id) {
                    return fileType;
                }
            }
            return null;
        }
    }
}
