package com.example.group2.service;

import com.example.group2.pojo.RecycleBin;
import com.example.group2.pojo.User;

import java.util.List;

public interface RecycleBinService {

    public User getFileOwner(RecycleBin recycleBin);
    public List<String> getFilePath(RecycleBin recycleBin);
}
