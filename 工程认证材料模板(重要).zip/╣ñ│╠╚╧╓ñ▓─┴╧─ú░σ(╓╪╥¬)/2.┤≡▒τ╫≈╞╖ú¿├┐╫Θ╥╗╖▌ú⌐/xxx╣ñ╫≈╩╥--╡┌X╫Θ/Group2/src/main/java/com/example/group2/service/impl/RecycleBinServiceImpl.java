package com.example.group2.service.impl;

import com.example.group2.dao.RecycleBinDao;
import com.example.group2.pojo.RecycleBin;
import com.example.group2.pojo.User;
import com.example.group2.service.HadoopService;
import com.example.group2.service.RecycleBinService;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;

import static java.util.concurrent.TimeUnit.SECONDS;

@Service
@Log4j2
public class RecycleBinServiceImpl implements RecycleBinService {

    private static long autoCleanTime;
    private static RedisTemplate<String, String> redisTemplate;
    private static HadoopService hadoopService;
    private static final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
    private static RecycleBinDao recycleBinDao;


    @Autowired
    public void setRecycleBinDao(RecycleBinDao recycleBinDao) {
        RecycleBinServiceImpl.recycleBinDao = recycleBinDao;
    }


    @Override
    public User getFileOwner(RecycleBin recycleBin) {
        recycleBin=recycleBinDao.select(recycleBin);
        if (recycleBin==null)
            throw new RuntimeException("文件不存在");
        return recycleBin.getUser();
    }

    @Override
    //废弃
    public List<String> getFilePath(RecycleBin recycleBin) {
        List<String> paths= new ArrayList<>();
        recycleBinDao.findFileByUser(recycleBin).forEach(v->paths.add("/"+v.getId()));
        return paths;
    }


    public static void setAutoCleanTime() {
        String autoCleanTime= ResourceBundle.getBundle("application").getString("spring.hadoop.recycleBin.autoCleanTime");
        String []ss=autoCleanTime.split("\\*");
        long autoTime=1;
        for (String s:ss){
            autoTime*=Integer.parseInt(s);
        }
        RecycleBinServiceImpl.autoCleanTime = autoTime/1000>0?autoTime/1000:1;
    }

    @Autowired
    public void setRedisTemplate(RedisTemplate<String, String> redisTemplate) {
        RecycleBinServiceImpl.redisTemplate = redisTemplate;
    }

    @Autowired
    public void setHadoopService(HadoopService hadoopService) {
        RecycleBinServiceImpl.hadoopService = hadoopService;
    }

    static {
        setAutoCleanTime();
        final int[] count = {1};
        final Runnable beeper = () -> {
            log.info("第"+ count[0] +"次回收站清理开始");
            Set<String> list;
            if (redisTemplate.hasKey("recycleBin")) {
                list= redisTemplate.boundZSetOps("recycleBin").rangeByScore(0, System.currentTimeMillis());
                if (list!=null){
                    int num=list.size();
                    log.info("本次共有"+num+"个需要清理的文件");
                    list.forEach(v-> {
                        try {
                            hadoopService.completelyDelete(v);
                            redisTemplate.boundZSetOps("recycleBin").remove(v);
                            recycleBinDao.deleteRecycleRecord(new RecycleBin(HadoopServiceImpl.HadoopUtil.getUserId(v)));
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    });
                    log.info("清理完成，本次共清理"+ num +"个文件");
                }
            }else {
                log.info("回收站空空如也");
            }
            count[0]++;
        };

        final ScheduledFuture<?> beeperHandle =
                //command–要执行的任务   initialDelay–延迟第一次执行的时间  period–连续执行之间的周期  unit–initialDelay和period参数的时间单位
                scheduler.scheduleAtFixedRate(beeper, 10, autoCleanTime, SECONDS);
        scheduler.schedule(() -> { beeperHandle.cancel(true); }, 20*365*24*60*60, SECONDS);
    }
}
