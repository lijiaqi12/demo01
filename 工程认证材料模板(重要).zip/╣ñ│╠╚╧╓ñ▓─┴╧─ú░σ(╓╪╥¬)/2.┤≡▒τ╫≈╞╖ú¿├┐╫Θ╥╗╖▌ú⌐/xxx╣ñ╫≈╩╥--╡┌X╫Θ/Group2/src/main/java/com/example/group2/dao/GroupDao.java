package com.example.group2.dao;

import com.example.group2.pojo.Group;
import com.example.group2.pojo.User;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.mapping.FetchType;

import java.util.List;

@Mapper
public interface GroupDao {
    @Update("UPDATE `group` SET data=#{data} WHERE id=#{id} LIMIT 1")
    public void updateData(Group group);

    @Update("UPDATE `group` SET name=#{name} WHERE id=#{id} LIMIT 1")
    public void updateName(Group group);

    @Update("UPDATE `group` SET code=#{code} WHERE id=#{id} LIMIT 1")
    public void updateCode(Group group);

    @Select("SELECT * FROM `group` WHERE id=#{id}")
    @Result(column = "founder_id", property = "founder", one = @One(select = "com.example.group2.dao.UserDao.findUserById", fetchType = FetchType.EAGER))
    public Group select(Group group);

    @Select("SELECT * FROM `group` WHERE founder_id=#{founder.id}")
    @Result(column = "founder_id", property = "founder", one = @One(select = "com.example.group2.dao.UserDao.findUserById", fetchType = FetchType.EAGER))
    public List<Group> selectByFounderId(Group group);

    @Select("SELECT * FROM `group` ")
    @Result(column = "founder_id", property = "founder", one = @One(select = "com.example.group2.dao.UserDao.findUserById", fetchType = FetchType.EAGER))
    public List<Group> getAllGroup();

    @Insert("INSERT INTO `group` (founder_id,data,name,code)VALUES(#{founder.id},#{data,typeHandler=org.apache.ibatis.type.BlobTypeHandler},#{name},#{code})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    //@Result(property="data", column="data",jdbcType = JdbcType.BLOB,typeHandler = BlobTypeHandler.class)
    public void addGroup(Group group);

    @Select("SELECT * FROM `group` WHERE id=#{id}")
    public User getGroupOwner(Group group);

    @Delete("DELETE FROM `group` WHERE id=#{id} LIMIT 1")
    public void dismissGroup(Group group);

}
