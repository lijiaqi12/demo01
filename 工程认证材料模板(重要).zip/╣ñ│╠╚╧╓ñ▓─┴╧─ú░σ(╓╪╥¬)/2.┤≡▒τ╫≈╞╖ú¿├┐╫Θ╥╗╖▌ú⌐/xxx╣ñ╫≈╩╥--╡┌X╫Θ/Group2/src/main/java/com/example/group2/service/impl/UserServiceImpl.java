package com.example.group2.service.impl;

import com.example.group2.dao.UserDao;
import com.example.group2.pojo.User;
import com.example.group2.service.UserService;
import com.example.group2.utils.CodeUtil;
import com.example.group2.utils.SHAEncryptUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class UserServiceImpl implements UserService {

    private UserDao userDao;
    private SHAEncryptUtil shaEncryptUtil;

    @Autowired
    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }

    @Autowired
    public void setShaEncryptUtil(SHAEncryptUtil shaEncryptUtil) {
        this.shaEncryptUtil = shaEncryptUtil;
    }

    @Override
    public void userRegister(User user) {
        if (userDao.findUserByUsername(user) != null) {
            throw new RuntimeException("用户已经存在");
        } else if (userDao.findUserByPhone(user) != null) {
            throw new RuntimeException("手机号已经被注册");
        } else if (userDao.findUserByEmail(user) != null) {
            throw new RuntimeException("邮箱已经注册");
        } else {
            //添加用户前先对密码进行加密处理
            user.setPassword(shaEncryptUtil.encryptPwd(user.getPassword()));
            userDao.addUser(user);
        }
    }


    @Override
    public User login(User user) {
        //先将用户真实数据从数据库取出
        User userInfo = userDao.findUserByUsername(user);
        if (userInfo == null)
            throw new RuntimeException("用户不存在");
        //将用户输入的密码与真实密码比对,验证通过返回用户数据,不通过返回null
        return shaEncryptUtil.validatePwd(user.getPassword(), userInfo.getPassword()) ? userInfo : null;
    }

    @Override
    public User fastLogin(User user, String code) {
        //先将用户真实数据从数据库取出
        User userInfo = userDao.findUser(user);
        if (userInfo == null)
            throw new RuntimeException("用户不存在");
        //先判断用户手机号是不是空的,是则进行邮箱验证码的验证,否则进行手机验证码的验证,验证成功返回用户数据,失败返回null.
        return "".equals(user.getPhone()) ?
                CodeUtil.codeCheck(user.getEmail(), code, CodeUtil.CodeTypeEnum.EMAIL_CODE) ? userInfo : null :
                CodeUtil.codeCheck(user.getPhone(), code, CodeUtil.CodeTypeEnum.PHONE_CODE) ? userInfo : null;
    }

    @Override
    public User getUserData(User user) {
        return userDao.findUserById(user);
    }

    @Override
    public void resetPassword(User user, String code) {
        //先将用户真实数据从数据库取出

        if ("".equals(user.getPhone())) {
            User userInfo = userDao.findUserByEmail(user);
            if (userInfo == null)
                throw new RuntimeException("用户不存在");
            if (CodeUtil.codeCheck(user.getEmail(), code, CodeUtil.CodeTypeEnum.EMAIL_CODE)) {
                user.setPassword(shaEncryptUtil.encryptPwd(user.getPassword()));
                user.setId(userInfo.getId());
                userDao.updatePassword(user);
            } else {
                throw new RuntimeException("验证码错误或已过期");
            }
        } else {
            User userInfo = userDao.findUserByPhone(user);
            if (userInfo == null)
                throw new RuntimeException("用户不存在");
            if (CodeUtil.codeCheck(userInfo.getPhone(), code, CodeUtil.CodeTypeEnum.PHONE_CODE)) {
                user.setPassword(shaEncryptUtil.encryptPwd(user.getPassword()));
                user.setId(userInfo.getId());
                userDao.updatePassword(user);
            } else {
                throw new RuntimeException("验证码错误或已过期");
            }
        }
    }

    @Override
    public void alterPassword(User user, String newPwd) {
        //先将用户真实数据从数据库取出
        User userInfo = userDao.findUserByUsername(user);
        if (userInfo == null)
            throw new RuntimeException("用户不存在");
        user = login(user);
        if (user == null)
            throw new RuntimeException("输入的密码不正确");
        user.setPassword(shaEncryptUtil.encryptPwd(newPwd));
        userDao.updatePassword(user);
    }

    @Override
    public void updateHeadImage(User user) {
        userDao.updateHeadImage(user);
    }

    @Override
    public void updateUserInfo(User user) {
        if ((user.getEmail()==null&&user.getNickname()==null)||("".equals(user.getNickname())&&"".equals(user.getEmail())))
            userDao.emptyUserInfo(user);
        else
            userDao.updateUserInfo(user);
    }
}
