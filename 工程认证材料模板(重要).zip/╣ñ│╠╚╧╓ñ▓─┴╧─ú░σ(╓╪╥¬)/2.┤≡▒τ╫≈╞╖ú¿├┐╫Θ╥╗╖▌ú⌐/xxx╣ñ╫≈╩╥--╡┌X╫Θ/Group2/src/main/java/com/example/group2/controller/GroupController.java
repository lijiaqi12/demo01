package com.example.group2.controller;

import com.alibaba.fastjson.JSONObject;
import com.example.group2.pojo.Group;
import com.example.group2.pojo.Sign;
import com.example.group2.pojo.User;
import com.example.group2.service.GroupService;
import com.example.group2.service.HadoopService;
import com.example.group2.service.SignService;
import com.example.group2.service.impl.HadoopServiceImpl;
import com.example.group2.utils.FieldUtil;
import com.example.group2.utils.SelfTimeUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.*;

@Controller
@CrossOrigin(origins = "${netDisk.web.path}", allowedHeaders = "*", allowCredentials = "true")
public class GroupController {
    private GroupService groupService;

    private HadoopService hadoopService;
    private SignService signService;

    @Autowired
    public void setGroupService(GroupService groupService) {
        this.groupService = groupService;
    }

    @Autowired
    public void setHadoopService(HadoopService hadoopService) {
        this.hadoopService = hadoopService;
    }

    @Autowired
    public void setSignService(SignService signService) {
        this.signService = signService;
    }

    /**
     * 获取群组信息，包括群主和所有成员
     *
     * @param group id：群组Id
     * @return com.alibaba.fastjson.JSONObject
     * @author zwl
     * @date 2021/8/22
     **/
    @RequestMapping(value = "/getGroupInfo")
    @ResponseBody
    public JSONObject getGroupInfo(Group group) {
        Map<String, Object> map = new HashMap<>();

        if (group == null || group.getId() == 0)
            map.put("errMsg", "参数不合法");
        try {
            //获取群组信息
            group = groupService.getGroupInfo(group);
        } catch (RuntimeException e) {
            map.put("errMsg", e.getMessage());
            map.put("code", -1);
            return new JSONObject(map);
        }
        Map<String, Object> data = new HashMap<>();
        data.put("group", group);
        data.put("owner", groupService.getGroupOwner(group));
        data.put("friends", groupService.getGroupFriends(group));
        map.put("data", data);
        map.put("code", 0);
        return new JSONObject(map);
    }

    /**
     * 创建群组
     *
     * @param request 请求中携带的用户ID
     * @param code 邀请码
     * @param name 群名称
     * @return com.alibaba.fastjson.JSONObject
     * @author zwl
     * @date 2021/8/22
     **/
    @RequestMapping(value = "/createGroup")
    @ResponseBody
    public JSONObject createGroup(HttpServletRequest request,String name,String code) {
        Map<String, Object> map = new HashMap<>();
        User user = new User();
        user.setId((Integer) request.getAttribute("id"));
        user.setUsername((String) request.getAttribute("username"));
        //创建一个群组
        Group group = new Group(groupService.createGroup(user,name,code));
        if (group.getId() < 1) {
            map.put("errMsg", "创建群组失败");
        } else {
            //获取群组专属文件目录
            String path = HadoopServiceImpl.FileType.getPath(HadoopServiceImpl.FileType.publicFile) + "/" + group.getId();
            try {
                //生成群组专属目录
                hadoopService.mkdir(path);
                map.put("data", hadoopService.getFileStatus(path));
            } catch (IOException e) {
                map.put("errMsg", "创建群组共享文件失败，请重新尝试创建");
                groupService.dismissGroup(group, user);
            }
            map.put("code", 0);
            map.put("message", "创建成功");
        }
        if (!map.containsKey("code")) {
            map.put("code", -1);
        }
        return new JSONObject(map);
    }

    /**
     * 给群组用户授权
     *
     * @param request      请求中的用户信息
     * @param authorizedId 被授权人Id
     * @param groupId      授权的群组Id
     * @param empowerList  权限列表    uploadPower 上传权限  downloadPower 下载权限  mkdirPower 创建文件夹权限 deletePower 删除权限  updatePower 修改文件权限 都是boolean类型，true代表可以操作
     * @return com.alibaba.fastjson.JSONObject
     * @author zwl
     * @date 2021/8/22
     **/
    @RequestMapping(value = "/empower")
    @ResponseBody
    public JSONObject empower(HttpServletRequest request, Integer authorizedId, Integer groupId, Power empowerList) throws NoSuchFieldException, IllegalAccessException {
        Map<String, Object> map = new HashMap<>();
        User user = new User();
        user.setId((Integer) request.getAttribute("id"));
        user.setUsername((String) request.getAttribute("username"));
        if (authorizedId == null) {
            map.put("errMsg", "必须有一个被授权用户!!!");
        } else if (user.getId() == authorizedId) {
            map.put("errMsg", "不能给自己授权");
        } else {
            //初始化群组
            Group group = new Group(groupId);
            User creator;
            try {
                //获取群组创始人信息
                creator = groupService.getGroupOwner(group);
            } catch (RuntimeException e) {
                map.put("errMsg", e.getMessage());
                map.put("code", -1);
                return new JSONObject(map);
            }
            if (!creator.equals(user)) {
                map.put("errMsg", "只有群组创建者才可以授权");
            } else {
                //获取群员列表
                List<User> list = new ArrayList<>(groupService.getGroupMember(group));
                //初始化被授权用户
                User authorized = new User(authorizedId);
                //如果授权的用户不在群组中
                if (!list.contains(authorized)) {
                    map.put("errMsg", "要授权的用户不在当前群组中");
                } else {
                    Group.Data.Power power;
                    try {
                        //获取原始权限列表
                        power = groupService.getPower(group, authorized);
                    } catch (RuntimeException e) {
                        map.put("errMsg", e.getMessage());
                        map.put("code", -1);
                        return new JSONObject(map);
                    }
                    //获取前端传递的权限列表中不为null的属性
                    String[] ss = HadoopServiceImpl.HadoopUtil.getNotNullPropertyNames(empowerList);
                    for (String s : ss) {
                        Field field = power.getClass().getDeclaredField(s);
                        //设置可访问
                        field.setAccessible(true);
                        //将原始权限设置为新的权限
                        field.set(power, FieldUtil.getAttribute(empowerList, s));
                    }
                    //授权
                    groupService.setPower(group, authorized, power);
                    map.put("code", 0);
                    map.put("message", "授权成功");
                }

            }
        }
        if (!map.containsKey("code")) {
            map.put("code", -1);
        }
        return new JSONObject(map);
    }

    /**
     * 加入群组
     *
     * @param request ..
     * @param groupId ..要加入的群组Id
     * @param code    输入的邀请码
     * @return com.alibaba.fastjson.JSONObject
     * @author zwl
     * @date 2021/8/17
     **/
    @RequestMapping(value = "/joinGroup")
    @ResponseBody
    public JSONObject joinGroup(HttpServletRequest request,String code, Integer groupId) {
        Map<String, Object> map = new HashMap<>();
        User user = new User();
        user.setId((Integer) request.getAttribute("id"));
        user.setUsername((String) request.getAttribute("username"));
        Group group=new Group(groupId);
        group.setCode(code);
        try {
            //加入群组    1.要加入的群组  2.加入的用户 3.初始权限
            groupService.joinGroup(group, user, new Group.Data.Power());
            map.put("code", 0);
            map.put("message", "加入成功");
        } catch (RuntimeException e) {
            map.put("errMsg", e.getMessage());
        }

        if (!map.containsKey("code")) {
            map.put("code", -1);
        }
        return new JSONObject(map);
    }

    /**
     * 退出群组
     *
     * @param request ..
     * @param groupId ..要退出的群组Id
     * @return com.alibaba.fastjson.JSONObject
     * @author zwl
     * @date 2021/8/17
     **/
    @RequestMapping(value = "/exitGroup")
    @ResponseBody
    public JSONObject exitGroup(HttpServletRequest request, Integer groupId) {
        Map<String, Object> map = new HashMap<>();
        User user = new User();
        user.setId((Integer) request.getAttribute("id"));
        user.setUsername((String) request.getAttribute("username"));
        try {
            groupService.exitGroup(new Group(groupId), user);
            map.put("code", 0);
            map.put("message", "退出成功");
        } catch (RuntimeException e) {
            map.put("errMsg", e.getMessage());
        }

        if (!map.containsKey("code")) {
            map.put("code", -1);
        }
        return new JSONObject(map);
    }

    /**
     * 解散群组
     *
     * @param request 请求中的用户信息
     * @param groupId 群组Id
     * @return com.alibaba.fastjson.JSONObject
     * @author zwl
     * @date 2021/8/22
     **/
    @RequestMapping(value = "/dismissGroup")
    @ResponseBody
    public JSONObject dismissGroup(HttpServletRequest request, Integer groupId) {
        Map<String, Object> map = new HashMap<>();
        User user = new User();
        user.setId((Integer) request.getAttribute("id"));
        user.setUsername((String) request.getAttribute("username"));
        Group group = new Group(groupId);
        User creator;
        try {
            //获取群组创始人
            creator = groupService.getGroupOwner(group);
        } catch (RuntimeException e) {
            map.put("errMsg", e.getMessage());
            map.put("code", -1);
            return new JSONObject(map);
        }
        if (!creator.equals(user)) {
            map.put("errMsg", "只有群组创建者才可以解散");
        } else {
            try {
                //解散群组
                groupService.dismissGroup(group, user);
                //清除群组共享文件
                hadoopService.completelyDelete(HadoopServiceImpl.HadoopUtil.amendPath("/", groupId, HadoopServiceImpl.FileType.publicFile));
                map.put("code", 0);
                map.put("message", "解散成功");
            } catch (RuntimeException e) {
                map.put("errMsg", e.getMessage());
            } catch (IOException e) {
                map.put("errMsg", "发生了一个错误");
            }
        }

        if (!map.containsKey("code")) {
            map.put("code", -1);
        }
        return new JSONObject(map);
    }

    @RequestMapping(value = "/initiateSign")
    @ResponseBody
    public JSONObject initiateSign(HttpServletRequest request, Integer groupId,@RequestParam(value = "date") Date endTime){
        Map<String, Object> map = new HashMap<>();
        if (groupId==null||groupId==0||endTime==null|| endTime.getTime()<System.currentTimeMillis()){
            map.put("errMsg","参数不合法");
        }else {
            User user = new User();
            user.setId((Integer) request.getAttribute("id"));
            user.setUsername((String) request.getAttribute("username"));
            Group group = new Group(groupId);
            Sign sign=new Sign();
            sign.setGroup(group);
            sign.setEndTime(endTime);
            try {
                signService.createSignInfo(sign,user);
                map.put("code",0);
                map.put("message","发起签到成功");
            }catch (RuntimeException e){
                map.put("errMsg",e.getMessage());
            }
        }
        if (!map.containsKey("code")) {
            map.put("code", -1);
        }
        return new JSONObject(map);
    }
    @RequestMapping(value = "/sign")
    @ResponseBody
    public JSONObject sign(HttpServletRequest request,Integer signId){
        Map<String, Object> map = new HashMap<>();
        User user = new User();
        user.setId((Integer) request.getAttribute("id"));
        user.setUsername((String) request.getAttribute("username"));
        Sign sign=new Sign(signId);
        try {
            signService.sign(sign,user);
            map.put("code",0);
            map.put("message","签到成功");
            map.put("data",signService.getGroupAllSignInfo(signService.getSignInfo(sign)));
        }catch (RuntimeException e){
            map.put("errMsg",e.getMessage());
            map.put("code",-1);
        }
        if (!map.containsKey("code")) {
            map.put("code", -1);
        }
        return new JSONObject(map);
    }

    @RequestMapping(value = "/getSignDetails")
    @ResponseBody
    public JSONObject getSignDetails(HttpServletRequest request,Integer signId){
        Map<String, Object> map = new HashMap<>();
        if (signId==null||signId==0){
            map.put("errMsg","参数错误");
        }else {
            User user = new User();
            user.setId((Integer) request.getAttribute("id"));
            user.setUsername((String) request.getAttribute("username"));
            Sign sign=new Sign(signId);
            try {
                map.put("data",signService.getFriendsSignInfo(sign));
                map.put("code",0);
                map.put("message","获取成功");
            }catch (RuntimeException e){
                map.put("errMsg",e.getMessage());
                map.put("code",-1);
            }
        }
        if (!map.containsKey("code")) {
            map.put("code", -1);
        }
        return new JSONObject(map);
    }


    @RequestMapping(value = "/getUserAllSign")
    @ResponseBody
    public JSONObject getUserAllSign(HttpServletRequest request){
        Map<String, Object> map = new HashMap<>();
            User user = new User();
            user.setId((Integer) request.getAttribute("id"));
            user.setUsername((String) request.getAttribute("username"));
            try {
                map.put("data",signService.getUserAllSignInfo(user));
                map.put("code",0);
                map.put("message","获取成功");
            }catch (RuntimeException e){
                map.put("errMsg",e.getMessage());
                map.put("code",-1);
            }
        return new JSONObject(map);
    }
    public static class Power {
        //上传权限
        private Boolean uploadPower=false;
        //下载权限
        private Boolean downloadPower=false;
        //创建文件夹权限
        private Boolean mkdirPower=false;
        //删除权限
        private Boolean deletePower=false;
        //修改权限
        private Boolean updatePower=false;

        public Boolean getUploadPower() {
            return uploadPower;
        }

        public void setUploadPower(Boolean uploadPower) {
            this.uploadPower = uploadPower;
        }

        public Boolean getDownloadPower() {
            return downloadPower;
        }

        public void setDownloadPower(Boolean downloadPower) {
            this.downloadPower = downloadPower;
        }

        public Boolean getMkdirPower() {
            return mkdirPower;
        }

        public void setMkdirPower(Boolean mkdirPower) {
            this.mkdirPower = mkdirPower;
        }

        public Boolean getDeletePower() {
            return deletePower;
        }

        public void setDeletePower(Boolean deletePower) {
            this.deletePower = deletePower;
        }

        public Boolean getUpdatePower() {
            return updatePower;
        }

        public void setUpdatePower(Boolean updatePower) {
            this.updatePower = updatePower;

        }


    }
}
