package com.example.group2.utils;

import com.example.group2.pojo.User;
import com.example.group2.service.HadoopService;
import com.sun.org.apache.xml.internal.security.utils.Base64;
import javax.crypto.Cipher;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;

import java.io.*;
import java.security.*;
import java.util.Arrays;

@Log4j2

public class RsaUtil {




    public static final String KEY_ALGORITHM_AES = "RSA";
    public static final String KEY_ALGORITHM_AES_PCKS1PADDING = "RSA/ECB/PKCS1PADDING";
    public static final String SIGNATURE_ALGORITHM = "MD5withRSA";
    private static final int MAX_ENCRYPT_BLOCK = 117;
    private static final int MAX_DECRYPT_BLOCK = 256;
    @Value("${spring.hadoop.PublicKey.Path}")
    private String pubPath;
    @Value("${spring.hadoop.PrivateKey.Path}")
    private String priPath;
    @Autowired
    private HadoopService hadoopService;

    //用户ID占用位数
    public static final int length=20;

    private static RedisTemplate<String,String> redisTemplate;

    @Autowired
    public void setRedisTemplate(RedisTemplate<String, String> redisTemplate) {
        RsaUtil.redisTemplate = redisTemplate;
    }

    @Autowired
    public void setPubPath(@Value("${spring.hadoop.fileRootPath}") String rootPath) {
        this.pubPath = rootPath+pubPath;
    }
    @Autowired
    public void setPriPath(@Value("${spring.hadoop.fileRootPath}") String rootPath) {
        this.priPath = rootPath+priPath;
    }
   // @Autowired
   /* public void setHadoopService(HadoopService hadoopService) {
        this.hadoopService = hadoopService;
    }*/


    /*public RsaUtil()  {
        try {
            //每次重启服务器都会生成新的key
            generateKeyToFile(pubPath,priPath);
        } catch (Exception e) {
            log.error("Rsa公密钥创建失败");
        }
    }*/

    /*@Autowired
    public void init()  {
        try {
            //每次重启服务器都会生成新的key
            generateKeyToFile(pubPath,priPath);
        } catch (Exception e) {
            log.error("Rsa公密钥创建失败");
        }
    }*/


    /**
     * 生成密钥对并保存在本地文件中
     *
     * @param pubPath   : 公钥保存路径
     * @param priPath   : 私钥保存路径
     * @throws Exception
     */
    public  void generateKeyToFile(String pubPath, String priPath) throws Exception {
        // 获取密钥对生成器
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance(KEY_ALGORITHM_AES);
        // 获取密钥对
        KeyPair keyPair = keyPairGenerator.generateKeyPair();
        // 获取公钥
        PublicKey publicKey = keyPair.getPublic();
        // 获取私钥
        PrivateKey privateKey = keyPair.getPrivate();
        // 获取byte数组
        byte[] publicKeyEncoded = publicKey.getEncoded();
        byte[] privateKeyEncoded = privateKey.getEncoded();

        // 进行Base64编码
        String publicKeyString = Base64.encode(publicKeyEncoded);
        String privateKeyString = Base64.encode(privateKeyEncoded);

        //hadoopService.upload(publicKeyString,"/pub.pem",pubPath);
        //hadoopService.upload(privateKeyString,"/pri.pem",priPath);

        // 保存文件
        //FileUtils.writeStringToFile(new File(pubPath), publicKeyString, StandardCharsets.UTF_8);
        //FileUtils.writeStringToFile(new File(priPath), privateKeyString, StandardCharsets.UTF_8);

    }

    /**
     * 生成密钥对并保存在redis中
     *User  创始人
     * @throws Exception 。。
     */
    public  void generateKey(User user) throws Exception {
        // 获取密钥对生成器
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance(KEY_ALGORITHM_AES);
        // 获取密钥对
        KeyPair keyPair = keyPairGenerator.generateKeyPair();
        // 获取公钥
        PublicKey publicKey = keyPair.getPublic();
        // 获取私钥
        PrivateKey privateKey = keyPair.getPrivate();
        // 获取byte数组
        byte[] publicKeyEncoded = publicKey.getEncoded();
        byte[] privateKeyEncoded = privateKey.getEncoded();
        System.out.println(Arrays.toString(publicKeyEncoded));
        System.out.println(Arrays.toString(privateKeyEncoded));
        // 进行Base64编码
        String publicKeyString = Base64.encode(publicKeyEncoded);
        String privateKeyString = Base64.encode(privateKeyEncoded);
        StringBuilder id= new StringBuilder(String.valueOf(user.getId()));
        while (id.length()<length){
            id.insert(0, "0");
        }
        redisTemplate.boundHashOps("shareKey").put(publicKeyString, id +privateKeyString);
    }
    /**
     * 从文件中加载公钥
     *
     * @return : 公钥
     * @throws Exception
     */
   /* public  PublicKey loadPublicKeyFromFile() throws Exception {

        // 将文件内容转为字符串
        //String keyString = FileUtils.readFileToString(new File(filePath), StandardCharsets.UTF_8);

        //return loadPublicKeyFromString(keyString);
        //return loadPublicKeyFromString(hadoopService.readKey(pubPath+"/pub.pem"));

    }*/

    /**
     * 从字符串中加载公钥
     *
     * @param keyString : 公钥字符串
     * @return : 公钥
     * @throws Exception
     */
    /*public  PublicKey loadPublicKeyFromString(String keyString) throws Exception {
        // 进行Base64解码
        byte[] decode = Base64.decode(keyString);
        // 获取密钥工厂
        KeyFactory keyFactory = KeyFactory.getInstance(KEY_ALGORITHM_AES);
        // 构建密钥规范
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(decode);
        // 获取公钥
        return keyFactory.generatePublic(keySpec);

    }*/

    /**
     * 从文件中加载私钥
     *
     * @return : 私钥
     * @throws Exception
     */
    /*public  PrivateKey loadPrivateKeyFromFile() throws Exception {
        // 将文件内容转为字符串

        //String keyString = FileUtils.readFileToString(new File(filePath), StandardCharsets.UTF_8);
        //return loadPrivateKeyFromString(keyString);

        System.out.println("privateKey:"+hadoopService.readKey(priPath+"/pri.pem"));
        return loadPrivateKeyFromString(hadoopService.readKey(priPath+"/pri.pem"));
    }*/

    /**
     * 从字符串中加载私钥
     *
     * @param keyString : 私钥字符串
     * @return : 私钥
     * @throws Exception
     */
    /*public  PrivateKey loadPrivateKeyFromString(String keyString) throws Exception {
        //剔除用户名
        keyString=keyString.substring(length);
        // 进行Base64解码
        byte[] decode = Base64.decode(keyString);
        // 获取密钥工厂
        KeyFactory keyFactory = KeyFactory.getInstance(RsaUtil.KEY_ALGORITHM_AES);
        // 构建密钥规范
        PKCS8EncodedKeySpec keyspec = new PKCS8EncodedKeySpec(decode);
        // 生成私钥
        return keyFactory.generatePrivate(keyspec);

    }*/

    /**
     * 使用密钥加密数据
     *
     * @param input          : 原文
     * @param key            : 密钥
     * @return : 密文
     * @throws Exception
     */
    /*public  String encrypt(String input, Key key) throws Exception {
        // 获取Cipher对象
        Cipher cipher = Cipher.getInstance(RsaUtil.KEY_ALGORITHM_AES);
        // 初始化模式(加密)和密钥
        cipher.init(Cipher.ENCRYPT_MODE, key);
        // 将原文转为byte数组
        byte[] data = input.getBytes();
        // 总数据长度
        int total = data.length;
        // 输出流
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        decodeByte(RsaUtil.MAX_ENCRYPT_BLOCK, cipher, data, total, baos);
        // 对密文进行Base64编码
        return Base64.encode(baos.toByteArray());

    }*/

    /**
     * 解密数据
     *
     * @param encrypted      : 密文
     * @param key            : 密钥
     * @return : 原文
     * @throws Exception
     */
    /*public  String decrypt(String encrypted, Key key) throws Exception {
        // 获取Cipher对象
        Cipher cipher = Cipher.getInstance(RsaUtil.KEY_ALGORITHM_AES);
        // 初始化模式(解密)和密钥
        cipher.init(Cipher.DECRYPT_MODE, key);
        // 由于密文进行了Base64编码, 在这里需要进行解码
        byte[] data = Base64.decode(encrypted);
        // 总数据长度
        int total = data.length;
        // 输出流
        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        decodeByte(MAX_DECRYPT_BLOCK, cipher, data, total, baos);
        // 输出原文
        return baos.toString();

    }*/

    /**
     * 分段处理数据
     *
     * @param maxSize : 最大处理能力
     * @param cipher  : Cipher对象
     * @param data    : 要处理的byte数组
     * @param total   : 总数据长度
     * @param baos    : 输出流
     * @throws Exception
     */
    private static void decodeByte(int maxSize, Cipher cipher, byte[] data, int total, ByteArrayOutputStream baos) throws Exception {
        // 偏移量
        int offset = 0;
        // 缓冲区
        byte[] buffer;
        // 如果数据没有处理完, 就一直继续
        while (total - offset > 0) {
            // 如果剩余的数据 >= 最大处理能力, 就按照最大处理能力来加密数据
            if (total - offset >= maxSize) {
                // 加密数据
                buffer = cipher.doFinal(data, offset, maxSize);
                // 偏移量向右侧偏移最大数据能力个
                offset += maxSize;
            } else {
                // 如果剩余的数据 < 最大处理能力, 就按照剩余的个数来加密数据
                buffer = cipher.doFinal(data, offset, total - offset);
                // 偏移量设置为总数据长度, 这样可以跳出循环
                offset = total;
            }
            // 向输出流写入数据
            baos.write(buffer);
        }
    }


}