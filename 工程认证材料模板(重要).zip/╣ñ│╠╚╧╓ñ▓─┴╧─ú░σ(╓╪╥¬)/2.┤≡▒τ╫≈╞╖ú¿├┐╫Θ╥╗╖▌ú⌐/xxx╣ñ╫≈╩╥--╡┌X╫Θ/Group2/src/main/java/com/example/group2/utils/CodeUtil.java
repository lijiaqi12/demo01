package com.example.group2.utils;

import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import javax.imageio.ImageIO;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;
import java.util.*;
import java.util.concurrent.TimeUnit;

@Component
public class CodeUtil {

    private static SendEmail sendEmail;

    //手机验证相关属性
    private static String APPCODE;
    private static String TEMPLATE_ID;
    private static Boolean LOGIN_CODE_OPEN;
    private static RedisTemplate<String, String> redisTemplate;
    //文本验证码相关属性
    private final int w = 70;
    private final int h = 35;
    private final Random r = new Random();
    private final String[] fontNames = new String[]{"宋体", "华文楷体", "黑体", "微软雅黑", "楷体_GB2312"};
    private final String codes = "23456789abcdefghjkmnopqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ";
    private final Color bgColor = new Color(255, 255, 255);
    private String text;


    @Value(value = "${user.appcode}")
    public void setAPPCODE(String APPCODE) {
        CodeUtil.APPCODE = APPCODE;
    }

    @Value(value = "${aLiBaBa.template.id}")
    public void setTemplateId(String templateId) {
        TEMPLATE_ID = templateId;
    }

    @Value(value = "${code.switch}")
    public void setLoginCodeOpen(Boolean loginCodeOpen) {
        LOGIN_CODE_OPEN = loginCodeOpen;
    }

    @Autowired
    public void setRedisTemplate(RedisTemplate<String, String> redisTemplate) {
        CodeUtil.redisTemplate = redisTemplate;
    }

    @Autowired
    public void setSendEmail(SendEmail sendEmail) {
        CodeUtil.sendEmail = sendEmail;
    }

    private Color randomColor() {
        int red = this.r.nextInt(150);
        int green = this.r.nextInt(150);
        int blue = this.r.nextInt(150);
        return new Color(red, green, blue);
    }

    private Font randomFont() {
        int index = this.r.nextInt(this.fontNames.length);
        String fontName = this.fontNames[index];
        int style = this.r.nextInt(4);
        int size = this.r.nextInt(5) + 24;
        return new Font(fontName, style, size);
    }

    private void drawLine(BufferedImage image) {
        int num = 3;
        Graphics2D g2 = (Graphics2D) image.getGraphics();

        for (int i = 0; i < num; ++i) {
            int x1 = this.r.nextInt(this.w);
            int y1 = this.r.nextInt(this.h);
            int x2 = this.r.nextInt(this.w);
            int y2 = this.r.nextInt(this.h);
            g2.setStroke(new BasicStroke(1.5F));
            g2.setColor(Color.BLUE);
            g2.drawLine(x1, y1, x2, y2);
        }

    }

    private char randomChar() {
        int index = this.r.nextInt(this.codes.length());
        return this.codes.charAt(index);
    }

    private BufferedImage createImage() {
        BufferedImage image = new BufferedImage(this.w, this.h, 1);
        Graphics2D g2 = (Graphics2D) image.getGraphics();
        g2.setColor(this.bgColor);
        g2.fillRect(0, 0, this.w, this.h);
        return image;
    }

    public BufferedImage getImage() {
        BufferedImage image = this.createImage();
        Graphics2D g2 = (Graphics2D) image.getGraphics();
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < 4; ++i) {
            String s = this.randomChar() + "";
            sb.append(s);
            float x = (float) i * 1.0F * (float) this.w / 4.0F;
            g2.setFont(this.randomFont());
            g2.setColor(this.randomColor());
            g2.drawString(s, x, (float) (this.h - 5));
        }

        this.text = sb.toString();
        this.drawLine(image);
        return image;
    }

    public String getText() {
        return this.text;
    }

    public static void output(BufferedImage image, OutputStream out) throws IOException {
        ImageIO.write(image, "JPEG", out);
    }


    /**
     * @author zwl
     * @date 2021/8/14 15:17
     * @Param: receiveMailAccount 收件人邮箱
     */
    public synchronized static void createEmailCode(String receiveMailAccount) throws Exception {
        //SendEmail sendEmail = new SendEmail();
        sendEmail.setReceiveMailAccount(receiveMailAccount);
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 6; i++) {
            sb.append(random.nextInt(10));
        }
        sendEmail.setInfo(sb.toString());
        sendEmail.Send();
        System.out.println(sb);
        redisTemplate.boundValueOps(CodeTypeEnum.EMAIL_CODE + "_" + receiveMailAccount).set(sb.toString(), 300, TimeUnit.SECONDS);
    }


    public static void createTextCode(HttpSession session, HttpServletResponse response,String uuid) throws IOException {
        CodeUtil ver = new CodeUtil();
        BufferedImage img = ver.getImage();
        ServletOutputStream out = response.getOutputStream();
        response.setContentType("image/jpeg");
        output(img, out);
        //session.setAttribute(CodeTypeEnum.TEXT_CODE.toString(), ver.getText());
        redisTemplate.boundValueOps(CodeTypeEnum.TEXT_CODE +"_"+uuid).set(ver.getText(), 10, TimeUnit.MINUTES);
        //System.out.println(redisTemplate.boundValueOps(session.getId()).get());
    }

    public static void createPhoneCode(String phone) {
        String host = "https://dfsns.market.alicloudapi.com";
        String path = "/data/send_sms";
        String method = "POST";
        Map<String, String> headers = new HashMap<String, String>();
        //最后在header中的格式(中间是英文空格)为Authorization:APPCODE 83359fd73fe94948385f570e3c139105
        headers.put("Authorization", "APPCODE " + APPCODE);
        //根据API的要求，定义相对应的Content-Type
        headers.put("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
        Map<String, String> querys = new HashMap<String, String>();
        Map<String, String> bodys = new HashMap<String, String>();
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 6; i++) {
            sb.append(random.nextInt(10));
        }
        bodys.put("content", "code:" + sb);
        bodys.put("phone_number", phone);
        bodys.put("template_id", TEMPLATE_ID);


        try {
            /**
             * 重要提示如下:
             * HttpUtils请从
             * https://github.com/aliyun/api-gateway-demo-sign-java/blob/master/src/main/java/com/aliyun/api/gateway/demo/util/HttpUtils.java
             * 下载
             *
             * 相应的依赖请参照
             * https://github.com/aliyun/api-gateway-demo-sign-java/blob/master/pom.xml
             */
            HttpResponse response = HttpUtils.doPost(host, path, method, headers, querys, bodys);
            System.out.println(response.toString());
            System.out.println(sb);
            //获取response的body
            System.out.println(EntityUtils.toString(response.getEntity()));
            redisTemplate.boundValueOps(CodeTypeEnum.PHONE_CODE + "_" + phone).set(sb.toString(), 300, TimeUnit.SECONDS);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    /*public static boolean codeCheck(String uuid, String code, Enum<CodeTypeEnum> codeType) {
        if (!LOGIN_CODE_OPEN) {
            return true;
        }
        return code != null &&
                codeType != null &&
                redisTemplate.hasKey(codeType + "_" + uuid ) &&
                code.equalsIgnoreCase(redisTemplate.boundValueOps(codeType + "_" +uuid ).get());
    }*/

    public static boolean codeCheck(String phone, String code, Enum<CodeTypeEnum> codeType) {
        if (!LOGIN_CODE_OPEN) {
            return true;
        }
        return code != null &&
                codeType != null &&
                phone != null &&
                redisTemplate.hasKey(codeType + "_" + phone) &&
                code.equalsIgnoreCase(redisTemplate.boundValueOps(codeType + "_" + phone).get());
    }

    @Component
    static class SendEmail {
        //发件人的邮箱和授权码
        @Value("${myEmailAccount}")
        private String myEmailAccount; //发送的邮箱
        @Value("${myEmailPassword}")
        private String myEmailPassword;//填写自己的授权码;

        private String receiveMailAccount;
        private String info;

        //设置收件人
        public void setReceiveMailAccount(String receiveMailAccount) {
            this.receiveMailAccount = receiveMailAccount;
        }

        //设置信息内容
        public void setInfo(String info) {
            this.info = info;
        }

        // 发件人邮箱的 SMTP 服务器地址, 必须准确, 不同邮件服务器地址不同, 一般(只是一般, 绝非绝对)格式为: smtp.xxx.com
        // 网易163邮箱的 SMTP 服务器地址为: smtp.163.com    腾讯: smtp.qq.com
        private final String myEmailSMTPServer = "smtp.qq.com";

        public void Send() throws Exception {
            // 1. 创建参数配置, 用于连接邮件服务器的参数配置
            Properties props = new Properties();                    // 参数配置
            props.setProperty("mail.transport.protocol", "smtp");   // 使用的协议（JavaMail规范要求）
            props.setProperty("mail.smtp.host", myEmailSMTPServer);   // 发件人的邮箱的 SMTP 服务器地址
            props.setProperty("mail.smtp.auth", "true");            // 需要请求认证
            // PS: 某些邮箱服务器要求 SMTP 连接需要使用 SSL 安全认证 (为了提高安全性, 邮箱支持SSL连接, 也可以自己开启),
            //     如果无法连接邮件服务器, 仔细查看控制台打印的 log, 如果有有类似 “连接失败, 要求 SSL 安全连接” 等错误,
            //     打开下面 /* ... */ 之间的注释代码, 开启 SSL 安全连接。

            // SMTP 服务器的端口 (非 SSL 连接的端口一般默认为 25, 可以不添加, 如果开启了 SSL 连接,
            //                  需要改为对应邮箱的 SMTP 服务器的端口, 具体可查看对应邮箱服务的帮助,
            //                  QQ邮箱的SMTP(SLL)端口为465或587, 其他邮箱自行去查看)
            final String smtpPort = "465";
            props.setProperty("mail.smtp.port", smtpPort);
            props.setProperty("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
            props.setProperty("mail.smtp.socketFactory.fallback", "false");
            props.setProperty("mail.smtp.socketFactory.port", smtpPort);


            // 2. 根据配置创建会话对象, 用于和邮件服务器交互
            Session session = Session.getDefaultInstance(props);
            session.setDebug(false);                                 // 设置为debug模式, 可以查看详细的发送 log

            // 3. 创建一封邮件
            MimeMessage message = createMessage(session, myEmailAccount, receiveMailAccount, info);

            // 4. 根据 Session 获取邮件传输对象
            Transport transport = session.getTransport();

            // 5. 使用 邮箱账号 和 密码 连接邮件服务器, 这里认证的邮箱必须与 message 中的发件人邮箱一致, 否则报错
            //
            //    PS_01: 成败的判断关键在此一句, 如果连接服务器失败, 都会在控制台输出相应失败原因的 log,
            //           仔细查看失败原因, 有些邮箱服务器会返回错误码或查看错误类型的链接, 根据给出的错误
            //           类型到对应邮件服务器的帮助网站上查看具体失败原因。
            //
            //    PS_02: 连接失败的原因通常为以下几点, 仔细检查代码:
            //           (1) 邮箱没有开启 SMTP 服务;
            //           (2) 邮箱密码错误, 例如某些邮箱开启了独立密码;
            //           (3) 邮箱服务器要求必须要使用 SSL 安全连接;
            //           (4) 请求过于频繁或其他原因, 被邮件服务器拒绝服务;
            //           (5) 如果以上几点都确定无误, 到邮件服务器网站查找帮助。
            //
            //    PS_03: 仔细看log, 认真看log, 看懂log, 错误原因都在log已说明。
            transport.connect(myEmailAccount, myEmailPassword);

            // 6. 发送邮件, 发到所有的收件地址, message.getAllRecipients() 获取到的是在创建邮件对象时添加的所有收件人, 抄送人, 密送人
            transport.sendMessage(message, message.getAllRecipients());

            // 7. 关闭连接
            transport.close();
        }

        /**
         * 创建一封只包含文本的简单邮件
         *
         * @param session     和服务器交互的会话
         * @param sendMail    发件人邮箱
         * @param receiveMail 收件人邮箱
         * @return
         * @throws Exception
         */
        public MimeMessage createMessage(Session session, String sendMail, String receiveMail, String info) throws Exception {
            // 1. 创建一封邮件
            MimeMessage message = new MimeMessage(session);
            // 2. From: 发件人（昵称有广告嫌疑，避免被邮件服务器误认为是滥发广告以至返回失败，请修改昵称）
            message.setFrom(new InternetAddress(sendMail, "邮箱验证码测试", "UTF-8"));
            // 3. To: 收件人（可以增加多个收件人、抄送、密送）
            message.setRecipient(MimeMessage.RecipientType.TO, new InternetAddress(receiveMail, "xx用户", "UTF-8"));
            // 4. Subject: 邮件主题（标题有广告嫌疑，避免被邮件服务器误认为是滥发广告以至返回失败，请修改标题）
            message.setSubject("验证码", "UTF-8");
            // 5. Content: 邮件正文（可以使用html标签）（内容有广告嫌疑，避免被邮件服务器误认为是滥发广告以至返回失败，请修改发送内容）
            message.setContent("【验证码】:" + info, "text/html;charset=UTF-8");
            // 6. 设置发件时间
            message.setSentDate(new Date());
            // 7. 保存设置
            message.saveChanges();

            return message;
        }
    }

    public enum CodeTypeEnum {
        TEXT_CODE("文本验证码", 1), EMAIL_CODE("邮箱验证码", 2), PHONE_CODE("手机验证码", 3);
        private final String typeInfo;
        private final int type;

        CodeTypeEnum(String typeInfo, int type) {
            this.typeInfo = typeInfo;
            this.type = type;
        }

        public String getTypeInfo() {
            return typeInfo;
        }

        public int getType() {
            return type;
        }

        public static String getTypeInfo(int type) {
            for (CodeTypeEnum typeEnum : CodeTypeEnum.values()) {
                if (type == typeEnum.type) {
                    return typeEnum.typeInfo;
                }
            }
            return "未知的类型";
        }

        public static CodeTypeEnum getCodeTypeEnum(int type) {
            for (CodeTypeEnum typeEnum : CodeTypeEnum.values()) {
                if (type == typeEnum.type) {
                    return typeEnum;
                }
            }
            return null;
        }
    }
}
