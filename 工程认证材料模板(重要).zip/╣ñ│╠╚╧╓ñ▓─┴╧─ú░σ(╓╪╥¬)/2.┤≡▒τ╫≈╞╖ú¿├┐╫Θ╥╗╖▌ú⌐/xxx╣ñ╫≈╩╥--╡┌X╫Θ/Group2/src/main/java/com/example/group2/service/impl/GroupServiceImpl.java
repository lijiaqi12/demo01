package com.example.group2.service.impl;

import com.example.group2.dao.GroupDao;
import com.example.group2.pojo.Group;
import com.example.group2.pojo.User;
import com.example.group2.service.GroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class GroupServiceImpl implements GroupService {


    private GroupDao groupDao;

    @Autowired
    public void setGroupDao(GroupDao groupDao) {
        this.groupDao = groupDao;
    }

    @Override
    public int createGroup(User user,String name,String code) {
        Group group = new Group();
        group.setFounder(user);
        group.setCode(code);
        group.setName(name);
        groupDao.addGroup(group);
        return group.getId();
    }

    @Override
    public Group getGroupInfo(Group group) {
        //先从数据库取出群组数据
        group = groupDao.select(group);
        Group.Data data;
        if (group == null)
            throw new RuntimeException("群组不存在!!!");
        return group;
    }

    //加入群组
    @Override
    public void joinGroup(Group group, User user, Group.Data.Power power) {
        //先从数据库取出群组数据
        Group tempGroup = groupDao.select(group);
        Group.Data data;
        if (tempGroup == null)
            throw new RuntimeException("群组不存在!!!");
        if (tempGroup.getFounder().equals(user))
            throw new RuntimeException("你是群主!!!!!");
        if (tempGroup.getCode()!=null&&!tempGroup.getCode().equals(group.getCode()))
            throw new RuntimeException("您输入的邀请码不正确!!!!!");
        //如果群组中的data不为空
        if (tempGroup.getData() != null) {
            //将取出的byte[]转成Data对象
            data = tempGroup.bytesToData(tempGroup.getData());
            Map<User, Group.Data.Power> map = data.getMap();
            if (map.containsKey(user))
                throw new RuntimeException("你已经在群组中，无法重复加入.");
            map.put(user, power);
            //将修改后的Data对象重新写回byte[]
            group.dataToBytes(new Group.Data(map));
        } else {
            group.dataToBytes(new Group.Data(user, power));
        }
        groupDao.updateData(group);
    }

    //退出群组
    @Override
    public void exitGroup(Group group, User user) {
        //先从数据库取出群组数据
        group = groupDao.select(group);
        if (group == null)
            throw new RuntimeException("群组不存在");
        Group.Data data;
        if (group.getFounder().getId() == user.getId())
            //群主只能解散,退出必须要先转让
            throw new RuntimeException("你是群主!!!!!");
        if (group.getData() == null) {
            throw new RuntimeException("这个群组是空的!!!");
        } else {
            //将取出的byte[]转成Data对象
            data = group.bytesToData(group.getData());
            Map<User, Group.Data.Power> map = data.getMap();
            if (!map.containsKey(user))
                throw new RuntimeException("你不在当前群组中，无法退出");
            map.remove(user);
            //将修改后的Data对象重新写回byte[]
            group.dataToBytes(new Group.Data(map));
        }
        groupDao.updateData(group);
    }

    @Override
    public void dismissGroup(Group group, User user) {
        group = groupDao.select(group);
        if (group == null)
            throw new RuntimeException("群组不存在");
        groupDao.dismissGroup(group);
    }

    @Override
    public void setPower(Group group, User user, Group.Data.Power power) {
        //先从数据库取出群组数据
        group = groupDao.select(group);
        if (group == null)
            throw new RuntimeException("群组不存在");
        Group.Data data;
        //如果群组中的data不为空
        if (group.getData() != null) {
            //将取出的byte[]转成Data对象
            data = group.bytesToData(group.getData());
            Map<User, Group.Data.Power> map = data.getMap();
            map.put(user, power);
            //将修改后的Data对象重新写回byte[]
            group.dataToBytes(new Group.Data(map));
        } else {
            throw new RuntimeException("群组数据异常");
        }
        groupDao.updateData(group);
    }

    @Override
    public Group.Data.Power getPower(Group group, User user) {
        //先从数据库取出群组数据
        group = groupDao.select(group);
        if (group == null)
            throw new RuntimeException("群组不存在");
        Group.Data data;
        //如果群组中的data不为空
        if (group.getData() == null) {
            throw new RuntimeException("群组数据异常");
        } else {
            //将取出的byte[]转成Data对象
            data = group.bytesToData(group.getData());
            Map<User, Group.Data.Power> map = data.getMap();
            if (!map.containsKey(user))
                throw new RuntimeException("被授权用户不在当前群组中");
            return map.get(user);
        }
    }

    @Override
    public List<Group> findMyGroup(User user) {
        List<Group> groups = groupDao.selectByFounderId(new Group(user));
        User user1 = new User();
        groups.forEach(v -> {
            //这一步的是为了将部分敏感信息隐藏
            user1.setId(v.getFounder().getId());
            user1.setUsername(v.getFounder().getUsername());
            v.setFounder(user1);
            v.setUpdateTime(null);
        });
        return groups;
    }

    @Override
    public List<Group> findJoinedGroup(User user) {
        List<Group> groups = groupDao.getAllGroup();
        List<Group> joinedGroups = new ArrayList<>();
        User user1 = new User();
        groups.forEach(v -> {
            //这一步的是为了将创建者部分敏感信息隐藏
            user1.setId(v.getFounder().getId());
            user1.setUsername(v.getFounder().getUsername());
            v.setFounder(user1);
            if (v.getData() != null) {
                Group.Data data = v.bytesToData(v.getData());
                if (data.getMap().containsKey(user)) {
                    joinedGroups.add(v);
                }
            }
        });
        return joinedGroups;
    }

    //获取群组所有成员
    @Override
    public List<User> getGroupMember(Group group) {
        List<User> users = new ArrayList<>();
        group = groupDao.select(group);
        if (group == null)
            throw new RuntimeException("群组不存在");
        //首先将群主加入list中
        users.add(group.getFounder());
        if (group.getData() != null) {
            users.addAll(group.bytesToData(group.getData()).getMap().keySet());
        }
        return users;
    }

    @Override
    public User getGroupOwner(Group group) {
        group = groupDao.select(group);
        if (group == null)
            throw new RuntimeException("群组不存在");
        User user=group.getFounder();
        user.setEmail("");
        user.setPhone("");
        user.setPassword("");
        user.setUpdateTime(null);
        return user;
    }

    @Override
    public List<User> getGroupFriends(Group group) {
        List<User> users = new ArrayList<>();
        group = groupDao.select(group);
        if (group == null)
            throw new RuntimeException("群组不存在");
        if (group.getData() != null) {
            users.addAll(group.bytesToData(group.getData()).getMap().keySet());
        }
        return users;
    }
}
