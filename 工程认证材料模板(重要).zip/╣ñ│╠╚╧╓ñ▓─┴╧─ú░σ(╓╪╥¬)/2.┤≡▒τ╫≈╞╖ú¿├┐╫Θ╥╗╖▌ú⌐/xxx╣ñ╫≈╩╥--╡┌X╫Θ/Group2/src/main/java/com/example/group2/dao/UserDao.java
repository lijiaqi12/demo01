package com.example.group2.dao;

import com.example.group2.pojo.User;
import org.apache.ibatis.annotations.*;


@Mapper
public interface UserDao {
    @Select({"<script>" +
            "SELECT * " +
            "FROM users " +
            "<where>" +
            "<if test='username!=null and username!=\"\"'> and username = #{username} </if>" +
            "<if test='phone!=null and phone!=\"\"'> and phone = #{phone} </if>" +
            "<if test='email!=null and email!=\"\"'> and email =#{email} </if>" +
            "</where>" +
            "</script>"})
    public User findUser(User user);

    @Insert("INSERT INTO users (username,password,phone,email)VALUES(#{username},#{password},#{phone},#{email})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    public void addUser(User user);

    @Select("SELECT * FROM users WHERE id=#{id}")
    public User findUserById(User user);

    @Select("SELECT * FROM users WHERE username=#{username}")
    public User findUserByUsername(User user);

    @Select("SELECT * FROM users WHERE phone=#{phone}")
    public User findUserByPhone(User user);

    @Select("SELECT * FROM users WHERE email=#{email}")
    public User findUserByEmail(User user);

    @Update("UPDATE users SET password=#{password} WHERE id=#{id}")
    public void updatePassword(User user);

    @Update("UPDATE users SET head_image=#{headImage} WHERE id=#{id}")
    public void updateHeadImage(User user);

    @Update({"<script>" +
            "UPDATE users " +
            "<set>" +
            "<if test ='email != null and email !=\"\"'>, email=#{email}</if>" +
            "<if test ='nickname!=null and nickname!=\"\"'>, nickname=#{nickname}</if>" +
            "</set>" +
            "WHERE id = #{id} " +
            "LIMIT 1 " +
            "</script>"})
    public void updateUserInfo(User user);

    @Update("UPDATE users SET email=\"\",nickname=\"\" WHERE id=#{id} LIMIT 1")
    public void emptyUserInfo(User user);

}
