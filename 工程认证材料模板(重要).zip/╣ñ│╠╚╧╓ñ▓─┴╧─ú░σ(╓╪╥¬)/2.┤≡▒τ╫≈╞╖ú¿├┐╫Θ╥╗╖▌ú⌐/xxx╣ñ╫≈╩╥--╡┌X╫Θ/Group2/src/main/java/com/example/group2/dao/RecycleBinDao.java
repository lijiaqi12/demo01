package com.example.group2.dao;

import com.example.group2.pojo.RecycleBin;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.mapping.FetchType;

import java.util.List;

@Mapper
public interface RecycleBinDao {

    @Insert("INSERT INTO `recyclebin` (`delete_file_name`,`original_address`,`size`,`delete_user_id`)VALUES(#{deleteFileName},#{originalAddress},#{size},#{user.id})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    public void addDeleteRecord(RecycleBin recycleBin);

    @Delete("DELETE FROM `recyclebin` WHERE id=#{id}")
    public void deleteRecycleRecord(RecycleBin recycleBin);

    @Select("SELECT * FROM `recyclebin` WHERE id=#{id}")
    @Result(column = "delete_user_id", property = "user", one = @One(select = "com.example.group2.dao.UserDao.findUserById", fetchType = FetchType.EAGER))
    public RecycleBin select(RecycleBin recycleBin);

    @Select("SELECT * FROM `recyclebin` WHERE delete_user_id=#{user.id}")
    @Result(column = "delete_user_id", property = "user", one = @One(select = "com.example.group2.dao.UserDao.findUserById", fetchType = FetchType.EAGER))
    public List<RecycleBin> findFileByUser(RecycleBin recycleBin);
}
