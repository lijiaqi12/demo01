package com.example.group2.controller;

import com.alibaba.fastjson.JSONObject;
import com.example.group2.handlerInterceptor.PassToken;
import com.example.group2.pojo.User;
import com.example.group2.pojo.check.EmailCheck;
import com.example.group2.pojo.check.PasswordCheck;
import com.example.group2.pojo.check.PhoneCheck;
import com.example.group2.pojo.check.UsernameCheck;
import com.example.group2.service.UserService;
import com.example.group2.utils.CodeUtil;
import com.example.group2.utils.CookiesUtil;
import com.example.group2.utils.JwtToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

@Controller
@CrossOrigin(origins = "${netDisk.web.path}", allowedHeaders = "*", allowCredentials = "true")
public class LoginController {

    private UserService userService;
    @Value("${token.name}")
    private String tokenName;
    @Autowired
    public void setUserService(UserService userService) {
        this.userService = userService;
    }

    /**
     * 通过用户名和密码登录
     * @param user  用户信息  只需要用户名和密码
     * @param result  参数错误结果集
     * @param code   验证码
     * @return com.alibaba.fastjson.JSONObject
     * @author zwl
     * @date 2021/8/22
     **/
    @RequestMapping(value = "/login")
    @ResponseBody
    @PassToken
    public JSONObject login(@Validated(value = {UsernameCheck.class, PasswordCheck.class}) User user, BindingResult result, String code,String uuid, HttpServletResponse response) {
        Map<String, Object> map = new HashMap<>();
        //如果有参数为通过校验，将其加入result中
        if (result.hasErrors()) {
            result.getAllErrors().forEach(v -> map.put("errMsg", map.containsKey("errMsg") ? map.get("errMsg") + " " + v.getDefaultMessage() : v.getDefaultMessage()));
        } else {
            //这里记得改回来  加个!
            if (!CodeUtil.codeCheck(uuid, code, CodeUtil.CodeTypeEnum.TEXT_CODE)) {
                map.put("errMsg", "验证码错误");
            } else {
                try {
                    //登录
                    user = userService.login(user);
                } catch (RuntimeException e) {
                    map.put("errMsg", e.getMessage());
                    map.put("code",-1);
                    return new JSONObject(map);
                }
                //user为空说明登录失败
                    if (user == null) {
                        map.put("errMsg", "用户名或密码错误");
                    } else {
                        Map<String,Object> tempMap=new HashMap<>();
                        tempMap.put("id",user.getId());
                        tempMap.put("username",user.getUsername());
                        //response.addCookie();
                        //将敏感信息清除
                        user.setPassword("");
                        user.setEmail("");
                        user.setPhone("");
                        map.put("code", 0);
                        map.put("message", "登录成功");
                        map.put("data", user);
                        map.put("token", JwtToken.GenerateToken(new JSONObject(tempMap).toJSONString()));
                    }

            }
        }
        if (!map.containsKey("code")) {
            map.put("code", -1);
        }
        return new JSONObject(map);
    }
    /**
     * 通过手机号快速登录
     * @param user 用户手机号
     * @param result  参数错误结果集
     * @param code    验证码
     * @return com.alibaba.fastjson.JSONObject
     * @author zwl
     * @date 2021/8/22
     **/
    @RequestMapping(value = "fastLoginByPhone")
    @ResponseBody
    @PassToken
    public JSONObject fastLoginByPhone(@Validated(value = PhoneCheck.class) User user, BindingResult result, String code,HttpServletResponse response) {
        Map<String, Object> map = new HashMap<>();
        //如果有参数未通过校验，将其加入result中
        if (result.hasErrors()) {
            result.getAllErrors().forEach(v -> map.put("errMsg", map.containsKey("errMsg") ? map.get("errMsg") + " " + v.getDefaultMessage() : v.getDefaultMessage()));
        } else {
            //先将用户名和邮箱置空防止干扰登录
            user.setEmail("");
            user.setUsername("");
            try {
                user = userService.fastLogin(user, code);
            } catch (RuntimeException e) {
                map.put("errMsg", e.getMessage());
                map.put("code",-1);
                return new JSONObject(map);
            }
                if (user == null) {
                    map.put("errMsg", "验证码错误");
                }else {
                    Map<String,Object> tempMap=new HashMap<>();
                    tempMap.put("id",user.getId());
                    tempMap.put("username",user.getUsername());
                    map.put("code", 0);
                    map.put("message", "登录成功");
                    map.put("token", JwtToken.GenerateToken(new JSONObject(tempMap).toJSONString()));
                }
        }
        if (!map.containsKey("code")) {
            map.put("code", -1);
        }
        return new JSONObject(map);
    }
    /**
     * 通过邮箱快速登录
     * @param user  用户邮箱
     * @param result  参数错误结果集
     * @param code  验证码
     * @return com.alibaba.fastjson.JSONObject
     * @author zwl
     * @date 2021/8/22
     **/
    @RequestMapping(value = "fastLoginByEmail")
    @ResponseBody
    @PassToken
    public JSONObject fastLoginByEmail(@Validated(value = EmailCheck.class) User user, BindingResult result, String code,HttpServletResponse response) {
        Map<String, Object> map = new HashMap<>();
        //如果有参数未通过校验，将其加入result中
        if (result.hasErrors()) {
            result.getAllErrors().forEach(v -> map.put("errMsg", map.containsKey("errMsg") ? map.get("errMsg") + " " + v.getDefaultMessage() : v.getDefaultMessage()));
        } else {

                if (user == null) {
                    map.put("errMsg", "验证码错误");
                } else {
                    //先将其他可能干扰的信息清空
                    user.setPassword("");
                    user.setUsername("");
                    user.setPhone("");
                    try {
                        user = userService.fastLogin(user, code);
                    }catch (RuntimeException e) {
                        map.put("errMsg", e.getMessage());
                        map.put("code",-1);
                        return new JSONObject(map);
                    }
                    if(user==null){
                        map.put("errMsg", "验证码错误");
                    }else {
                        Map<String,Object> tempMap=new HashMap<>();
                        tempMap.put("id",user.getId());
                        tempMap.put("username",user.getUsername());
                        map.put("token",JwtToken.GenerateToken(new JSONObject(tempMap).toJSONString()));
                        map.put("code", 0);
                        map.put("message", "登录成功");
                    }
            }
        }
        if (!map.containsKey("code")) {
            map.put("code", -1);
        }
        return new JSONObject(map);
    }


}
