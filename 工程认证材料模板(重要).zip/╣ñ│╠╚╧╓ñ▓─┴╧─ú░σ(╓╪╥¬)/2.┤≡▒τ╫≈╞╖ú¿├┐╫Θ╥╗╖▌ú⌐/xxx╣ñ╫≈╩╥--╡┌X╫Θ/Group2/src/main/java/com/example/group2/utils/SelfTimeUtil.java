package com.example.group2.utils;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class SelfTimeUtil {
      public static  Date getDate(){
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date time= null;
        try {
            time = df.parse(df.format(new Date()));
            System.out.println(time+"  555  "+df.format(new Date()));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return time;
    }
    public static  String getTime(){
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
    }
    public static  String formatTime(Date date){
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);
    }
    /**
     * 时间转化为时间戳
     * @author zwl
     * @date 2021/5/31 8:30
      * @Param: 要转化的时间
     * @return 转化后的时间戳
    */
    public static String dateToStamp(String s) throws ParseException {
        String res;                //设置时间格式，将该时间格式的时间转换为时间戳
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = simpleDateFormat.parse(s);
        long time = date.getTime();
        res = String.valueOf(time);
        return res;
    }

    /**
     * 将时间戳转化为时间
     * @author zwl
     * @date 2021/5/31 8:34
      * @Param: 要转化的时间戳
     * @return  转化后的时间
    */
    public static String stampToTime(String s){
        String res;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        long lt = Long.parseLong(s);              //将时间戳转换为时间
        Date date = new Date(lt);           //将时间调整为yyyy-MM-dd HH:mm:ss时间样式
        res = simpleDateFormat.format(date);
        return res;
    }
    /**
     * @author zwl
     * @date 2021/6/15 10:01
     * @Param: String   要解析的时间戳字符串
     * @return long[]  解析后的时间戳数组
    */
    public static long[] parseTime(String time){
        int oldLength=time.length();//获取初始字符串长度
        int newLength=time.replace(",","").length();//获取将","去除的字符串长度,oldLength-newLength即为","出现的次数
        long[] times=new long[oldLength-newLength+1];//+1因为oldLength-newLength个","可以将字符串分为oldLength-newLength+1个子串
        int i=0;
        while (time.contains(",")){
            times[i]=Long.parseLong(time.substring(0,time.indexOf(",")));
            time=time.substring(time.indexOf(",")+1);//将记录下的子串剔除
            i++;
        }
        times[i]=Long.parseLong(time);//因为剩最后一个子串时已经跳过循环,所以要手动赋值
        return times;
    }



}
