package com.example.group2.pojo.check;

public interface PhoneCheck {
}
