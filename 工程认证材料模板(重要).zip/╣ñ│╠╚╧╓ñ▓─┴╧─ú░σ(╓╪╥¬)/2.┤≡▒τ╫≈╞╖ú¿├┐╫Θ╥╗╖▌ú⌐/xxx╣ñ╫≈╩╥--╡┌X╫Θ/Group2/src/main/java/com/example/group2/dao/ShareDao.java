package com.example.group2.dao;

import com.example.group2.pojo.Share;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.mapping.FetchType;

@Mapper
public interface ShareDao {
    @Select("SELECT * FROM share WHERE id=#{id}")
    @Result(column = "share_user_id", property = "user", one = @One(select = "com.example.group2.dao.UserDao.findUserById", fetchType = FetchType.EAGER))
    public Share selectShare(Share share);
    @Insert("INSERT INTO `share` (share_file_name,share_user_id,`code`,overdue_time)VALUES(#{shareFileName},#{user.id},#{code},#{overdueTime})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    public void addShare(Share share);
}
