package com.example.group2.service.impl;

import com.example.group2.dao.SignDao;
import com.example.group2.pojo.Group;
import com.example.group2.pojo.Sign;
import com.example.group2.pojo.User;
import com.example.group2.service.GroupService;
import com.example.group2.service.SignService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class SignServiceImpl implements SignService {

    private SignDao signDao;
    private GroupService groupService;

    @Autowired
    public void setSignDao(SignDao signDao) {
        this.signDao = signDao;
    }

    @Autowired
    public void setGroupService(GroupService groupService) {
        this.groupService = groupService;
    }

    @Override
    public Sign getSignInfo(Sign sign) {
        sign=signDao.select(sign);
        if (sign==null)
            throw new RuntimeException("签到记录不存在");
        return sign;
    }

    @Override
    public void createSignInfo(Sign sign, User user) {
        if (!user.equals(groupService.getGroupInfo(sign.getGroup()).getFounder()))
            throw new RuntimeException("只有群主才能发起签到");
        if (sign.getGroup()==null)
            throw new RuntimeException("不能对空气发起签到");
        signDao.addSignInfo(sign);

    }

    @Override
    public void sign(Sign sign, User user) {
        sign=signDao.select(sign);
        if (sign==null)
            throw new RuntimeException("签到信息不存在");
        if (sign.getGroup().getFounder().equals(user))
            throw new RuntimeException("你是群主签什么到!!");
        if (System.currentTimeMillis()>sign.getEndTime().getTime())
            throw new RuntimeException("签到已过期");
        if (!groupService.getGroupFriends(sign.getGroup()).contains(user))
            throw new RuntimeException("你不在群组中,无法签到!!");
        if (sign.getData()!=null) {
            Sign.Data data = sign.bytesToData(sign.getData());
            Map<User, Date> map = data.getMap();
            if (map.containsKey(user))
                throw new RuntimeException("你已经签到过了");
            map.put(user, new Date());
            sign.dataToBytes(new Sign.Data(map));
        }else {
            sign.dataToBytes(new Sign.Data(user,new Date()));
        }
        signDao.updateSignInfo(sign);
    }

    //获取该群组所有签到记录
    @Override
    public List<Sign> getGroupAllSignInfo(Sign sign) {
        return signDao.selectGroupAllSignInfo(sign);
    }

    //获取某次签到的详情
    @Override
    public Map<User,Date> getFriendsSignInfo(Sign sign) {
        sign=signDao.select(sign);
        if (sign==null)
            throw new RuntimeException("签到信息不存在");
        if (sign.getData()==null)
            return null;
        Map<User,Date> map =groupService.getGroupFriends(sign.getGroup()).stream().collect(Collectors.toMap(Function.identity(),User::getTime));
        map.replaceAll((k,v)->v=null);
        map.putAll(sign.bytesToData(sign.getData()).getMap());
        return map;
    }

    @Override
    public int getUserSignInfo(Sign sign, User user) {
        sign=signDao.select(sign);
        if (sign==null)
            throw new RuntimeException("签到信息不存在");
        Group group=sign.getGroup();
        if (!group.bytesToData(group.getData()).getMap().containsKey(user))
            throw new RuntimeException("你不在这个群组中");
        if (sign.getData()!=null&&sign.bytesToData(sign.getData()).getMap().containsKey(user))
            //已经签到
            return -1;
        else if (sign.getStartTime().getTime()>System.currentTimeMillis()||sign.getEndTime().getTime()<System.currentTimeMillis())
            //无法签到
            return -2;
        else
            //可以签到
            return 0;

    }

    @Override
    public Map<Sign,Integer> getUserAllSignInfo(User user) {
        List<Sign> signs=new ArrayList<>();
        Map<Sign,Integer> map=new HashMap<>();
        groupService.findJoinedGroup(user).forEach(v-> signs.addAll(signDao.selectGroupAllSignInfo(new Sign(v))));
        signs.forEach(v-> map.put(v,getUserSignInfo(v,user)));
        return map;
    }

}
