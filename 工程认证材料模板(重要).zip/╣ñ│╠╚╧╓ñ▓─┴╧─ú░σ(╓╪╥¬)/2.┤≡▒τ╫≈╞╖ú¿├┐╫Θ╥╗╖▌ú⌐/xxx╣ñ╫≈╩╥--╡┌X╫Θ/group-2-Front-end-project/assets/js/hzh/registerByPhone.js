$(function() {



});



// ================以下为自定义函数======================
 
    //用户注册
    function registerByPhone() {
        var uname = $("#uname").val().trim();
        var phone = $("#fastphone").val();
        var code = $("#code").val();
        var pwd = $("#password").val();
        var rePwd = $("#rePassword").val();

        var check = $("#agreeCheck").is(":checked");
        // alert(check)

        if(!check){
            alert("请同意此条款和协议")
        }else{
            $.ajax({
                url : SERVER_PATH + "/registerByPhone",
                type:'post',
                data : {
                    username : uname,
                    phone : phone,
                    code : code,
                    password : pwd,
                    tPassword : rePwd
                },
                dataType : 'json',
                cache:false,
                success : function(data) {
                    if(data.code==0){
                        alert(data.message);
                        window.location="login.html";
                    }else{
                        alert(data.errMsg);
                    }
                }
            })
        }
        
       
    }


  