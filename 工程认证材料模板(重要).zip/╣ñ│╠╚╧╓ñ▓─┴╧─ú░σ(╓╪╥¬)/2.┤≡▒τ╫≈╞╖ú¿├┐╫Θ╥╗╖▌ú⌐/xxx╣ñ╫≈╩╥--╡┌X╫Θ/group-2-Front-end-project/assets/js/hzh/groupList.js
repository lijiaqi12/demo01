// alert("index.js生效！")

$(function(){
	//初始化页面
	initGroupInfo();
	setCurrentType(2);
	setCurrentPath("/");


	//加载读取文件夹函数
	readDir()


	// 加载删除函数
    clickDeleteBtn()


	//加载修改函数
	clickAlterBtn() 


    //加载搜索
    selectFile();
	
 	//加载新建文件夹函数
    mkdir();



     //加载下载函数
    download()

	//导航
	fileNavigation();

});





