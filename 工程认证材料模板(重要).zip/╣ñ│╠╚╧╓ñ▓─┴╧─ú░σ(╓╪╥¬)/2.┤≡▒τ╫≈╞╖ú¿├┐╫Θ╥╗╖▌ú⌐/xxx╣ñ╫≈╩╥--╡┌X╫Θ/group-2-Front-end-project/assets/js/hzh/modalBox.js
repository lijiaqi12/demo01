// 模态框



//确认删除框

function clickConfirmDeleteBtn(modalId,modalRandomId,modalTitle,modalMessage){
    var html = '<div class="modal fade" id="'+modalId+''+modalRandomId+'" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">\n' +
    '  <div class="modal-dialog modal-dialog-centered">\n' +
    '    <div class="modal-content">\n' +
    '      <div class="modal-header">\n' +
    '        <h5 class="modal-title" id="exampleModalCenterTitle">'+modalTitle+'</h5>\n' +
    '        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>\n' +
    '      </div>\n' +
    '      <div class="modal-body">'+modalMessage+'</div>\n' +
    '      <div class="modal-footer">\n' +
    '        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">关闭</button>\n' +
    '        <button type="button" class="btn btn-primary" data-bs-dismiss="modal" id="'+modalId+'Btn'+modalRandomId+'">确认</button>\n' +
    '      </div>\n' +
    '    </div>\n' +
    '  </div>\n' +
    '</div>';

}

                   
{/* <div class="modal fade" id="confirmDelete" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">下载</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">是否下载勾选文件？</div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">关闭</button>
        <button type="button" class="btn btn-primary" id="confirmDeleteBtn">确认</button>
      </div>
    </div>
  </div>
</div> */}