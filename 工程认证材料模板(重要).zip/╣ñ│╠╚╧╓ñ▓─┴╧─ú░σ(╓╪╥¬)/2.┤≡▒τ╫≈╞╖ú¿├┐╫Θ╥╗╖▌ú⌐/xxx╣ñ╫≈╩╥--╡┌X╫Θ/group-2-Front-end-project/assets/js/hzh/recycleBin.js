// alert("recycleBin.js生效！")

$(function(){


	//回收站初始化
    initRecyleBin("/",3)

	//回收站还原
	clickRestore();

	//回收站彻底删除
	clickCompletelyDeleteBtn();
    
        
    
    });
    
    
//=======================以下为自定义函数=========================




    


