/**
 * 路径面包屑导航
 * html页面，加id
 * <ol class="breadcrumb" id="breadcrumb">
 */

 window.onload=function(){
	//分割相对路径
	var items=location.pathname.substr(1).split('/');//返回域名后的部分
	//var action = window.location.pathname.split("/").slice(-1)[0];
	//构建主路径
	//alert("item="+items);
	//alert("item.length="+items.length);
	var mainpath="<a href='"+location.protocol+"//"+location.hostname+":"+location.port+"/";
	//alert(location.hostname);
	var breadcrumbTrail="<p>";
	for(var i=0;i<items.length;i++){
		//结尾的斜杠
		if(items[i].length==0){
			break;
		}else if((items[i]=="index.html")||(items[i]=="group.html")||(items[i]=="groupList.html")||(items[i]=="fileManagerDetail.html")){

			var j=i;
			for(j;j<items.length;j++){
				//将主路径增加到一个新的层次
			mainpath+=items[j];
			//在所有的项之后添加斜杠，最后一项除外
			if(j<items.length-1)
			mainpath+='/';
	
			//创建面包屑路径部分
			//仅对内部项添加箭头
			if(j>i&&j<items.length)
			breadcrumbTrail+=" > ";
		
			//添加面包屑
			if(items[j]=="index.html"){
				var itemsname="个人文件";
			}else if(items[j]=="group.html"){
				var itemsname="群组";
			}else if(items[j]=="groupList.html"){
				var itemsname="群组列表";
			}else if(items[j]=="fileManagerDetail.html"){
				var itemsname="文件分类";
			}else{
				itemsname=items[j];
			}
			//alert("mainpath"+mainpath);
			breadcrumbTrail+=mainpath+"'>"+itemsname+"</a>";
			}
		}else {
			//将主路径增加到一个新的层次
			mainpath+=items[i];
			if(i<items.length-1)
			mainpath+='/';
			//alert("mainpath"+mainpath);
			continue;
		}
	}
	breadcrumbTrail+="</p>";
	document.getElementById("breadcrumb").innerHTML=breadcrumbTrail;
}

//  window.onload=function(){
// 	//分割相对路径
// 	var items=location.pathname.substr(1).split('/');//返回域名后的部分
// 	//var action = window.location.pathname.split("/").slice(-1)[0];
// 	//构建主路径
// 	var mainpath="<a href='"+location.protocol+"//"+location.hostname+"/";
	
// 	var breadcrumbTrail="<p>";
// 	for(var i=0;i<items.length;i++){
// 		//结尾的斜杠
// 		if(items[i].length==0) break;
		
// 		//将主路径增加到一个新的层次
// 		mainpath+=items[i];
		
// 		//在所有的项之后添加斜杠，最后一项除外
// 		if(i<items.length-1)
// 			mainpath+='/';
		
// 		//创建面包屑路径部分
// 		//仅对内部项添加箭头
// 		if(i>0&&i<items.length)
// 			breadcrumbTrail+=" > ";
		
// 		//添加面包屑

// 		breadcrumbTrail+=mainpath+"'>"+items[i]+"</a>";
// 		alert("item="+items[i])
// 		alert("面包屑"+breadcrumbTrail)
// 	}
	
// 	breadcrumbTrail+="</p>";
// 	document.getElementById("breadcrumb").innerHTML=breadcrumbTrail;
// }