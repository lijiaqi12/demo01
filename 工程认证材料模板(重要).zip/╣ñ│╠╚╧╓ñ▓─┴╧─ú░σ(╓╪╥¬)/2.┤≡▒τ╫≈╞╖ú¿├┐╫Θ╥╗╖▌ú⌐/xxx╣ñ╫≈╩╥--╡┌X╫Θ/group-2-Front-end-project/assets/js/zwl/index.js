

$(function(){
//初始化页面
readFileList("/",1)
setCurrentType(1);
setCurrentPath("/");

//加载读取文件夹函数
readDir();


// 加载删除函数
clickDeleteBtn();


//加载修改函数
clickAlterBtn();


//加载搜索
selectFile();


//加载新建文件夹方法
mkdir();


//加载下载方法
download();


//文件预览
filepreview();

//导航
fileNavigation();

})