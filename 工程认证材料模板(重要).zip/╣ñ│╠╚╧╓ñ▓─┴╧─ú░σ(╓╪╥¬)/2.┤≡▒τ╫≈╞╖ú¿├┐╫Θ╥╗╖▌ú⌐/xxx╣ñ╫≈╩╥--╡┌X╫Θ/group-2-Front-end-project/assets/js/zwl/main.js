// alert("index.js生效！")

$(function(){

	//readGroupList();

	


});


//=======================以下为自定义函数=========================

//编辑个人资料
function profileEditing(){

    var nickname = $("#InputNickName").val();
    var email = $("#InputEmail1").val();
    alert(nickname);
    alert(email);

   
    $.ajax({
        type: "post",
        url: SERVER_PATH + "/alterUserInfo",
        headers:{"Accept": "application/json; charset=utf-8",
                "X-Requested-With":'XMLHttpRequest',
                "token":storage.token}, 
        data: {
            name:nickname,
            email:email
        },
        dataType: "json",
        success: function (data) {
            if(data.code==0){
                alert(data.message);
            }else{
                alert(data.errMsg);
            }
        }
    });

}



  //字符串修正
  function escapeHtml(string) {
	     var entityMap = {
	         "&": "&amp;",
	         "<": "&lt;",
	         ">": "&gt;",
	         '"': '&#34;',
	         "'": '&#39;',
	         "\\": '&#92;',
	         "/": '&#x2F;',
			 " ":'&nbsp;'
	     };
	     return String(string).replace(/[&<>\"\'\/\ ]/g, function (s) {
	         return entityMap[s];
	     });
	 }





    Date.prototype.Format = function (fmt) { //author: meizz
        var o = {
            "M+": this.getMonth() + 1, //月份
            "d+": this.getDate(), //日
            "h+": this.getHours(), //小时
            "m+": this.getMinutes(), //分
            "s+": this.getSeconds(), //秒
            "q+": Math.floor((this.getMonth() + 3) / 3), //季度
            "S": this.getMilliseconds() //毫秒
        };
        if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
        for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        return fmt;
    }


//文件大小单位自动转化
function fileSizeConvert(size){
	return size/1024/1024/1024>1?(size/1024/1024/1024).toFixed(2)+" GB":size/1024/1024>1?(size/1024/1024).toFixed(2)+" MB":size/1024>1?(size/1024).toFixed(2)+" KB":size+" B" 
}

//获取当前文件的路径
function getFilePath(){
	return $(this).parents("tr").attr("path");
}


//获取当前页面的路径
function getCurrentPath(){
	return $(".fsList").attr("path");
}
//设置当前页面的路径
function setCurrentPath(path){
	return $(".fsList").attr("path",path);
}
//获取当前文件的类型
function getCurrentType(){
	return $(".fsList").attr("type");
}
//设置当前文件的类型
function setCurrentType(type){
	return $(".fsList").attr("type",type);
}
//获取当前群组Id
function getGroupId(){
    return $("#groupId").text();
}
//设置群组Id
function getSroupId(groupId){
    return $("#groupId").text(groupId);
}

//截取当前路径函数
function subPath(path){
	if(path=="/"){
		return "/";
	}
	var i = path.lastIndexOf("/");
	path=path.substring(0,i);
	return path==""?"/":path;
}


//获取路径中属性名为name的数据
function getUrlParam(name) {
    var url = window.location.href;
    if(url!=null && url.indexOf("?")!=-1){
        var url_param = url.split("?")[1];
        var url_param_arr = url_param.split("&");
        for(var i=0;i<url_param_arr.length;i++){
            var tempParam = url_param_arr[i];
            var paramName =  tempParam.split("=")[0];
            if(paramName==name){
                return tempParam.split("=")[1]
            }
        }
    }
    return null;
}





//解析后端返回的文件数据
function parseFileData(data){
			var fshtml = "";
			data.map(function (item,index) {
				SUB_PATH = subPath(item.path)
				if(item.dir){
					//设置表格每行的路径
					fshtml += ' <tr path='+escapeHtml(item.path)+'>\n' +
					'\t\t\t\t\t            <td  class="d-none d-lg-table-cell"><input type="checkbox" value="select"></td>\n' +
					'                      <td  class="fileName"><img src="../../assets/images/hzh/folder3.png" alt=""><a href="javascript:void(0);" class="isDir">'+item.name+'</a></td>\n' +
					'                      <div>\n' +
					'                        <td class="d-none d-lg-table-cell" >'+item.modification_time+'</td>\n' +
					'                        <td class="d-none d-lg-table-cell">'+item.length+'</td>\\n\'</td>\n' +
					// '                        <td class="d-none d-lg-table-cell"></td>\n' +
					'                      </div>\n' +
					'                  \n' +
					'                      <td>\n' +
					'                        <div class="d-none d-lg-table-cell">\n' +
					'                          <a href="javascript:void(0);" class="downloadBtn"><span class="badge bg-info">下载</span></a> \n' +
					'                          <a href="javascript:void(0);" class="deleteBtn"><span class="badge bg-danger mx-1">删除</span></a>\n' +
					'                          <a href="javascript:void(0);" class="alterBtn"><span class="badge bg-success">修改</span></a>\n' +
					'                          <a href="javascript:void(0);" class="shareBtn"><span class="badge bg-secondary mx-1">分享</span></a> \n' +
					'                          <a href="javascript:void(0);" class="collectingBtn"><span class="badge bg-dark mx-1">收藏</span></a>\n' +
					'                        </div>\n' +
					'\n' +
					'                        <div class="d-table-cell d-lg-none">\n' +
					'                          <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false"> 更多 </button>\n' +
					'                          <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">\n' +
					'                            <li><a class="dropdown-item downloadBtn" href="#">下载</a></li>\n' +
					'                            <li><a class="dropdown-item deleteBtn" href="javascript:void(0);">删除</a></li>\n' +
					'                            <li><a class="dropdown-item alterBtn" href="#">修改</a></li>\n' +
					'                            <li><a class="dropdown-item shareBtn" href="#">分享</a></li>\n' +
					'                            <li><a class="dropdown-item collectingBtn" href="#">收藏</a></li>\n' +
					'                          </ul>\n' +
					'                        </div>\n' +
					'                        \n' +
					'\t\t\t\t\t            </td>\t\t\t  \n' +
					'                    </tr>' ;
				}else{
					fshtml += ' <tr path='+escapeHtml(item.path)+'>\n' +
					'\t\t\t\t\t            <td  class="d-none d-lg-table-cell"><input type="checkbox" value="select"></td>\n' +
					'                      <td  class="fileName"><img src="../../assets/images/hzh/file.png" alt="">'+item.name+'</td>\n' +
					'                      <div>\n' +
					'                        <td class="d-none d-lg-table-cell" >'+item.modification_time+'</td>\n' +
					'                        <td class="d-none d-lg-table-cell">'+fileSizeConvert(item.length)+'</td>\\n\'</td>\n' +
					// '                        <td class="d-none d-lg-table-cell"></td>\n' +
					'                      </div>\n' +
					'                  \n' +
					'                      <td>\n' +
					'                        <div class="d-none d-lg-table-cell">\n' +
					'                          <a href="javascript:void(0);" class="downloadBtn"><span class="badge bg-info">下载</span></a> \n' +
					'                          <a href="javascript:void(0);" class="deleteBtn"><span class="badge bg-danger mx-1">删除</span></a>\n' +
					'                          <a href="javascript:void(0);" class="alterBtn"><span class="badge bg-success">修改</span></a>\n' +
					'                          <a href="javascript:void(0);" class="shareBtn"><span class="badge bg-secondary mx-1">分享</span></a> \n' +
					'                          <a href="javascript:void(0);" class="collectingBtn"><span class="badge bg-dark mx-1">收藏</span></a>\n' +
					'                        </div>\n' +
					'\n' +
					'                        <div class="d-table-cell d-lg-none">\n' +
					'                          <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false"> 更多 </button>\n' +
					'                          <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">\n' +
					'                            <li><a class="dropdown-item downloadBtn" href="#">下载</a></li>\n' +
					'                            <li><a class="dropdown-item deleteBtn" href="javascript:void(0);">删除</a></li>\n' +
					'                            <li><a class="dropdown-item alterBtn" href="#">修改</a></li>\n' +
					'                            <li><a class="dropdown-item shareBtn" href="#">分享</a></li>\n' +
					'                            <li><a class="dropdown-item collectingBtn" href="#">收藏</a></li>\n' +
					'                          </ul>\n' +
					'                        </div>\n' +
					'                        \n' +
					'\t\t\t\t\t            </td>\t\t\t  \n' +
					'                    </tr>' ;

								}	
										
							});
			$(".fsList").html(fshtml)
	
}


//解析后端返回的群组数据
function parseGroupData(data){
	
    var groupHtml = "";
    data.data.myGroups.map(function (item,index) {
        groupHtml +="<tr groupId="+item.id+">\n" +
        "                      <th scope=\"row\">"+item.id+"</th>\n" +
        "                      <th scope=\"row\"><img src=\"../../assets/images/avatars/profile-image.png\" alt=\"\"><a href=\"javascript:void(0);\">"+item.name+"</a></th>\n" +
        "                      <td>"+1+"</td>\n" +
        "                      <td>\n" +
        "                        <a href=\"groupList.html\"><span class=\"badge bg-info\">进入</span></a>\n" +
        "                        <a href=\"javascript:void(0);\"><span class=\"badge bg-danger mx-1\">删除</span></a>\n" +
        "                      </td> \n" +
        "                    </tr>"
    $(".myGroupClass").html(fshtml)

})
}

//文件列表显示函数
function readFileList(path,type,groupId){
	$.ajax({
		type: "post",
		url: SERVER_PATH + "/getFileStatus",
		headers:{"Accept": "application/json; charset=utf-8",
		"X-Requested-With":'XMLHttpRequest',
		"token":storage.token}, 
		data: {
			path:path,
			type:type,
			groupId:groupId
		},
		dataType: "json",
		success: function (result) {
			if(result.code == 0){
				var fsList = result.data;
				var fshtml = "";
				fsList.map(function (item,index) {
					SUB_PATH = subPath(item.path)
					$(".fsList").attr("path",subPath(item.path))
						$(".fsList").attr("type",type)
					if(item.dir){
						//设置表格每行的路径
						fshtml += ' <tr path='+escapeHtml(item.path)+'>\n' +
		'\t\t\t\t\t            <td  class="d-none d-lg-table-cell"><input type="checkbox" value="select"></td>\n' +
		'                      <td  class="fileName"><img src="../../assets/images/hzh/folder3.png" alt=""><a href="javascript:void(0);" class="isDir">'+item.name+'</a></td>\n' +
		'                      <div>\n' +
		'                        <td class="d-none d-lg-table-cell" >'+item.modification_time+'</td>\n' +
		'                        <td class="d-none d-lg-table-cell">'+item.length+'</td>\\n\'</td>\n' +
		// '                        <td class="d-none d-lg-table-cell"></td>\n' +
		'                      </div>\n' +
		'                  \n' +
		'                      <td>\n' +
		'                        <div class="d-none d-lg-table-cell">\n' +
		'                          <a href="javascript:void(0);" class="downloadBtn"><span class="badge bg-info">下载</span></a> \n' +
		'                          <a href="javascript:void(0);" class="deleteBtn"><span class="badge bg-danger mx-1">删除</span></a>\n' +
		'                          <a href="javascript:void(0);" class="alterBtn"><span class="badge bg-success">修改</span></a>\n' +
		// '                          <a href="javascript:void(0);" class="shareBtn"><span class="badge bg-secondary mx-1">分享</span></a> \n' +
		// '                          <a href="javascript:void(0);" class="collectingBtn"><span class="badge bg-dark mx-1">收藏</span></a>\n' +
		'                        </div>\n' +
		'\n' +
		'                        <div class="d-table-cell d-lg-none">\n' +
		'                          <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false"> 更多 </button>\n' +
		'                          <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">\n' +
		'                            <li><a class="dropdown-item downloadBtn" href="#">下载</a></li>\n' +
		'                            <li><a class="dropdown-item deleteBtn" href="javascript:void(0);">删除</a></li>\n' +
		'                            <li><a class="dropdown-item alterBtn" href="#">修改</a></li>\n' +
		// '                            <li><a class="dropdown-item shareBtn" href="#">分享</a></li>\n' +
		// '                            <li><a class="dropdown-item collectingBtn" href="#">收藏</a></li>\n' +
		'                          </ul>\n' +
		'                        </div>\n' +
		'                        \n' +
		'\t\t\t\t\t            </td>\t\t\t  \n' +
		'                    </tr>' ;
					}else{
						fshtml += ' <tr path='+escapeHtml(item.path)+'>\n' +
		'\t\t\t\t\t            <td  class="d-none d-lg-table-cell"><input type="checkbox" value="select"></td>\n' +
		'                      <td  class="fileName"><img src="../../assets/images/hzh/file.png" alt="">'+item.name+'</td>\n' +
		'                      <div>\n' +
		'                        <td class="d-none d-lg-table-cell" >'+item.modification_time+'</td>\n' +
		'                        <td class="d-none d-lg-table-cell">'+fileSizeConvert(item.length)+'</td>\\n\'</td>\n' +
		// '                        <td class="d-none d-lg-table-cell"></td>\n' +
		'                      </div>\n' +
		'                  \n' +
		'                      <td>\n' +
		'                        <div class="d-none d-lg-table-cell">\n' +
		'                          <a href="javascript:void(0);" class="downloadBtn"><span class="badge bg-info">下载</span></a> \n' +
		'                          <a href="javascript:void(0);" class="deleteBtn"><span class="badge bg-danger mx-1">删除</span></a>\n' +
		'                          <a href="javascript:void(0);" class="alterBtn"><span class="badge bg-success">修改</span></a>\n' +
		// '                          <a href="javascript:void(0);" class="shareBtn"><span class="badge bg-secondary mx-1">分享</span></a> \n' +
		// '                          <a href="javascript:void(0);" class="collectingBtn"><span class="badge bg-dark mx-1">收藏</span></a>\n' +
		'                        </div>\n' +
		'\n' +
		'                        <div class="d-table-cell d-lg-none">\n' +
		'                          <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false"> 更多 </button>\n' +
		'                          <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">\n' +
		'                            <li><a class="dropdown-item downloadBtn" href="#">下载</a></li>\n' +
		'                            <li><a class="dropdown-item deleteBtn" href="javascript:void(0);">删除</a></li>\n' +
		'                            <li><a class="dropdown-item alterBtn" href="#">修改</a></li>\n' +
		// '                            <li><a class="dropdown-item shareBtn" href="#">分享</a></li>\n' +
		// '                            <li><a class="dropdown-item collectingBtn" href="#">收藏</a></li>\n' +
		'                          </ul>\n' +
		'                        </div>\n' +
		'                        \n' +
		'\t\t\t\t\t            </td>\t\t\t  \n' +
		'                    </tr>' ;
					}	
							
				});




				//导航替换
				$(".fsList").html(fshtml);
				$.ajax({
					type: "post",
					url: SERVER_PATH + "/parsePath",
					data: {
						path:getCurrentPath
					},
					dataType: "json",
					success: function (data) {
						var s=data.data;
						var html='<li class="breadcrumb-item"><a href="index.html">首页</a></li>';
					
						for(var i=s.length;i>0;i--){

							html+='<li  class="breadcrumb-item" path="'+s[i-1][0]+'"><a href="#" class="buttonList" type="button">'+s[i-1][1]+'<a></li>';
						}
						$('#breadcrumb').html(html);

					}
				});

				

			}


			

		}

	});

}




//文件列表显示函数
// function readFileList(path,type,groupId){
// 	$.ajax({
// 		type: "post",
// 		url: SERVER_PATH + "/getFileStatus",
// 		headers:{"Accept": "application/json; charset=utf-8",
// 		"X-Requested-With":'XMLHttpRequest',
// 		"token":storage.token}, 
// 		data: {
// 			path:path,
// 			type:type,
// 			groupId:groupId
// 		},
// 		dataType: "json",
// 		success: function (result) {
// 			if(result.code == 0){
// 				var fsList = result.data;
// 				var fshtml = "";
// 				fsList.map(function (item,index) {
// 					SUB_PATH = subPath(item.path)
// 					$(".fsList").attr("path",subPath(item.path))
// 						$(".fsList").attr("type",type)
// 					if(item.dir){
// 						//设置表格每行的路径
// 						fshtml += ' <tr path='+escapeHtml(item.path)+'>\n' +
// 		'\t\t\t\t\t            <td  class="d-none d-lg-table-cell"><input type="checkbox" value="select"></td>\n' +
// 		'                      <td  class="fileName"><img src="../../assets/images/hzh/folder3.png" alt=""><a href="javascript:void(0);" class="isDir">'+item.name+'</a></td>\n' +
// 		'                      <div>\n' +
// 		'                        <td class="d-none d-lg-table-cell" >'+item.modification_time+'</td>\n' +
// 		'                        <td class="d-none d-lg-table-cell">'+item.length+'</td>\\n\'</td>\n' +
// 		// '                        <td class="d-none d-lg-table-cell"></td>\n' +
// 		'                      </div>\n' +
// 		'                  \n' +
// 		'                      <td>\n' +
// 		'                        <div class="d-none d-lg-table-cell">\n' +
// 		'                          <a href="javascript:void(0);" class="downloadBtn"><span class="badge bg-info">下载</span></a> \n' +
// 		'                          <a href="javascript:void(0);" class="deleteBtn"><span class="badge bg-danger mx-1">删除</span></a>\n' +
// 		'                          <a href="javascript:void(0);" class="alterBtn"><span class="badge bg-success">修改</span></a>\n' +
// 		'                          <a href="javascript:void(0);" class="shareBtn"><span class="badge bg-secondary mx-1">分享</span></a> \n' +
// 		'                          <a href="javascript:void(0);" class="collectingBtn"><span class="badge bg-dark mx-1">收藏</span></a>\n' +
// 		'                        </div>\n' +
// 		'\n' +
// 		'                        <div class="d-table-cell d-lg-none">\n' +
// 		'                          <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false"> 更多 </button>\n' +
// 		'                          <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">\n' +
// 		'                            <li><a class="dropdown-item downloadBtn" href="#">下载</a></li>\n' +
// 		'                            <li><a class="dropdown-item deleteBtn" href="javascript:void(0);">删除</a></li>\n' +
// 		'                            <li><a class="dropdown-item alterBtn" href="#">修改</a></li>\n' +
// 		'                            <li><a class="dropdown-item shareBtn" href="#">分享</a></li>\n' +
// 		'                            <li><a class="dropdown-item collectingBtn" href="#">收藏</a></li>\n' +
// 		'                          </ul>\n' +
// 		'                        </div>\n' +
// 		'                        \n' +
// 		'\t\t\t\t\t            </td>\t\t\t  \n' +
// 		'                    </tr>' ;
// 					}else{
// 						fshtml += ' <tr path='+escapeHtml(item.path)+'>\n' +
// 		'\t\t\t\t\t            <td  class="d-none d-lg-table-cell"><input type="checkbox" value="select"></td>\n' +
// 		'                      <td  class="fileName"><img src="../../assets/images/hzh/file.png" alt="">'+item.name+'</td>\n' +
// 		'                      <div>\n' +
// 		'                        <td class="d-none d-lg-table-cell" >'+item.modification_time+'</td>\n' +
// 		'                        <td class="d-none d-lg-table-cell">'+fileSizeConvert(item.length)+'</td>\\n\'</td>\n' +
// 		// '                        <td class="d-none d-lg-table-cell"></td>\n' +
// 		'                      </div>\n' +
// 		'                  \n' +
// 		'                      <td>\n' +
// 		'                        <div class="d-none d-lg-table-cell">\n' +
// 		'                          <a href="javascript:void(0);" class="downloadBtn"><span class="badge bg-info">下载</span></a> \n' +
// 		'                          <a href="javascript:void(0);" class="deleteBtn"><span class="badge bg-danger mx-1">删除</span></a>\n' +
// 		'                          <a href="javascript:void(0);" class="alterBtn"><span class="badge bg-success">修改</span></a>\n' +
// 		'                          <a href="javascript:void(0);" class="shareBtn"><span class="badge bg-secondary mx-1">分享</span></a> \n' +
// 		'                          <a href="javascript:void(0);" class="collectingBtn"><span class="badge bg-dark mx-1">收藏</span></a>\n' +
// 		'                        </div>\n' +
// 		'\n' +
// 		'                        <div class="d-table-cell d-lg-none">\n' +
// 		'                          <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false"> 更多 </button>\n' +
// 		'                          <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">\n' +
// 		'                            <li><a class="dropdown-item downloadBtn" href="#">下载</a></li>\n' +
// 		'                            <li><a class="dropdown-item deleteBtn" href="javascript:void(0);">删除</a></li>\n' +
// 		'                            <li><a class="dropdown-item alterBtn" href="#">修改</a></li>\n' +
// 		'                            <li><a class="dropdown-item shareBtn" href="#">分享</a></li>\n' +
// 		'                            <li><a class="dropdown-item collectingBtn" href="#">收藏</a></li>\n' +
// 		'                          </ul>\n' +
// 		'                        </div>\n' +
// 		'                        \n' +
// 		'\t\t\t\t\t            </td>\t\t\t  \n' +
// 		'                    </tr>' ;
// 					}	
							
// 				});
// 				$(".fsList").html(fshtml)
// 			}

// 		}

// 	});

// }


//初始化群组列表
function readGroupList(){

	$.ajax({
		type: "post",
		url: SERVER_PATH + "/getFileStatus",
		headers:{"Accept": "application/json; charset=utf-8",
		"X-Requested-With":'XMLHttpRequest',
		"token":storage.token}, 
		data: {
			type : 2
		},
		dataType: "json",
		success: function (result) {
			if(result.code == 0){
				var mygroupHtml = "";
				var joingroupHtml = "";
	
				result.data.myGroups.map(function (item,index) {
					mygroupHtml += '  <tr groupId='+item.id+'>\n' +
	'                     <th scope="row" class="d-none d-lg-table-cell">'+item.id+'</th>\n' +
	'                     <th scope="row"><img src="../../assets/images/hzh/group.svg" alt="" class="d-none d-lg-inline"><a href="groupList.html?id='+item.id+'">'+item.name+'</a></th>\n' +
	'                     <td class="d-none d-lg-table-cell">'+new Date(item.regTime).Format("yyyy-MM-dd hh:mm")+'</td>\n' +
	'                     <td>\n' +
	// '                        <a href="groupList.html?id='+item.id+'"><span class="badge bg-info">进入</span></a>\n' +
	'                        <a href="javascript:void(0);"><span class="dismissGroup badge bg-danger mx-1">解散</span></a>\n' +
	'                     </td>\n' +
	'                  </tr>';
	
			  })
	
			  result.data.joinedGroups.map(function (item,index) {
	
				joingroupHtml += '<tr groupId='+item.id+'>\n' +
		'                 <th scope="row" class="d-none d-lg-table-cell">'+item.id+'</th>\n' +
		'                 <th scope="row"><img src="../../assets/images/hzh/group.svg" alt="" class="d-none d-lg-inline"><a href="groupList.html?id='+item.id+'">'+item.name+'</a></th>\n' +
		'                 <td class="d-none d-lg-table-cell">'+item.founder.username+'</td>\n' +
		'                 <td class="d-none d-lg-table-cell">'+new Date(item.regTime).Format("yyyy-MM-dd hh:mm")+' </td>\n' +
		'                 <td>\n' +
		// '                     <a href="groupList.html?id='+item.id+'"><span class="badge bg-info">进入</span></a>\n' +
		'                     <a href="javascript:void(0);"><span class="exitGroup badge bg-danger mx-1">退群</span></a>  \n' +
		'                  </td>\n' +
		'              </tr>';
	

	
		})
		$(".myGroupClass").html(mygroupHtml)
		$(".joinGroupClass").html(joingroupHtml)
	
		}
	
			
	}
});

}






function filepreview() {  

	// $(".fsList").on("click",".collectingBtn",function(){
    //     var path=$(this).parents("tr").attr("path");
	// 	var name = path.substring(path.lastIndexOf("/")+1);
	// 	alert("文件名"+name)
    //     var originUrl = SERVER_PATH + "/download?path="+path+"&type=1"; //要预览文件的访问地址
	// 	//var previewUrl= originUrl+'&fullfilename='+name;
	// 	// alert("文件路径"+path);
	// 	// alert("文件路径"+SERVER_PATH);
	// 	// alert("文件路径"+originUrl);
	// 	var base = new Base64();
    //     window.open('http://192.168.142.111:8012/onlinePreview?url='+encodeURIComponent(originUrl));
    // })

    $(".fsList").on("click",".collectingBtn",function(){
        var path=$(this).parents("tr").attr("path");
         var name = path.substring(path.lastIndexOf("/")+1);
//         var originUrl = SERVER_PATH + "/download?"; //要预览文件的访问地址
//         var previewUrl= originUrl+'&fileName='+""+;
		var  originUrl = SERVER_PATH + "/download?path="+path+"&type=1";
		var previewUrl= originUrl+'&fullfilename='+name;
		
		var pre = 'http://127.0.0.1:8080/login.jsp'
        alert("文件路径"+path);
//         alert("文件路径"+SERVER_PATH);
//         alert("文件路径"+previewUrl);
		// var base = new base64(previewUrl);
		// alert(base)

        window.open('http://192.168.142.111:8012/onlinePreview?url='+encodeURIComponent(pre));
    })
}

// //新建文件夹
// function mkdir() {  }
// $(".page-content").on("click","#mkdir",function(){

// 	var path = getCurrentPath()
// 	var type = getCurrentType();
// 	var groupId =getGroupId();
// 	$("#newFolder").on("click","#newFolerConfirmBtn",function(){
// 		var dirname =  $("#newFolderInput").val();
// 		path=path+"/"+dirname
// 		if(dirname.length>0){
// 			$.ajax({
// 				type: "post",
// 				url: SERVER_PATH + "/mkdir",
//                 headers:{"Accept": "application/json; charset=utf-8",
// 		                "X-Requested-With":'XMLHttpRequest',
// 		                "token":storage.token}, 
// 				data: {
// 					newDirPath:path,
// 					type:type,
// 					groupId:groupId
// 				},
// 				dataType: "json",
// 				success: function (data) {
// 					if(data.code==0){
// 						// alert("新建成功")
						
// 						parseFileData(data.data);
// 					}else{
// 						alert(data.errMsg);
// 					}
// 				}
// 			});
// 		}
// 	});
	
// });


//新建文件夹
function mkdir() { 
	var path = getCurrentPath()
	var type = getCurrentType();
	var groupId =getGroupId();	
$(".page-content").on("click","#mkdir",function(){
	 path = getCurrentPath()
	 type = getCurrentType();
	 groupId =getGroupId();
});
$("#newFolder").on("click","#newFolerConfirmBtn",function(){
	var dirname =  $("#newFolderInput").val();
	path=path+"/"+dirname
	if(dirname.length>0){
		$.ajax({
			type: "post",
			url: SERVER_PATH + "/mkdir",
			headers:{"Accept": "application/json; charset=utf-8",
					"X-Requested-With":'XMLHttpRequest',
					"token":storage.token}, 
			data: {
				newDirPath:path,
				type:type,
				groupId:groupId
			},
			dataType: "json",
			success: function (data) {
				if(data.code==0){
					parseFileData(data.data);
				}else{
					alert(data.errMsg);
				}
			}
		});
	}
});
}



//下载文件
function download() {  

	$(".fsList").on("click",".downloadBtn",function(){
		var type=getCurrentType();
		var path=$(this).parents("tr").attr("path");
        var groupId=getGroupId();
		var url = SERVER_PATH+"/download";
		var fileName = path;
		var form = $("<form></form>").attr("action", url).attr("method", "post");
		form.append($("<input></input>").attr("type", "hidden").attr("name", "path").attr("value", fileName));
		form.append($("<input></input>").attr("type", "hidden").attr("name", "type").attr("value", type));
        form.append($("<input></input>").attr("type", "hidden").attr("name", "groupId").attr("value", groupId));
		form.append($("<input></input>").attr("type", "hidden").attr("name", "token").attr("value", storage.token));
		form.appendTo('body').submit().remove();

	})

	
}





//核心代码.第一个参数上FormData对象。第二个是上传文件表单对象。
function CreateFileName(upLoadFile,obj){
	var L=obj.files.length;
	for(let i=0;i<L;i++){
		upLoadFile.append("file",obj.files[i]);   // 这里的 "File" 需要和服务端的接收参数一致。不然会报错。
	}
	return upLoadFile;
}





////////////////////////////


//上传文件
function postData(){
    var file=CreateFileName(new FormData(),$("#file")[0]);
	file.append("type",getCurrentType())
	file.append("path",getCurrentPath())
	file.append("groupId",getGroupId())
	$.ajax({
		type: "post",
		url:SERVER_PATH + "/upload",
		headers:{"Accept": "application/json; charset=utf-8",
		"X-Requested-With":'XMLHttpRequest',
		"token":storage.token}, 
		contentType: false,
		// 告诉jQuery不要去设置Content-Type请求头
		processData:false,
		data: file,
		dataType: "json",
		success: function (result) {
			if(result.code == 0){
				// alert(result.message)
				parseFileData(result.data)
			}else{
				alert(result.errMsg)
			}
	
		}
	});
	return false;
}


//获取用户头像
function getUserImg(){
    var file=CreateFileName(new FormData(),$("#file")[0]);
	$.ajax({
		type: "post",
		url:SERVER_PATH + "/alterHeadImage",
		headers:{"Accept": "application/json; charset=utf-8",
		"X-Requested-With":'XMLHttpRequest',
		"token":storage.token}, 
		contentType: false,
		// 告诉jQuery不要去设置Content-Type请求头
		processData:false,
		data: file,
		dataType: "json",
		success: function (result) {
			if(result.code == 0){
				alert(result.message)
				parseFileData(result.data)
			}else{
				alert(result.errMsg)
			}
		}
	});
	return false;
}



//上传头像文件
function postUserImg(){
    var file=CreateFileName(new FormData(),$("#file")[0]);
	$.ajax({
		type: "post",
		url:SERVER_PATH + "/alterHeadImage",
		headers:{"Accept": "application/json; charset=utf-8",
		"X-Requested-With":'XMLHttpRequest',
		"token":storage.token}, 
		contentType: false,
		// 告诉jQuery不要去设置Content-Type请求头
		processData:false,
		data: file,
		dataType: "json",
		success: function (result) {
			if(result.code == 0){
				alert(result.message)
				parseFileData(result.data)
			}else{
				alert(result.errMsg)
			}
	
		}
	});
	return false;
}


//查询文件

function selectFile() {  

	$("#selectInput").on("keypress",function(event){
	if(event.keyCode==13){
		var keyword=$("#selectInput").val();
		var path=getCurrentPath();
		var type=getCurrentType();
        var groupId=getGroupId();
	
		$.ajax({	
			type: "get",
			url: SERVER_PATH + "/select",
			headers:{"Accept": "application/json; charset=utf-8",
			"X-Requested-With":'XMLHttpRequest',
			"token":storage.token}, 
			data: {
				path:"/",
				type:type,
				keyword:keyword,
                groupId:groupId
			},	
			dataType: "json",		
			success: function (date) {		
				if(date.code==0){
					// alert(date.message);
					parseFileData(date.data);
				}else{	
					alert(date.errMsg);		
				}
			}
		});
	}
	})
}

//修改文件名
function clickAlterBtn() { 
	$(".fsList").on("click",".alterBtn",function(){

		var path = $(this).parents("tr").attr("path");
		var type = getCurrentType();
		var fileName = path.substring(path.lastIndexOf("/")+1);
        var groupId=getGroupId();
		var renameFile = prompt('你要修改的文件是：'+fileName+',请输入修改后的名字');
		
		// alert(renameFile)
		if(renameFile){
			$.ajax({
			type: "get",
			url: SERVER_PATH + "/alter",
			headers:{"Accept": "application/json; charset=utf-8",
			"X-Requested-With":'XMLHttpRequest',
			"token":storage.token}, 
			data: {
				filePath:path,
				alterName:getCurrentPath()+"/"+renameFile,
				type:type,
                groupId:groupId
			},
			dataType: "json",
			success: function (data) {
				if(data.code == 0){
					//console.log(data.path);
					readFileList(getCurrentPath(),type,groupId);
				}else{
					alert(data.errMsg);
				}
				
			}
		});
		}
		
	});
 }	

	//进入文件夹
	function readDir(){
		$(".fsList").on("click",".isDir",function(){
		var path = $(this).parents("tr").attr("path");
		var type = getCurrentType();
 		readFileList(path,type,getGroupId());
		setCurrentPath(path);
	});
	}



//删除函数
function clickDeleteBtn(){
	$(".fsList").on("click",".deleteBtn",function(){
	
		//获取当前点击按钮所在行的路径
		var path = $(this).parents("tr").attr("path");
		var type = getCurrentType();
		//alert(path)
		var fileName = path.substring(path.lastIndexOf("/")+1);
        var groupId=getGroupId();
		var b= confirm("确认删除: "+fileName+" ?");
		if(b){
			$.ajax({
				type: "get",
				url: SERVER_PATH + "/delete",
                headers:{"Accept": "application/json; charset=utf-8",
		                "X-Requested-With":'XMLHttpRequest',
		                "token":storage.token}, 
				data: {
					path : path,
					type : type,
                    groupId:groupId
				},
				dataType: "json",
				success: function (result) {
					if(result.code == 0){
						// alert(result.message)
						readFileList(getCurrentPath(),type,groupId)
					}else{
						alert(result.errMsg)
					}
					
				}
			});
		}	

	});

}




	// 点击退出按钮
    function exitGroup(){
         $(".joinGroupClass").on("click",".exitGroup",function(){
        var groupId = $(this).parents("tr").attr("groupId");
        var exit = confirm("确认退出: "+groupId+" ?");
        if(exit){
            $.ajax({
            type: "get",
            url: SERVER_PATH + "/exitGroup",
			headers:{"Accept": "application/json; charset=utf-8",
			"X-Requested-With":'XMLHttpRequest',
			"token":storage.token}, 
            data: {
                groupId:groupId
            },
            dataType: "json",
            success: function (data) {
                if(data.code==0){
                    // alert(data.message);
                    readGroupList(2)
                }else{
                    alert(data.errMsg);
                }
            }
        });
        }
        
    }); 
    }
  
        // 点击解散按钮
        function dismissGroup(){
            $(".myGroupClass").on("click",".dismissGroup",function(){
            var groupId = $(this).parents("tr").attr("groupId");
            var dismiss = confirm("确认解散: "+groupId+" ?");
            if(dismiss){
                $.ajax({
                type: "get",
                url: SERVER_PATH + "/dismissGroup",
                headers:{"Accept": "application/json; charset=utf-8",
		                "X-Requested-With":'XMLHttpRequest',
		                "token":storage.token}, 
                data: {
                    groupId:groupId
                },
                dataType: "json",
                success: function (data) {
                    if(data.code==0){
                        // alert(data.message);
                        readGroupList(2)
                    }else{
                        alert(data.errMsg);
                    }
                }
            });
            }
            
        });
        }
        


//新建群组函数
function clickNewGroupBtn(){

    $("#myfrm").on("click","#newGroupBtn",function(){
        // alert("点击了新建群组按钮");

        $("#newGroup").on("click","#newGroupConfirmBtn",function(){
            var name = $("#groupName").val();
            var code = $("#groupPwd").val();

            $.ajax({
                type: "post",
                url: SERVER_PATH + "/createGroup",
                headers:{"Accept": "application/json; charset=utf-8",
		                "X-Requested-With":'XMLHttpRequest',
		                "token":storage.token}, 
                data: {
                    name : name,
                    code: code
                },
                dataType: "json",
                success: function (result) {
                    if(result.code == 0){
                        // alert(result.message)
                        readGroupList("/")
                    }else{
                        alert(result.errMsg)
                    }
                    
                }
            });
        });
        

    });
}




//加入群组函数
function clickJoinGroupBtn(){

    $("#myfrm").on("click","#joinGroupBtn",function(){
        // alert("点击了加入群组按钮");
          
        $("#joinGroup").on("click","#joinGroupConfirmBtn",function(){
            var id = $("#groupID").val();
            var code = $("#setGroupPwd").val();
            // alert(id)
            // alert(code)

            $.ajax({
                type: "post",
                url: SERVER_PATH + "/joinGroup",
                headers:{"Accept": "application/json; charset=utf-8",
		                "X-Requested-With":'XMLHttpRequest',
		                "token":storage.token},  
                data: {
                    groupId : id,
                    code: code
                },
                dataType: "json",
                success: function (result) {
                    if(result.code == 0){
                        alert(result.message)
                        readGroupList("/")
                    }else{
                        alert(result.errMsg);
                    }
                    
                }
            });
        });


    });
}



//初始化页面
function initGroupInfo(){
	var groupId=getUrlParam("id");
	$.ajax({
		type: "post",
		url: SERVER_PATH + "/getGroupInfo",
		headers:{"Accept": "application/json; charset=utf-8",
		"X-Requested-With":'XMLHttpRequest',
		"token":storage.token}, 
		data: {
			id:groupId
		},
		dataType: "json",
		success: function (result) {
			if(result.code == 0){
				$("#groupName").text(result.data.group.name)
				$("#groupId").text(groupId)
				$("#founder").text(result.data.owner.username)
				$("#regTime").text(new Date(result.data.group.regTime).Format("yyyy-MM-dd hh:mm"))
	
				var dropdown="";
				var friends=result.data.friends;
				friends.map(function (item,index) {
				dropdown  +="<li>\n" +
				"                          <a class=\"dropdown-item\" style=\"padding-left:3px\" href=\"javascript:void(0);\"><img src=\"../../assets/images/avatars/profile-image.png\" alt=\"\"><span class=\"author-name\" style=\"font-size:2px\">"+ item.username+"</span></a>\n" +
				"                        </li>"
				})
				$(".groupMembersList").find(".dropdown-menu").html(dropdown);
				readFileList("/",2,groupId);
			}
			
		}
	});


}


//回收站还原函数
function clickRestore(){

	$(".fsList").on("click",".restoreBtn",function(){
		// alert("点击了还原函数")
		var path = $(this).parents("tr").attr("path");
		// alert(path);

		$.ajax({
			type: "post",
			url: SERVER_PATH + "/reduction",
			headers:{"Accept": "application/json; charset=utf-8",
			"X-Requested-With":'XMLHttpRequest',
			"token":storage.token}, 
			data: {
				path:path
			},
			dataType: "json",
			success: function (data) {
				if(data.code==0){
					// alert("新建成功")
					initRecyleBin();
				}
			}
		});

	});

}



//回收站彻底删除
function clickCompletelyDeleteBtn(){
	$(".fsList").on("click",".completelyDeleteBtn",function(){
		// alert("点击了彻底删除函数")
		var path = $(this).parents("tr").attr("path");
		// alert(path);
		// alert(type)

		$.ajax({
			type: "post",
			url: SERVER_PATH + "/delete",
			headers:{"Accept": "application/json; charset=utf-8",
			"X-Requested-With":'XMLHttpRequest',
			"token":storage.token}, 
			data: {
				path:path,
				type:3
			},
			dataType: "json",
			success: function (data) {
				if(data.code==0){
					alert("彻底删除成功")
					initRecyleBin();
				}else{
					alert(data.errMsg)
				}
			}
		});

	});
}

//回收站文件列表显示函数
function initRecyleBin(){
	$.ajax({
		type: "post",
		url: SERVER_PATH + "/getFileStatus",
		headers:{"Accept": "application/json; charset=utf-8",
			"X-Requested-With":'XMLHttpRequest',
			"token":storage.token}, 
		data: {
			path:"/",
			type:3
		},
		dataType: "json",
		success: function (result) {
		if(result.code == 0){
			var fsList = result.data;
			var fshtml = "";
			fsList.map(function (item,index) {
				SUB_PATH = subPath(item.path)
				$(".fsList").attr("path",subPath(item.path))
					$(".fsList").attr("type",3)
				if(item.dir){
					//设置表格每行的路径
					fshtml += '    <tr path='+escapeHtml(item.path)+'>\n' +
					'\t\t\t\t\t            <td  class="d-none d-lg-table-cell"><input type="checkbox" value="select"></td>\n' +
					'                      <th class="fileName"><img src="../../assets/images/hzh/folder3.png" alt="">'+item.name+'</th>\n' +
					'                      <div>\n' +
					'                        <td class="d-none d-lg-table-cell" >'+item.access_time+'</td>\n' +
					'                        <td class="d-none d-lg-table-cell" >'+item.modification_time+'</td>\n' +
					'                        <td class="d-none d-lg-table-cell">'+item.length+'</td>\n' +
					'                      </div>\n' +
					'                  \n' +
					'                      <td>\n' +
					'                        <div class="d-none d-lg-table-cell">\n' +
					'                          <a href="javascript:void(0);"><span class=" restoreBtn badge bg-info">还原</span></a> \n' +
					'                          <a href="javascript:void(0);"><span class="completelyDeleteBtn badge bg-danger mx-1">彻底删除</span></a>\n' +
					'                        </div>\n' +
					'\n' +
					'                        <div class="d-table-cell d-lg-none">\n' +
					'                          <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false"> 更多 </button>\n' +
					'                          <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">\n' +
					'                            <li><a class="dropdown-item restoreBtn" href="#">还原</a></li>\n' +
					'                            <li><a class="dropdown-item completelyDeleteBtn" href="#">彻底删除</a></li>\n' +
					'                          </ul>\n' +
					'                        </div>\n' +
					'\t\t\t\t\t       </td>\t\t\t  \n' +
					 '             </tr>';
				}else{

					fshtml += '    <tr path='+escapeHtml(item.path)+'>\n' +
					'\t\t\t\t\t            <td  class="d-none d-lg-table-cell"><input type="checkbox" value="select"></td>\n' +
					'                      <th class="fileName"><img src="../../assets/images/hzh/file.png" alt="">'+item.name+'</th>\n' +
					'                      <div>\n' +
					'                        <td class="d-none d-lg-table-cell" >'+item.access_time+'</td>\n' +
					'                        <td class="d-none d-lg-table-cell" >'+item.modification_time+'</td>\n' +
					'                        <td class="d-none d-lg-table-cell">'+fileSizeConvert(item.length)+'</td>\n' +
					'                      </div>\n' +
					'                  \n' +
					'                      <td>\n' +
					'                        <div class="d-none d-lg-table-cell">\n' +
					'                          <a href="javascript:void(0);"><span class=" restoreBtn badge bg-info">还原</span></a> \n' +
					'                          <a href="javascript:void(0);"><span class="completelyDeleteBtn badge bg-danger mx-1">彻底删除</span></a>\n' +
					'                        </div>\n' +
					'\n' +
					'                        <div class="d-table-cell d-lg-none">\n' +
					'                          <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false"> 更多 </button>\n' +
					'                          <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">\n' +
					'                            <li><a class="dropdown-item  restoreBtn" href="#">还原</a></li>\n' +
					'                            <li><a class="dropdown-item completelyDeleteBtn" href="#">彻底删除</a></li>\n' +
					'                          </ul>\n' +
					'                        </div>\n' +
					'\t\t\t\t\t       </td>\t\t\t  \n' +
					 '             </tr>';
				}	
						
			});
			$(".fsList").html(fshtml)
		}
	
	
	}
});

}

//回收站文件列表显示函数
function parseRecyleBinFile(data){
	
			data.map(function (item,index) {
				SUB_PATH = subPath(item.path)
				$(".fsList").attr("path",subPath(item.path))
					$(".fsList").attr("type",3)
					var fsList="";
				if(item.dir){
					//设置表格每行的路径
					fshtml += '    <tr path='+escapeHtml(item.path)+'>\n' +
					'\t\t\t\t\t            <td  class="d-none d-lg-table-cell"><input type="checkbox" value="select"></td>\n' +
					'                      <th class="fileName"><img src="../../assets/images/hzh/folder3.png" alt="">'+item.name+'</th>\n' +
					'                      <div>\n' +
					'                        <td class="d-none d-lg-table-cell" >'+item.access_time+'</td>\n' +
					'                        <td class="d-none d-lg-table-cell" >'+item.modification_time+'</td>\n' +
					'                        <td class="d-none d-lg-table-cell">'+item.length+'</td>\n' +
					'                      </div>\n' +
					'                  \n' +
					'                      <td>\n' +
					'                        <div class="d-none d-lg-table-cell">\n' +
					'                          <a href="javascript:void(0);"><span class=" restoreBtn badge bg-info">还原</span></a> \n' +
					'                          <a href="javascript:void(0);"><span class="completelyDeleteBtn badge bg-danger mx-1">彻底删除</span></a>\n' +
					'                        </div>\n' +
					'\n' +
					'                        <div class="d-table-cell d-lg-none">\n' +
					'                          <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false"> 更多 </button>\n' +
					'                          <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">\n' +
					'                            <li><a class="dropdown-item restoreBtn" href="#">还原</a></li>\n' +
					'                            <li><a class="dropdown-item completelyDeleteBtn" href="#">彻底删除</a></li>\n' +
					'                          </ul>\n' +
					'                        </div>\n' +
					'\t\t\t\t\t       </td>\t\t\t  \n' +
					 '             </tr>';
				}else{

					fshtml += '    <tr path='+escapeHtml(item.path)+'>\n' +
					'\t\t\t\t\t            <td  class="d-none d-lg-table-cell"><input type="checkbox" value="select"></td>\n' +
					'                      <th class="fileName"><img src="../../assets/images/hzh/file.png" alt="">'+item.name+'</th>\n' +
					'                      <div>\n' +
					'                        <td class="d-none d-lg-table-cell" >'+item.access_time+'</td>\n' +
					'                        <td class="d-none d-lg-table-cell" >'+item.modification_time+'</td>\n' +
					'                        <td class="d-none d-lg-table-cell">'+fileSizeConvert(item.length)+'</td>\n' +
					'                      </div>\n' +
					'                  \n' +
					'                      <td>\n' +
					'                        <div class="d-none d-lg-table-cell">\n' +
					'                          <a href="javascript:void(0);"><span class=" restoreBtn badge bg-info">还原</span></a> \n' +
					'                          <a href="javascript:void(0);"><span class="completelyDeleteBtn badge bg-danger mx-1">彻底删除</span></a>\n' +
					'                        </div>\n' +
					'\n' +
					'                        <div class="d-table-cell d-lg-none">\n' +
					'                          <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false"> 更多 </button>\n' +
					'                          <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">\n' +
					'                            <li><a class="dropdown-item  restoreBtn" href="#">还原</a></li>\n' +
					'                            <li><a class="dropdown-item completelyDeleteBtn" href="#">彻底删除</a></li>\n' +
					'                          </ul>\n' +
					'                        </div>\n' +
					'\t\t\t\t\t       </td>\t\t\t  \n' +
					 '             </tr>';
				}	
						
			});
			$(".fsList").html(fshtml)
		
	


}



//点击导航
function fileNavigation(){
	$(".breadcrumb").on("click",".buttonList",function(){
		readFileList($(this).parents("li").attr("path"),getCurrentType(),getGroupId());
	})
}


