// alert("index.js生效！")

$(function(){

/*
	//加载读取文件夹函数
	readDir()


	// 加载删除函数
    clickDeleteBtn()


	//加载修改函数
	clickAlterBtn() 


    //加载搜索
    selectFile();
	
 	//加载新建文件夹函数
    mkdir()



     //加载下载函数
    download()

    //加载退出群组函数
    exitGroup()

    //加载解散群组函数
    dismissGroup()
 
*/
	// 点击分享按钮
	/*$(".fsList").on("click",".shareBtn",function(){

		var path = $(this).parent().attr("path");
		var fileName = path.substring(path.lastIndexOf("/")+1);
		var renameFile = prompt('你要修改的文件是：'+fileName+',请输入修改后的名字');
		
		$.ajax({
			type: "get",
			url: SERVER_PATH + "/",
			data: {
				
			},
			dataType: "json",
			success: function (response) {
				
			}
		});
	});*/


	


});


//=======================以下为自定义函数=========================


//新建文件夹
function mkdir() {  }
$(".page-content").on("click","#mkdir",function(){
	var path = getCurrentPath()
	var type = getCurrentType();
	var groupId = $(this).parents("tr").attr("groupId");
	$("#newFolder").on("click","#newFolerConfirmBtn",function(){
		var dirname =  $("#newFolderInput").val();
		path=path+"/"+dirname
		if(dirname.length>0){
			$.ajax({
				type: "post",
				url: SERVER_PATH + "/mkdir",
				data: {
					newDirPath:path,
					type:type,
					groupId:groupId
				},
				dataType: "json",
				success: function (data) {
					if(data.code==0){
						// alert("新建成功")
						info(getCurrentPath(),type);
					}
				}
			});
		}
	});
	
});

//下载文件
function download() {  

	$(".fsList").on("click",".downloadBtn",function(){
		var type=getCurrentType();
		var path=$(this).parents("tr").attr("path");
        var groupId=getGroupId();
		var url = SERVER_PATH+"/download";
		var fileName = path;
		var form = $("<form></form>").attr("action", url).attr("method", "post");
		form.append($("<input></input>").attr("type", "hidden").attr("name", "path").attr("value", fileName));
		form.append($("<input></input>").attr("type", "hidden").attr("name", "type").attr("value", type));
        form.append($("<input></input>").attr("type", "hidden").attr("name", "groupId").attr("value", groupId));
		form.appendTo('body').submit().remove();
	})

	
}
//查询文件

function selectFile() {  

	$("#selectInput").on("keypress",function(event){
	if(event.keyCode==13){
		var keyword=$("#selectInput").val();
		var path=getCurrentPath();
		var type=getCurrentType();
        var groupId=getGroupId();
	
		$.ajax({	
			type: "get",
			url: SERVER_PATH + "/select",
			data: {
				path:"/",
				type:type,
				keyword:keyword,
                groupId:groupId
			},	
			dataType: "json",		
			success: function (date) {		
				if(date.code==0){
					alert(date.message);
					parseFileData(date.data);
				}else{	
					alert(date.errMsg);		
				}
			}
		});
	}
	})
}

//修改文件名
function clickAlterBtn() { 
	$(".fsList").on("click",".alterBtn",function(){

		var path = $(this).parents("tr").attr("path");
		var type = getCurrentType();
		var fileName = path.substring(path.lastIndexOf("/")+1);
        var groupId=getGroupId();
		var renameFile = prompt('你要修改的文件是：'+fileName+',请输入修改后的名字');
		
		// alert(renameFile)
		if(renameFile){
			$.ajax({
			type: "get",
			url: SERVER_PATH + "/alter",
			data: {
				filePath:path,
				alterName:getCurrentPath()+"/"+renameFile,
				type:type,
                groupId:groupId
			},
			dataType: "json",
			success: function (data) {
				if(data.code == 0){
					//console.log(data.path);
					readFileList(getCurrentPath(),type,groupId);
				}else{
					alert(data.errMsg);
				}
				
			}
		});
		}
		
	});
 }	

	//进入文件夹
	function readDir(){
		$(".fsList").on("click",".isDir",function(){
		var path = $(this).parents("tr").attr("path");
		var type = getCurrentType();
        var groupId=getGroupId()
		groupId?readFileList(path,type,groupId):readFileList(path,type);
		setCurrentPath(path);
	});
	}

//文件大小单位自动转化
function fileSizeConvert(size){
	return size/1024/1024/1024>1?(size/1024/1024/1024).toFixed(2)+" GB":size/1024/1024>1?(size/1024/1024).toFixed(2)+" MB":size/1024>1?(size/1024).toFixed(2)+" KB":size+" B" 
}



//删除函数
function clickDeleteBtn(){
	$(".fsList").on("click",".deleteBtn",function(){
	
		//获取当前点击按钮所在行的路径
		var path = $(this).parents("tr").attr("path");
		var type = getCurrentType();
		//alert(path)
		var fileName = path.substring(path.lastIndexOf("/")+1);
        var groupId=getGroupId();
		var b= confirm("确认删除: "+fileName+" ?");
		if(b){
			$.ajax({
				type: "get",
				url: SERVER_PATH + "/delete",
				data: {
					path : path,
					type : type,
                    groupId:groupId
				},
				dataType: "json",
				success: function (result) {
					if(result.code == 0){
						alert(result.message)
						readFileList(getCurrentPath(),type,groupId)
					}else{
						alert(result.errMsg)
					}
					
				}
			});
		}	

	});

}




	// 点击退出按钮
    function exitGroup(){
         $(".joinGroupClass").on("click",".exitGroup",function(){
        var groupId = $(this).parents("tr").attr("groupId");
        var exit = confirm("确认退出: "+groupId+" ?");
        if(exit){
            $.ajax({
            type: "get",
            url: SERVER_PATH + "/exitGroup",
            data: {
                groupId:groupId
            },
            dataType: "json",
            success: function (data) {
                if(data.code==0){
                    alert(data.message);
                    readGroupList(2)
                }else{
                    alert(data.errMsg);
                }
            }
        });
        }
        
    }); 
    }
  
        // 点击解散按钮
        function dismissGroup(){
            $(".myGroupClass").on("click",".dismissGroup",function(){
            var groupId = $(this).parents("tr").attr("groupId");
            var dismiss = confirm("确认解散: "+groupId+" ?");
            if(dismiss){
                $.ajax({
                type: "get",
                url: SERVER_PATH + "/dismissGroup",
                data: {
                    groupId:groupId
                },
                dataType: "json",
                success: function (data) {
                    if(data.code==0){
                        alert(data.message);
                        readGroupList(2)
                    }else{
                        alert(data.errMsg);
                    }
                }
            });
            }
            
        });
        }
        

//获取当前页面的路径
function getCurrentPath(){
	return $(".fsList").attr("path");
}
//设置当前页面的路径
function setCurrentPath(path){
	return $(".fsList").attr("path",path);
}
//获取当前文件的类型
function getCurrentType(){
	return $(".fsList").attr("type");
}
//设置当前文件的类型
function setCurrentType(type){
	return $(".fsList").attr("type",type);
}
//获取当前群组Id
function getGroupId(){
    return $("#groupId").text();
}
//设置群组Id
function getSroupId(groupId){
    return $("#groupId").text(groupId);
}

//截取当前路径函数
function subPath(path){
	if(path=="/"){
		return "/";
	}
	var i = path.lastIndexOf("/");
	path=path.substring(0,i);
	return path==""?"/":path;
}


//获取路径中属性名为name的数据
function getUrlParam(name) {
    var url = window.location.href;
    if(url!=null && url.indexOf("?")!=-1){
        var url_param = url.split("?")[1];
        var url_param_arr = url_param.split("&");
        for(var i=0;i<url_param_arr.length;i++){
            var tempParam = url_param_arr[i];
            var paramName =  tempParam.split("=")[0];
            if(paramName==name){
                return tempParam.split("=")[1]
            }
        }
    }
    return null;
}

//文件列表显示函数
function readFileList(path,type,groupId){
	$.getJSON(SERVER_PATH + "/getFileStatus",{path:path,type:type,groupId:groupId},function (result) {
		if(result.code == 0){
			var fsList = result.data;
			var fshtml = "";
			fsList.map(function (item,index) {
				SUB_PATH = subPath(item.path)
				$(".fsList").attr("path",subPath(item.path))
					$(".fsList").attr("type",type)
				if(item.dir){
					//设置表格每行的路径
					fshtml += '  <tr path='+escapeHtml(item.path)+'>\n' +
					'\t\t\t\t\t            <td><input type="checkbox" value="select"></td>\n' +
					'                      <td scope="row" class="fileName"><img src="../../assets/images/hzh/folder3.png" alt=""><a href="javascript:void(0);" class="isDir">'+item.name+'</a></td>\n' +
					'                      <td>'+item.modification_time+'</td>\n' +
					'                      <td>'+item.length+'</td>\n' +
					'                      <td></td> \n' +
					'                      <td>\n' +
					'                        <a href="javascript:void(0);" class="deleteBtn"><span class="badge bg-danger mx-1">删除</span></a>\n' +
					'                        <a href="javascript:void(0);" class="alterBtn"><span class="badge bg-success">修改</span></a>\n' +
					'                        <a href="javascript:void(0);" class="shareBtn"><span class="badge bg-secondary mx-1">分享</span></a>\n' +
					'                        <a href="javascript:void(0);" class="collectingBtn"><span class="badge bg-dark mx-1">收藏</span></a>\n' +
					'\t\t\t\t\t           </td>\t\t\t  \n' +
					'            </tr>';
				}else{
					fshtml += '  <tr  path='+escapeHtml(item.path)+">\n "+
					'\t\t\t\t\t            <td><input type="checkbox" value="select"></td>\n' +
					'                      <td scope="row"  class="fileName"><img src="../../assets/images/hzh/file.png" alt="">'+item.name+'</td>\n' +
					'                      <td>'+item.modification_time+'</td>\n' +
					'                      <td>'+fileSizeConvert(item.length)+'</td>\n' +
					'                      <td></td> \n' +
					'                      <td>\n' +
					'                        <a href="javascript:void(0);" class="downloadBtn"><span class="badge bg-info">下载</span></a>\n' +
					'                        <a href="javascript:void(0);" class="deleteBtn"><span class="badge bg-danger mx-1">删除</span></a>\n' +
					'                        <a href="javascript:void(0);" class="alterBtn"><span class="badge bg-success">修改</span></a>\n' +
					'                        <a href="javascript:void(0);" class="shareBtn"><span class="badge bg-secondary mx-1">分享</span></a>\n' +
					'                        <a href="javascript:void(0);" class="collectingBtn"><span class="badge bg-dark mx-1">收藏</span></a>\n' +
					'\t\t\t\t\t           </td>\t\t\t  \n' +
					'             </tr>';
				}	
						
			});
			$(".fsList").html(fshtml)
		}
	});
}


//初始化群组列表
function readGroupList(){

	$.getJSON(SERVER_PATH + "/getFileStatus",{type:2},function (result) {

		if(result.code == 0){
        	var mygroupHtml = "";
        	var joingroupHtml = "";

			result.data.myGroups.map(function (item,index) {
				mygroupHtml +="<tr groupId="+item.id+">\n" +
                "                      <th scope=\"row\">"+item.id+"</th>\n" +
                "                      <th scope=\"row\"><img src=\"../../assets/images/avatars/profile-image.png\" alt=\"\"><a href=\"javascript:void(0);\">"+item.name+"</a></th>\n" +
                "                      <td>"+new Date(item.regTime).Format("yyyy-MM-dd hh:mm")+"</td>\n" +
                "                      <td>\n" +
                "                        <a href=\"groupList.html?id="+item.id+"\"><span class=\"badge bg-info\">进入</span></a>\n" +
                "                        <a href=\"javascript:void(0);\"><span class=\"dismissGroup badge bg-danger mx-1\">解散</span></a>\n" +
                "                      </td> \n" +
                "                    </tr>";
          })

          result.data.joinedGroups.map(function (item,index) {
            joingroupHtml +="<tr groupId="+item.id+">\n" +
            "                      <th scope=\"row\">"+item.id+"</th>\n" +
            "                      <th scope=\"row\"><img src=\"../../assets/images/avatars/profile-image.png\" alt=\"\"><a href=\"javascript:void(0);\">"+item.name+"</a></th>\n" +
            "                      <td>"+item.founder.id+"</td>\n" +
            "                      <td>"+new Date(item.regTime).Format("yyyy-MM-dd hh:mm")+"</td>\n" +
            "                      <td>\n" +
            "                        <a href=\"groupList.html?id="+item.id+"\"><span class=\"badge bg-info\">进入</span></a>\n" +
            "                        <a href=\"javascript:void(0);\"><span class=\"exitGroup badge bg-danger mx-1\">退出</span></a>\n" +
            "                      </td> \n" +
            "                    </tr>"

    })
    $(".myGroupClass").html(mygroupHtml)
    $(".joinGroupClass").html(joingroupHtml)

	}

})
}


//解析后端返回的文件数据
function parseFileData(data){
			var fshtml = "";
			data.map(function (item,index) {
				SUB_PATH = subPath(item.path)
				if(item.dir){
					//设置表格每行的路径
					fshtml += '  <tr path='+escapeHtml(item.path)+' >\n' +
					'\t\t\t\t\t            <td><input type="checkbox" value="select"></td>\n' +
					'                      <td scope="row" class="fileName"><img src="../../assets/images/hzh/folder3.png" alt=""><a href="javascript:void(0);" class="isDir">'+item.name+'</a></td>\n' +
					'                      <td>'+item.modification_time+'</td>\n' +
					'                      <td>'+item.length+'</td>\n' +
					'                      <td></td> \n' +
					'                      <td>\n' +
					'                        <a href="javascript:void(0);" class="deleteBtn"><span class="badge bg-danger mx-1">删除</span></a>\n' +
					'                        <a href="javascript:void(0);" class="alterBtn"><span class="badge bg-success">修改</span></a>\n' +
					'                        <a href="javascript:void(0);" class="shareBtn"><span class="badge bg-secondary mx-1">分享</span></a>\n' +
					'                        <a href="javascript:void(0);" class="collectingBtn"><span class="badge bg-dark mx-1">收藏</span></a>\n' +
					'\t\t\t\t\t           </td>\t\t\t  \n' +
					'            </tr>';
				}else{
					fshtml += '  <tr  path='+escapeHtml(item.path)+">\n "+
					'\t\t\t\t\t            <td><input type="checkbox" value="select"></td>\n' +
					'                      <td scope="row"  class="fileName"><img src="../../assets/images/hzh/file.png" alt="">'+item.name+'</td>\n' +
					'                      <td>'+item.modification_time+'</td>\n' +
					'                      <td>'+fileSizeConvert(item.length)+'</td>\n' +
					'                      <td></td> \n' +
					'                      <td>\n' +
					'                        <a href="javascript:void(0);" class="downloadBtn"><span class="badge bg-info">下载</span></a>\n' +
					'                        <a href="javascript:void(0);" class="deleteBtn"><span class="badge bg-danger mx-1">删除</span></a>\n' +
					'                        <a href="javascript:void(0);" class="alterBtn"><span class="badge bg-success">修改</span></a>\n' +
					'                        <a href="javascript:void(0);" class="shareBtn"><span class="badge bg-secondary mx-1">分享</span></a>\n' +
					'                        <a href="javascript:void(0);" class="collectingBtn"><span class="badge bg-dark mx-1">收藏</span></a>\n' +
					'\t\t\t\t\t           </td>\t\t\t  \n' +
					'             </tr>';
				}
				
						
			});
			$(".fsList").html(fshtml)
	
}


//解析后端返回的群组数据
function parseGroupData(data){
	
    var groupHtml = "";
    data.data.myGroups.map(function (item,index) {
        groupHtml +="<tr groupId="+item.id+">\n" +
        "                      <th scope=\"row\">"+item.id+"</th>\n" +
        "                      <th scope=\"row\"><img src=\"../../assets/images/avatars/profile-image.png\" alt=\"\"><a href=\"javascript:void(0);\">"+item.name+"</a></th>\n" +
        "                      <td>"+1+"</td>\n" +
        "                      <td>\n" +
        "                        <a href=\"groupList.html\"><span class=\"badge bg-info\">进入</span></a>\n" +
        "                        <a href=\"javascript:void(0);\"><span class=\"badge bg-danger mx-1\">删除</span></a>\n" +
        "                      </td> \n" +
        "                    </tr>"
    $(".myGroupClass").html(fshtml)

})
}


//上传文件
function postData(){
	var file=new FormData();
	file.append("file",$("#file")[0].files[0]);
	file.append("type",getCurrentType())
	file.append("path",getCurrentPath())
	file.append("groupId",getGroupId())
	$.ajax({
type: "post",
url:SERVER_PATH + "/upload",
contentType: false,
// 告诉jQuery不要去设置Content-Type请求头
processData:false,
data: file,
dataType: "json",
success: function (result) {
	if(result.code == 0){
		alert(result.message)
		parseFileData(result.data)
	}else{
		alert(result.errMsg)
	}
	
}
});
return false;
  }




  //字符串修正
  function escapeHtml(string) {
	     var entityMap = {
	         "&": "&amp;",
	         "<": "&lt;",
	         ">": "&gt;",
	         '"': '&#34;',
	         "'": '&#39;',
	         "\\": '&#92;',
	         "/": '&#x2F;',
			 " ":'&nbsp;'
	     };
	     return String(string).replace(/[&<>\"\'\/\ ]/g, function (s) {
	         return entityMap[s];
	     });
	 }





    Date.prototype.Format = function (fmt) { //author: meizz
        var o = {
            "M+": this.getMonth() + 1, //月份
            "d+": this.getDate(), //日
            "h+": this.getHours(), //小时
            "m+": this.getMinutes(), //分
            "s+": this.getSeconds(), //秒
            "q+": Math.floor((this.getMonth() + 3) / 3), //季度
            "S": this.getMilliseconds() //毫秒
        };
        if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
        for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        return fmt;
    }

 




