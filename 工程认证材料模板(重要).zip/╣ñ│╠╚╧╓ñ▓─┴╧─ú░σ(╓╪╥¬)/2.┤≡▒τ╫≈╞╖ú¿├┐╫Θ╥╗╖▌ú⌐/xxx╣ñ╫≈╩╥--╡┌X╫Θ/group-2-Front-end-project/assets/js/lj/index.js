//表格全选
$(function() {
	checkBox();

	function checkBox() {
		var $thr = $("table thead tr"); //表格头部的tr
		var $checkAllTh = $("table thead tr").find('input').parent(); //表格头部的的全选按钮
		var $tbr = $("table tbody tr"); //表格内容的tr

		var $checkAll = $thr.find('input'); //表格头部的全选框
		//全选
		$checkAll.click(function(event) {
			//根据表格头部（thead）的全选框的是否选中的状态（true或false）来设置表格内容（tbody）的选择框状态
			$tbr.find('input').prop('checked', $(this).prop('checked'));
			if ($(this).prop('checked')) {
				$tbr.find('input').parent().parent().addClass('danger');
			} else {
				$tbr.find('input').parent().parent().removeClass('danger');
			}
			//防止点击事件向父元素冒泡    必须加阻止事件冒泡，不然会出现单击全选框按钮无作用的情况
			event.stopPropagation();
		});

		//点击表格头部全选框所在的单元格时也触发全选框的点击操作
		$checkAllTh.click(function() {
			$(this).find('input').click();
		});


		//点击表格内容（tbody）下面的每一行的选择框
		$tbr.find('input').click(function(event) {
			//给选中和未选中，添加和删除样式
			$(this).parent().parent().toggleClass('danger');
			//判断tbody里面的已经选中的input长度和表格内容本有的input长度是有相等，如果相等，则把theard的选择框置为选中，
			$checkAll.prop('checked', $tbr.find('input:checked').length == $tbr.find('input').length ?
				true : false);
			event.stopPropagation(); //防止点击事件向父元素冒泡    必须加阻止事件冒泡，不然会出现单击每一行内容的选框按钮无作用的情况  
		});
	}
})

/**
 * 调用方式
 * onclick="javascript:sureDelete()"
 *  <a href="javascript:void(0);" class="deleteBtn" onclick="javascript:sureDelete()"><span class="badge bg-danger mx-1">删除</span></a>
*/
//下载前确认
// $(".uploadBtn").onclick=function(){
// 	alert("删除")
// }
// function sureUpload(){
// 	var upload;
// 	upload=confirm("确定下载？")
// 	if(upload==true){
// 		return true;
// 	}else{
// 		return false;
// 	}
// }

// //删除前确认
// function sureDelete(){
// 	var delete;
// 	delete=confirm("确定删除？")
// 	if(delete==true){
// 		return true;
// 	}else{
// 		return false;
// 	}
// }

// //分享前确认
// function sureShare(){
// 	var share;
// 	share=confirm("确定将此文件分享到共享文件夹？")
// 	if(share==true){
// 		return true;
// 	}else{
// 		return false;
// 	}
// }

// function upload(){
// 	alert("上传")
// }

// //文件列表显示函数
// function info(path){
// 	$.getJSON(SERVER_PATH + "/readDir1",{url:path},function (data) {
// 		if(data.success){
// 			// alert(data.fsList);
// 			var fsList = data.fsList;
// 					var fshtml = "";
// 					fsList.map(function (item,index) {
// 						SUB_PATH = subPath(item.path)
// 						if(item.isdir){
// 							$(".fsList").attr("path",item.path)


// 							fshtml += '  <tr path='+item.path+'>\n' +
// 							'\t\t\t\t\t            <td><input type="checkbox" value="select"></td>\n' +
// 							'                      <td scope="row" class="fileName"><img src="../../assets/images/index/folder.png" alt=""><a href="javascript:void(0);" class="isDir">'+item.name+'</a></td>\n' +
// 							'                      <td>'+item.modification_time+'</td>\n' +
// 							'                      <td>'+item.length+'</td>\n' +
// 							'                      <td>'+item.length+'</td> \n' +
// 							'                      <td>\n' +
// 							'                        <a href="javascript:void(0);" class="uploadBtn"><span class="badge bg-info">下载</span></a>\n' +
// 							'                        <a href="javascript:void(0);" class="deleteBtn"><span class="badge bg-danger mx-1">删除</span></a>\n' +
// 							'                        <a href="javascript:void(0);" class="alterBtn"><span class="badge bg-success">修改</span></a>\n' +
// 							'                        <a href="javascript:void(0);" class="shareBtn"><span class="badge bg-secondary mx-1">分享</span></a>\n' +
// 							'                        <a href="javascript:void(0);" class="collectingBtn"><span class="badge bg-dark mx-1">收藏</span></a>\n' +
// 							'\t\t\t\t\t           </td>\t\t\t  \n' +
// 							'                    </tr>';
// 						}else{
// 							// var name = item.name;
// 							// var index = name.lastIndexOf(".");
// 							// var match = name.substring(index+1);
// 							// switch(match){
// 							// 	case "png": case "jpg": case "gif": case "psd":
								
// 							// }
// 							fshtml += '  <tr path='+item.path+'>\n' +
// 							'\t\t\t\t\t            <td><input type="checkbox" value="select"></td>\n' +
// 							'                      <td scope="row"  class="fileName"><img src="../../assets/images/avatars/profile-image.png" alt="">'+item.name+'</td>\n' +
// 							'                      <td>'+item.modification_time+'</td>\n' +
// 							'                      <td>'+item.length+'</td>\n' +
// 							'                      <td>'+item.length+'</td> \n' +
// 							'                      <td>\n' +
// 							'                        <a href="javascript:void(0);" class="uploadBtn"><span class="badge bg-info">下载</span></a>\n' +
// 							'                        <a href="javascript:void(0);" class="deleteBtn"><span class="badge bg-danger mx-1">删除</span></a>\n' +
// 							'                        <a href="javascript:void(0);" class="alterBtn"><span class="badge bg-success">修改</span></a>\n' +
// 							'                        <a href="javascript:void(0);" class="shareBtn"><span class="badge bg-secondary mx-1">分享</span></a>\n' +
// 							'                        <a href="javascript:void(0);" class="collectingBtn"><span class="badge bg-dark mx-1">收藏</span></a>\n' +
// 							'\t\t\t\t\t           </td>\t\t\t  \n' +
// 							'                    </tr>';
// 						}
						
								
// 					});
// 					$(".fsList").html(fshtml)
// 		}
// 	});

// }