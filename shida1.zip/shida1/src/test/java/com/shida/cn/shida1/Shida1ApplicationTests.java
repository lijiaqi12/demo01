package com.shida.cn.shida1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Shida1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
