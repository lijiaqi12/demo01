package com.shida.cn.shida1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Shida1Application {

    public static void main(String[] args) {
        SpringApplication.run(Shida1Application.class, args);
    }

}
