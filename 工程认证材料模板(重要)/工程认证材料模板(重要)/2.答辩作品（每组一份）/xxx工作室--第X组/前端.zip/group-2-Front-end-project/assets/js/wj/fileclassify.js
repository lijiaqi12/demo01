/**
 * 
 * @param {*} fileName 
 * @returns 
 * 文件分类
 * 1、获取个人文件存储空间中的所有文件
 * 2、获取文件类型
 * 3、按文件类型在页面上异步刷新显示“文件列表”
 */


 $(function(){
	//初始化页面
	init(getUrlParam("id"));
	setCurrentType(2);
	setCurrentPath("/");


	//加载读取文件夹函数
	readDir()


	// 加载删除函数
    clickDeleteBtn()


	//加载修改函数
	clickAlterBtn() 


    //加载搜索
    selectFile();
	

     //加载下载函数
    download();

    //文件预览
	filepreview();
});

function getFileType(fileName) {
    // 后缀获取
    let suffix = '';
    // 获取类型结果
    let result = '';
    try {
    const flieArr = fileName.split('.');
    suffix = flieArr[flieArr.length - 1];
    } catch (err) {
    suffix = '';
    }
    // fileName无后缀返回 false
    if (!suffix) { return false; }
    suffix = suffix.toLocaleLowerCase();
    // 图片格式
    const imglist = ['png', 'jpg', 'jpeg', 'bmp', 'gif'];
    // 进行图片匹配
    result = imglist.find(item => item === suffix);
    if (result) {
    return 'image';
    }
    // 匹配txt
    const txtlist = ['txt'];
    result = txtlist.find(item => item === suffix);
    if (result) {
    return 'txt';
    }
    // 匹配 excel
    const excelist = ['xls', 'xlsx'];
    result = excelist.find(item => item === suffix);
    if (result) {
    return 'excel';
    }
    // 匹配 word
    const wordlist = ['doc', 'docx'];
    result = wordlist.find(item => item === suffix);
    if (result) {
    return 'word';
    }
    // 匹配 pdf
    const pdflist = ['pdf'];
    result = pdflist.find(item => item === suffix);
    if (result) {
    return 'pdf';
    }
    // 匹配 ppt
    const pptlist = ['ppt', 'pptx'];
    result = pptlist.find(item => item === suffix);
    if (result) {
    return 'ppt';
    }
    // 匹配 视频
    const videolist = ['mp4', 'm2v', 'mkv', 'rmvb', 'wmv', 'avi', 'flv', 'mov', 'm4v'];
    result = videolist.find(item => item === suffix);
    if (result) {
    return 'video';
    }
    // 匹配 音频
    const radiolist = ['mp3', 'wav', 'wmv'];
    result = radiolist.find(item => item === suffix);
    if (result) {
    return 'radio';
    }
    // 其他 文件类型
    return 'other';
    }
    console.log(getFileType("jb51.jpg"));


    
    //文件列表显示函数
function info(path,type,groupId){
	$.getJSON(SERVER_PATH + "/getFileStatus",{path:path,type:type,groupId:groupId},function (result) {
		if(result.code == 0){
			var fsList = result.data;
			var fshtml = "";
			fsList.map(function (item,index) {
				SUB_PATH = subPath(item.path)
				$(".fsList").attr("path",subPath(item.path))
					$(".fsList").attr("type",type)
				if(item.dir){
					//设置表格每行的路径
					fshtml += ' <tr path='+escapeHtml(item.path)+'>\n' +
    '\t\t\t\t\t            <td  class="d-none d-lg-table-cell"><input type="checkbox" value="select"></td>\n' +
    '                      <td  class="fileName"><img src="../../assets/images/hzh/folder3.png" alt=""><a href="javascript:void(0);" class="isDir">'+item.name+'</a></td>\n' +
    '                      <div>\n' +
    '                        <td class="d-none d-lg-table-cell" >'+item.modification_time+'</td>\n' +
    '                        <td class="d-none d-lg-table-cell">'+item.length+'</td>\\n\'</td>\n' +
    // '                        <td class="d-none d-lg-table-cell"></td>\n' +
    '                      </div>\n' +
    '                  \n' +
    '                      <td>\n' +
    '                        <div class="d-none d-lg-table-cell">\n' +
    '                          <a href="javascript:void(0);" class="downloadBtn"><span class="badge bg-info">下载</span></a> \n' +
    '                          <a href="javascript:void(0);" class="deleteBtn"><span class="badge bg-danger mx-1">删除</span></a>\n' +
    '                          <a href="javascript:void(0);" class="alterBtn"><span class="badge bg-success">修改</span></a>\n' +
    '                          <a href="javascript:void(0);" class="shareBtn"><span class="badge bg-secondary mx-1">分享</span></a> \n' +
    '                          <a href="javascript:void(0);" class="collectingBtn"><span class="badge bg-dark mx-1">收藏</span></a>\n' +
    '                          <a href="javascript:void(0);" class="filepreviewBtn"><span class="badge bg-primary mx-1">预览</span></a>\n' +

    '                        </div>\n' +
    '\n' +
    '                        <div class="d-table-cell d-lg-none">\n' +
    '                          <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false"> 更多 </button>\n' +
    '                          <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">\n' +
    '                            <li><a class="dropdown-item downloadBtn" href="#">下载</a></li>\n' +
    '                            <li><a class="dropdown-item deleteBtn" href="javascript:void(0);">删除</a></li>\n' +
    '                            <li><a class="dropdown-item alterBtn" href="#">修改</a></li>\n' +
    '                            <li><a class="dropdown-item shareBtn" href="#">分享</a></li>\n' +
    '                            <li><a class="dropdown-item collectingBtn" href="#">收藏</a></li>\n' +
    '                          </ul>\n' +
    '                        </div>\n' +
    '                        \n' +
    '\t\t\t\t\t            </td>\t\t\t  \n' +
	'                    </tr>' ;
				}else{
					fshtml += ' <tr path='+escapeHtml(item.path)+'>\n' +
    '\t\t\t\t\t            <td  class="d-none d-lg-table-cell"><input type="checkbox" value="select"></td>\n' +
    '                      <td  class="fileName"><img src="../../assets/images/hzh/file.png" alt="">'+item.name+'</td>\n' +
    '                      <div>\n' +
    '                        <td class="d-none d-lg-table-cell" >'+item.modification_time+'</td>\n' +
    '                        <td class="d-none d-lg-table-cell">'+fileSizeConvert(item.length)+'</td>\\n\'</td>\n' +
    // '                        <td class="d-none d-lg-table-cell"></td>\n' +
    '                      </div>\n' +
    '                  \n' +
    '                      <td>\n' +
    '                        <div class="d-none d-lg-table-cell">\n' +
    '                          <a href="javascript:void(0);" class="downloadBtn"><span class="badge bg-info">下载</span></a> \n' +
    '                          <a href="javascript:void(0);" class="deleteBtn"><span class="badge bg-danger mx-1">删除</span></a>\n' +
    '                          <a href="javascript:void(0);" class="alterBtn"><span class="badge bg-success">修改</span></a>\n' +
    '                          <a href="javascript:void(0);" class="shareBtn"><span class="badge bg-secondary mx-1">分享</span></a> \n' +
    '                          <a href="javascript:void(0);" class="collectingBtn"><span class="badge bg-dark mx-1">收藏</span></a>\n' +
    '                          <a href="javascript:void(0);" class="filepreviewBtn"><span class="badge bg-primary mx-1">预览</span></a>\n' +
    '                        </div>\n' +
    '\n' +
    '                        <div class="d-table-cell d-lg-none">\n' +
    '                          <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false"> 更多 </button>\n' +
    '                          <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">\n' +
    '                            <li><a class="dropdown-item downloadBtn" href="#">下载</a></li>\n' +
    '                            <li><a class="dropdown-item deleteBtn" href="javascript:void(0);">删除</a></li>\n' +
    '                            <li><a class="dropdown-item alterBtn" href="#">修改</a></li>\n' +
    '                            <li><a class="dropdown-item shareBtn" href="#">分享</a></li>\n' +
    '                            <li><a class="dropdown-item collectingBtn" href="#">收藏</a></li>\n' +
    '                          </ul>\n' +
    '                        </div>\n' +
    '                        \n' +
    '\t\t\t\t\t            </td>\t\t\t  \n' +
	'                    </tr>' ;
				}	
						
			});
			$(".fsList").html(fshtml)
		}
	});
}