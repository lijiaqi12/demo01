//记住用户名,默认不记住
    var checkFlag = false;
    function remeberNameAndPwd(){
        //这里是当页面是从注册页面注册成功过来
        var remFlag = $("#remember").is(':checked');
        if(remFlag==true){
            checkFlag = true;
        }
        //当在login.html页面点击是否记住z
        $("#remember").click(function(){
            var remFlag = $("#remember").is(':checked');
            if(remFlag==true){
                $("#remember").attr("checked",true);
                checkFlag=true;
            }else{
                $("#remember").attr("checked",false);
                checkFlag=false;
            }
        })
    }
 
    
    //写入cookie与删除
    function setAndRemoveCookie(){
        //注意 密码写入cookie的时候这里没有写加密 是不安全的
        if(checkFlag){
            var name = $("#name").val();
            var password = $("#password").val();
            $.cookie("remember","true",{expires : 7 })//单位：天
            $.cookie("name",name,{expires: 7 });
            $.cookie("password",password,{expires: 7 })
        }else{
            //删除cookie
            $.cookie("remember","false",{expires:-1 });
            $.cookie("name",null,{expires:-1});
            $.cookie("password",null,{expires:-1});
        }
    }
 
    //获取cookie
    /*function getCookie(){
        if($.cookie("remember")=="true"){
            $("#remember").attr("checked",true);
            $("#uname").val($.cookie("uname"));
            $("#password").val($.cookie("password"));
        }
    }*/
 
   /* $(function(){
        getCookie();//获取cookie
        remeberNameAndPwd();//remember点击事件
    });*/
 
    //登录
    function login() {
        var uname = $("#uname").val()
        var password = $("#password").val();
        //是否管理员登录
        
        /*if($(".tips ").is(":visible")){
            return;
        }
        if (name == "") {
            showError("请输入用户名");
            return;
        }
        if (password == "") {
            showError("请输入密码");
            return false;
        }*/
        $.ajax({
            url : 'http://localhost:8080/login',
            type:'post',
            data : {
                username : uname,
                password : password,
            },
            dataType : 'json',
            cache:false,
            success : function(data) {
                if(data.code==0){
                    alert(data.message);
                    window.location="index.html";
                }else{
                    alert(data.errMsg);
                }

                /*if ("0"==d.err) {
                    setAndRemoveCookie();//是否写入cookie
                    window.location.href = d.url;
                }else{
                    //showError(d.msg);
                    return false;
                }*/
            }
        })
    }
        //快速登录
        function fastLoginByPhone() {
            var uname = $("#floatingInput").val()
            var password = $("#floatingPassword").val();
            $.ajax({
                url : 'http://localhost:8080/fastLoginByPhone',
                type:'post',
                data : {
                    phone : uname,
                    code : password,
                },
                dataType : 'json',
                cache:false,
                success : function(data) {
                    if(data.code==0){
                        alert(data.message);
                        window.location="index.html";
                    }else{
                        alert(data.errMsg);
                    }

                }
            })
    }
    function sendCode() {
        var phone = $("#floatingInput").val()
        var password = $("#floatingPassword").val();

        $.ajax({
            url : 'http://localhost:8080/sendPhoneCode',
            type:'post',
            data : {
                phone : phone,
            },
            dataType : 'json',
            cache:false,
            success : function(data) {
                if(data.code==0){
                    alert(data.message);
                }else{
                    alert(data.errMsg);
                }

            }
        })
}

