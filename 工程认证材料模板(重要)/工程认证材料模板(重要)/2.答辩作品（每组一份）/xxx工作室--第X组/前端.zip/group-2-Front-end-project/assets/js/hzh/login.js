var uuid=generateUUID()

$(function() {

    //var uuid=generateUUID();
    //初始化图形验证码
    var verifyCodePath = SERVER_PATH + "/getTextCode?uuid="+uuid; 
    $(".VerifyCode").attr("src",verifyCodePath)

});


function generateUUID() {
    var d = new Date().getTime();
    if (window.performance && typeof window.performance.now === "function") {
        d += performance.now(); //use high-precision timer if available
    }
    var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        var r = (d + Math.random() * 16) % 16 | 0;
        d = Math.floor(d / 16);
        return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
    });
    return uuid;
}


// ================以下为自定义函数======================
 
    //用户名登录
    function login() {
        var uname = $("#uname").val().trim();
        var password = $("#password").val();
        var code = $("#code").val();
        
        $.ajax({
            url : SERVER_PATH + "/login",
            type:'post',
            data : {
                username : uname,
                password : password,
                code : code,
                uuid : uuid
            },
            dataType : 'json',
            cache:false,
            success : function(data) {
                if(data.code==0){
                    storage.setItem("token",data.token);
                    window.location="index.html";
                }else{
                    alert(data.errMsg);
                }
            }
        })
    }


    //手机短信快速登录
    function fastLoginByPhone() {
        var fastphone = $("#fastphone").val().trim();
        var code = $("#code").val();
        $.ajax({
            url : SERVER_PATH + '/fastLoginByPhone',
            type:'post',
            data : {
                phone : fastphone,
                code : code,
            },
            dataType : 'json',
            cache:false,
            success : function(data) {
                if(data.code==0){
                    alert(data.message);
                    storage.setItem("token",data.token);
                    window.location="index.html";
                }else{
                    alert(data.errMsg);
                }

            }
        })
    }

    
    //手机验证重置密码
    function resetPasswordByPhone() {
        var uname = $("#uname").val().trim();
        var fastphone = $("#fastphone").val().trim();
        var code = $("#code").val();
        var newpwd = $("#newPassword").val();
        var reNewPwd = $("#reNewPassword").val();
        $.ajax({
            url : SERVER_PATH + '/resetPasswordByPhone',
            type:'post',
            data : {
                username : uname,
                phone : fastphone,
                code : code,
                password : newpwd,
                tPassword : reNewPwd
            },
            dataType : 'json',
            cache:false,
            success : function(data) {
                if(data.code==0){
                    alert(data.message);
                    storage.setItem("token",data.token);
                    window.location="login.html";
                }else{
                    alert(data.errMsg);
                }

            }
        })
    }

    // //发送手机验证码
    // function sendCode() {
    //     var phone = $("#fastphone").val()
    //     var code = $("#code").val();

    //     $.ajax({
    //         url : SERVER_PATH + '/sendPhoneCode',
    //         type:'post',
    //         data : {
    //             phone : phone,
    //         },
    //         dataType : 'json',
    //         cache:false,
    //         success : function(data) {
    //             if(data.code==0){
    //                 countdownHandler();
    //                 // alert(data.message);
    //             }else{
    //                 alert(data.errMsg);
    //             }

    //         }
    //     })
    // }


    // //短信验证码倒计时
	// function countdownHandler(){
	// 	var $button = $(".sendVerifyCode");
	// 	var number = 60;
	// 	var countdown = function(){
	// 		if (number == 0) {
	// 			$button.attr("disabled",false);
	// 			$button.html("发送验证码");
	//             number = 60;
	//             return;
	//         } else {
	//         	$button.attr("disabled",true);
	//         	$button.html(number + "秒 重新发送");
	//         	number--;
	//         }
	// 		setTimeout(countdown,1000);
	// 	}
	// 	setTimeout(countdown,1000);
	// }

