//alert("lj_index.js生效")
//表格全选
$(function() {
	checkBox();

	function checkBox() {
		var $thr = $("table thead tr"); //表格头部的tr
		var $checkAllTh = $("table thead tr").find('input').parent(); //表格头部的的全选按钮
		var $tbr = $("table tbody tr"); //表格内容的tr

		var $checkAll = $thr.find('input'); //表格头部的全选框
		//全选
		$checkAll.click(function(event) {
			//根据表格头部（thead）的全选框的是否选中的状态（true或false）来设置表格内容（tbody）的选择框状态
			$tbr.find('input').prop('checked', $(this).prop('checked'));
			if ($(this).prop('checked')) {
				$tbr.find('input').parent().parent().addClass('danger');
			} else {
				$tbr.find('input').parent().parent().removeClass('danger');
			}
			//防止点击事件向父元素冒泡    必须加阻止事件冒泡，不然会出现单击全选框按钮无作用的情况
			event.stopPropagation();
		});

		//点击表格头部全选框所在的单元格时也触发全选框的点击操作
		$checkAllTh.click(function() {
			$(this).find('input').click();
		});


		//点击表格内容（tbody）下面的每一行的选择框
		$tbr.find('input').click(function(event) {
			//给选中和未选中，添加和删除样式
			$(this).parent().parent().toggleClass('danger');
			//判断tbody里面的已经选中的input长度和表格内容本有的input长度是有相等，如果相等，则把theard的选择框置为选中，
			$checkAll.prop('checked', $tbr.find('input:checked').length == $tbr.find('input').length ?
				true : false);
			event.stopPropagation(); //防止点击事件向父元素冒泡    必须加阻止事件冒泡，不然会出现单击每一行内容的选框按钮无作用的情况  
		});
	}
})

// $('.uploadBtn').click(function(){
	
// 	$('#myModal').modal('show');
// })

// window.alert =alert;
//     function alert(e){
//         $("body").append('<div id="msg"><div id="msg_top">信息<span class="msg_close">×</span></div><div id="msg_cont">'+e+'</div><div class="msg_close" id="msg_clear">确定</div></div>');
//         $(".msg_close").click(function (){
//             $("#msg").remove();
//         });
//     }