// alert("index.js生效！")

$(function(){

	//初始化页面
	info("/",1)
	setCurrentType(1);
	setCurrentPath("/");
	//加载读取文件夹函数
	readDir()


	// 加载删除函数
    clickDeleteBtn()


	//加载修改函数
	clickAlterBtn() 


    //加载搜索
    selectFile();
	
 

	// 点击分享按钮
	$(".fsList").on("click",".shareBtn",function(){

		var path = $(this).parent().attr("path");
		var fileName = path.substring(path.lastIndexOf("/")+1);
		var renameFile = prompt('你要修改的文件是：'+fileName+',请输入修改后的名字');
		
		$.ajax({
			type: "get",
			url: SERVER_PATH + "/",
			data: {
				
			},
			dataType: "json",
			success: function (response) {
				
			}
		});
	});

	//加载新建文件夹方法
	mkdir()



	//加载下载方法
	download()

	


});


//=======================以下为自定义函数=========================


//新建文件夹
function mkdir() {  }
$(".page-content").on("click","#mkdir",function(){
	var path = getCurrentPath()
	var type = getCurrentType();
	var groupId = $(this).parents("tr").attr("groupId");
	$("#newFolder").on("click","#newFolerConfirmBtn",function(){
		var dirname =  $("#newFolderInput").val();
		path=path+"/"+dirname
		if(dirname.length>0){
			$.ajax({
				type: "post",
				url: SERVER_PATH + "/mkdir",
				data: {
					newDirPath:path,
					type:type,
					groupId:groupId
				},
				dataType: "json",
				success: function (data) {
					if(data.code==0){
						// alert("新建成功")
						info(getCurrentPath(),type);
					}
				}
			});
		}
	});
	
});

//下载文件
function download() {  

	$(".fsList").on("click",".downloadBtn",function(){
		var type=getCurrentType();
		var path=$(this).parents("tr").attr("path");
		var url = SERVER_PATH+"/download";
		var fileName = path;
		var form = $("<form></form>").attr("action", url).attr("method", "post");
		form.append($("<input></input>").attr("type", "hidden").attr("name", "path").attr("value", fileName));
		form.append($("<input></input>").attr("type", "hidden").attr("name", "type").attr("value", type));
		form.appendTo('body').submit().remove();
	})

	
}
//查询文件

function selectFile() {  

	$("#selectInput").on("keypress",function(event){
	if(event.keyCode==13){
		var keyword=$("#selectInput").val();
		var path=getCurrentPath();
		var type=getCurrentType();
	
		$.ajax({	
			type: "get",
			url: SERVER_PATH + "/select",
			data: {
				path:"/",
				type:type,
				keyword:keyword
			},	
			dataType: "json",		
			success: function (date) {		
				if(date.code==0){
					alert(date.message);
					parseFileData(date.data,type);
				}else{	
					alert(date.errMsg);		
				}
			}
		});
	}
	})
}

//修改文件名
function clickAlterBtn() { 
	$(".fsList").on("click",".alterBtn",function(){

		var path = $(this).parents("tr").attr("path");
		var type = getCurrentType();
		var fileName = path.substring(path.lastIndexOf("/")+1);
		var renameFile = prompt('你要修改的文件是：'+fileName+',请输入修改后的名字');
		
		// alert(renameFile)
		if(renameFile!=null){
			$.ajax({
			type: "get",
			url: SERVER_PATH + "/alter",
			data: {
				filePath:path,
				alterName:getCurrentPath()+"/"+renameFile,
				type:type
			},
			dataType: "json",
			success: function (data) {
				if(data.code == 0){
					//console.log(data.path);
					info(getCurrentPath(),type);
				}else{
					alert(data.errMsg);
				}
				
			}
		});
		}
		
	});
 }	

	//进入文件夹
	function readDir(groupId){
		$(".fsList").on("click",".isDir",function(){
		var path = $(this).parents("tr").attr("path");
		var type = getCurrentType();
		groupId?info(path,type):info(path,type,groupId);
		setCurrentPath(path);
	});
	}

//文件大小单位自动转化
function fileSizeConvert(size){
	return size/1024/1024/1024>1?(size/1024/1024/1024).toFixed(2)+" GB":size/1024/1024>1?(size/1024/1024).toFixed(2)+" MB":size/1024>1?(size/1024).toFixed(2)+" KB":size+" B" 
}



//删除函数
function clickDeleteBtn(){
	$(".fsList").on("click",".deleteBtn",function(){
	
		//获取当前点击按钮所在行的路径
		var path = $(this).parents("tr").attr("path");
		var type = getCurrentType();
	
		var fileName = path.substring(path.lastIndexOf("/")+1);

		var b= confirm("确认删除: "+fileName+" ?");
		if(b){
			$.ajax({
				type: "get",
				url: SERVER_PATH + "/delete",
				data: {
					path : path,
					type : type
				},
				dataType: "json",
				success: function (result) {
					if(result.code == 0){
						alert(result.message)
						info(getCurrentPath(),type)
					}else{
						alert(result.errMsg)
					}
					
				}
			});
		}	

	});

}


//获取当前页面的路径
function getCurrentPath(){
	return $(".fsList").attr("path");
}
//设置当前页面的路径
function setCurrentPath(path){
	return $(".fsList").attr("path",path);
}
//获取当前文件的类型
function getCurrentType(){
	return $(".fsList").attr("type");
}
//设置当前文件的类型
function setCurrentType(type){
	return $(".fsList").attr("type",type);
}

//截取当前路径函数
function subPath(path){
	if(path=="/"){
		return "/";
	}
	var i = path.lastIndexOf("/");
	path=path.substring(0,i);
	return path==""?"/":path;
}


//文件列表显示函数
function info(path,type,groupId){
	$.getJSON(SERVER_PATH + "/getFileStatus",{path:path,type:type,groupId:groupId},function (result) {
		if(result.code == 0){
			var fsList = result.data;
			var fshtml = "";
			fsList.map(function (item,index) {
				SUB_PATH = subPath(item.path)
				$(".fsList").attr("path",subPath(item.path))
					$(".fsList").attr("type",type)
				if(item.dir){
					//设置表格每行的路径
					fshtml += '  <tr '+escapeHtml(item.path)+'>\n' +
					// '\t\t\t\t\t            <td><input type="checkbox" value="select"></td>\n' +
					'                      <td  class="fileName"><img src="../../assets/images/hzh/folder3.png" alt=""><a href="javascript:void(0);" class="isDir">'+item.name+'</a></td>\n' +
					// '                      <td>'+item.modification_time+'</td>\n' +
					// '                      <td>'+item.length+'</td>\n' +
					// '                      <td></td> \n' +
					'                      <td>\n' +
					'                        <a href="javascript:void(0);" class="deleteBtn"><span class="badge bg-danger mx-1">删除</span></a>\n' +
					'                        <a href="javascript:void(0);" class="alterBtn"><span class="badge bg-success">修改</span></a>\n' +
					'                        <a href="javascript:void(0);" class="shareBtn"><span class="badge bg-secondary mx-1">分享</span></a>\n' +
					'                        <a href="javascript:void(0);" class="collectingBtn"><span class="badge bg-dark mx-1">收藏</span></a>\n' +
					'\t\t\t\t\t           </td>\t\t\t  \n' +
					'            </tr>';
				}else{
					fshtml += '  <tr  path='+escapeHtml(item.path)+">\n "+
					// '\t\t\t\t\t            <td><input type="checkbox" value="select"></td>\n' +
					'                      <td   class="fileName"><img src="../../assets/images/hzh/file.png" alt="">'+item.name+'</td>\n' +
					// '                      <td>'+item.modification_time+'</td>\n' +
					// '                      <td>'+fileSizeConvert(item.length)+'</td>\n' +
					// '                      <td></td> \n' +
					'                      <td>\n' +
					'                        <a href="javascript:void(0);" class="downloadBtn"><span class="badge bg-info">下载</span></a>\n' +
					'                        <a href="javascript:void(0);" class="deleteBtn"><span class="badge bg-danger mx-1">删除</span></a>\n' +
					'                        <a href="javascript:void(0);" class="alterBtn"><span class="badge bg-success">修改</span></a>\n' +
					'                        <a href="javascript:void(0);" class="shareBtn"><span class="badge bg-secondary mx-1">分享</span></a>\n' +
					'                        <a href="javascript:void(0);" class="collectingBtn"><span class="badge bg-dark mx-1">收藏</span></a>\n' +
					'\t\t\t\t\t           </td>\t\t\t  \n' +
					'             </tr>';
				}	
						
			});
			$(".fsList").html(fshtml)
		}
	});
}
//解析后端返回的文件数据
function parseFileData(data){
			var fshtml = "";
			data.map(function (item,index) {
				SUB_PATH = subPath(item.path)
				if(item.dir){
					//设置表格每行的路径
					fshtml += '  <tr path='+escapeHtml(item.path)+' >\n' +
					'\t\t\t\t\t            <td><input type="checkbox" value="select"></td>\n' +
					'                      <td scope="row" class="fileName"><img src="../../assets/images/hzh/folder3.png" alt=""><a href="javascript:void(0);" class="isDir">'+item.name+'</a></td>\n' +
					'                      <td>'+item.modification_time+'</td>\n' +
					'                      <td>'+item.length+'</td>\n' +
					'                      <td></td> \n' +
					'                      <td>\n' +
					'                        <a href="javascript:void(0);" class="deleteBtn"><span class="badge bg-danger mx-1">删除</span></a>\n' +
					'                        <a href="javascript:void(0);" class="alterBtn"><span class="badge bg-success">修改</span></a>\n' +
					'                        <a href="javascript:void(0);" class="shareBtn"><span class="badge bg-secondary mx-1">分享</span></a>\n' +
					'                        <a href="javascript:void(0);" class="collectingBtn"><span class="badge bg-dark mx-1">收藏</span></a>\n' +
					'\t\t\t\t\t           </td>\t\t\t  \n' +
					'            </tr>';
				}else{
					fshtml += '  <tr  path='+escapeHtml(item.path)+">\n "+
					'\t\t\t\t\t            <td><input type="checkbox" value="select"></td>\n' +
					'                      <td scope="row"  class="fileName"><img src="../../assets/images/hzh/file.png" alt="">'+item.name+'</td>\n' +
					'                      <td>'+item.modification_time+'</td>\n' +
					'                      <td>'+fileSizeConvert(item.length)+'</td>\n' +
					'                      <td></td> \n' +
					'                      <td>\n' +
					'                        <a href="javascript:void(0);" class="downloadBtn"><span class="badge bg-info">下载</span></a>\n' +
					'                        <a href="javascript:void(0);" class="deleteBtn"><span class="badge bg-danger mx-1">删除</span></a>\n' +
					'                        <a href="javascript:void(0);" class="alterBtn"><span class="badge bg-success">修改</span></a>\n' +
					'                        <a href="javascript:void(0);" class="shareBtn"><span class="badge bg-secondary mx-1">分享</span></a>\n' +
					'                        <a href="javascript:void(0);" class="collectingBtn"><span class="badge bg-dark mx-1">收藏</span></a>\n' +
					'\t\t\t\t\t           </td>\t\t\t  \n' +
					'             </tr>';
				}
				
						
			});
			$(".fsList").html(fshtml)
	
}





//上传文件
function postData(){
	var file=new FormData();
	file.append("file",$("#file")[0].files[0]);
	file.append("type",$(".fsList").attr("type"))
	file.append("path",$(".fsList").attr("path"))
	file.append("groupId",$("#groupId").text())
	$.ajax({
		type: "post",
		url:SERVER_PATH + "/upload",
		contentType: false,
		// 告诉jQuery不要去设置Content-Type请求头
		processData:false,
		data: file,
		dataType: "json",
		success: function (result) {
			if(result.code == 0){
				// alert(result.message)
				parseFileData(result.data)
			}else{
				alert(result.errMsg)
			}
			
		}
	});
	return false;
}




  //字符串修正
  function escapeHtml(string) {
	     var entityMap = {
	         "&": "&amp;",
	         "<": "&lt;",
	         ">": "&gt;",
	         '"': '&#34;',
	         "'": '&#39;',
	         "\\": '&#92;',
	         "/": '&#x2F;',
			 " ":'&nbsp;'
	     };
	     return String(string).replace(/[&<>\"\'\/\ ]/g, function (s) {
	         return entityMap[s];
	     });
	 }




// function info(path){
// 	$.getJSON(SERVER_PATH + "/readDir1",{url:path},function (data) {
// 		if(data.success){
// 			// alert(data.fsList);
// 			var fsList = data.fsList;
// 					var fshtml = "";
// 					fsList.map(function (item,index) {
// 						SUB_PATH = subPath(item.path)
// 						if(item.isdir){
// 							$(".fsList").attr("path",item.path)


// 							fshtml += '  <tr path='+item.path+'>\n' +
// 							'\t\t\t\t\t            <td><input type="checkbox" value="select"></td>\n' +
// 							'                      <td scope="row" class="fileName"><img src="../../assets/images/avatars/profile-image.png" alt=""><a href="javascript:void(0);" class="isDir">'+item.name+'</a></td>\n' +
// 							'                      <td>'+item.modification_time+'</td>\n' +
// 							'                      <td>'+item.length+'</td>\n' +
// 							'                      <td>'+item.length+'</td> \n' +
// 							'                      <td>\n' +
// 							'                        <a href="javascript:void(0);" class="uploadBtn"><span class="badge bg-info">下载</span></a>\n' +
// 							'                        <a href="javascript:void(0);" class="deleteBtn"><span class="badge bg-danger mx-1">删除</span></a>\n' +
// 							'                        <a href="javascript:void(0);" class="alterBtn"><span class="badge bg-success">修改</span></a>\n' +
// 							'                        <a href="javascript:void(0);" class="shareBtn"><span class="badge bg-secondary mx-1">分享</span></a>\n' +
// 							'                        <a href="javascript:void(0);" class="collectingBtn"><span class="badge bg-dark mx-1">收藏</span></a>\n' +
// 							'\t\t\t\t\t           </td>\t\t\t  \n' +
// 							'            </tr>';
// 						}else{
// 							fshtml += '  <tr path='+item.path+'>\n' +
// 							'\t\t\t\t\t            <td><input type="checkbox" value="select"></td>\n' +
// 							'                      <td scope="row"  class="fileName"><img src="../../assets/images/avatars/profile-image.png" alt="">'+item.name+'</td>\n' +
// 							'                      <td>'+item.modification_time+'</td>\n' +
// 							'                      <td>'+item.length+'</td>\n' +
// 							'                      <td>'+item.length+'</td> \n' +
// 							'                      <td>\n' +
// 							'                        <a href="javascript:void(0);" class="uploadBtn"><span class="badge bg-info">下载</span></a>\n' +
// 							'                        <a href="javascript:void(0);" class="deleteBtn"><span class="badge bg-danger mx-1">删除</span></a>\n' +
// 							'                        <a href="javascript:void(0);" class="alterBtn"><span class="badge bg-success">修改</span></a>\n' +
// 							'                        <a href="javascript:void(0);" class="shareBtn"><span class="badge bg-secondary mx-1">分享</span></a>\n' +
// 							'                        <a href="javascript:void(0);" class="collectingBtn"><span class="badge bg-dark mx-1">收藏</span></a>\n' +
// 							'\t\t\t\t\t           </td>\t\t\t  \n' +
// 							'             </tr>';
// 						}
						
								
// 					});
// 					$(".fsList").html(fshtml)
// 		}
// 	});

// }






