/**
 * 服务端PATH
 */
 var SERVER_PATH = "http://127.0.0.1:8080";
 var storage = window.localStorage;

function getQueryString(name) {
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
	var r = window.location.search.substr(1).match(reg);
	if (r != null) {
		return decodeURIComponent(r[2]);
	}
	return '';
}


/**
 * 点击更换图形验证码
 */
function changeVerifyCode(img) {
	uuid = generateUUID();
	img.src = SERVER_PATH +"/getTextCode?uuid="+uuid;
}



$.ajaxSetup({
	complete : function(XMLHttpRequest, textStatus) {    
	// 通过XMLHttpRequest取得响应头，REDIRECT      
	var redirect = XMLHttpRequest.getResponseHeader("REDIRECT");//若HEADER中含有REDIRECT说明后端想重定向    
	if (redirect == "REDIRECT") {  
		var win = window;      
		while (win != win.top){    
			win = win.top;    
		}  

		win.location.href= XMLHttpRequest.getResponseHeader("CONTEXTPATH");

		}  
	}
});


    //用户退出登录
    function logout() { 
        storage.removeItem("token");
        window.location="login.html";
    }



//发送手机验证码
function sendCode() {
	var phone = $("#fastphone").val()
	var code = $("#code").val();

	$.ajax({
		url : SERVER_PATH + '/sendPhoneCode',
		type:'post',
		data : {
			phone : phone,
		},
		dataType : 'json',
		cache:false,
		success : function(data) {
			if(data.code==0){
				countdownHandler();
				// alert(data.message);
			}else{
				alert(data.errMsg);
			}

		}
	})
}


//短信验证码倒计时
function countdownHandler(){
	var $button = $(".sendVerifyCode");
	var number = 60;
	var countdown = function(){
		if (number == 0) {
			$button.attr("disabled",false);
			$button.html("发送验证码");
			number = 60;
			return;
		} else {
			$button.attr("disabled",true);
			$button.html(number + "秒后重发");
			number--;
		}
		setTimeout(countdown,1000);
	}
	setTimeout(countdown,1000);
}




/**
 * 自定义弹出框
 * 
 * @param {*} message  提示消息
 * @param {*} callback 回调函数，在弹出框关闭时触发。
 */
 function alertBox(message, callback) {
	if (!message) return false;

	var template_alert_box = 
		'<div class="modal" id="alert-box" tabindex="-1" role="dialog">'+
			'<div class="modal-dialog" role="document" style="margin:100px auto;">'+
				'<div class="modal-content">'+
					'<div class="modal-header">'+
						'<h5 class="modal-title">提示</h5>'+
						'<button type="button" class="close" data-dismiss="modal" aria-label="Close">'+
							'<span aria-hidden="true">&times;</span>'+
						'</button>'+
					'</div>'+
					'<div class="modal-body">'+
						'<p id="alert-box-message"></p>'+
					'</div>'+
					'<div class="modal-footer">'+
						'<button type="button" class="btn btn-secondary" data-dismiss="modal">确定</button>'+
					'</div>'+
				'</div>'+
			'</div>'+
		'</div>';

	if ($("#alert-box")) $("#alert-box").remove();

	var $box = $(template_alert_box);
	$box.find("#alert-box-message").text(message);
	$box.modal({backdrop:"static", show:true});
	if (callback) $box.on('hidden.bs.modal', callback);
	$("body").append($box);

	return true;
}



//自定义提示框

 