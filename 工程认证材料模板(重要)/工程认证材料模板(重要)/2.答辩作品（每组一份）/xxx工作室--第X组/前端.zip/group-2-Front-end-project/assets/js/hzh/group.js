// alert("index.js生效！")

$(function(){

	//初始化页面
	readGroupList("/")


	//加载退出群组函数
    exitGroup()

    //加载解散群组函数
    dismissGroup()


    //新建群组
    clickNewGroupBtn();


    //加入群组
    clickJoinGroupBtn();



		
		
	


});
//=======================以下为自定义函数=========================











