
//验证码
var counts = 30;
var sendTag = '0';
var setTimeoutTag = undefined;

function setTime(val) {
　　var mobile = $('#mobile').val();

if (('' == mobile || undefined == mobile) || mobile.length != 11) {
　　alert('请输入正确的手机号码...');
　　return false;
}
if ('0' == sendTag) {
　　// 获取短信验证码
　　getCodeStr(mobile);
}
if (counts == 0) {
　　val.removeAttribute("disabled");
　　val.value = "获取验证码";
　　counts = 30;
　　sendTag = tag;
　　clearTimeout(setTimeoutTag);
} else {
　　sendTag = '1';
　　val.setAttribute("disabled", 'disabled');
　　val.value = "重新发送（" + counts + "）";
　　counts--;
}
setTimeoutTag = setTimeout(function() {
　　setTime(val);
　　}, 1000);
}

// 到后台获取短信验证码
function getCodeStr(mobile) {
　　$.ajax({
　　type : 'post',
　　dataType : 'json',
　　url : url,
　　data : {
　　'paramMap.mobile' : mobile,
},
success : function(data) {
　　if('200' == data.statusCode){
　　alert("验证码发送成功");
　　}else{
　　alert("验证码发送失败" + data.message );
　　}
},
error : function() {
　　alert("发送失败...");
　　}
　});
}


$('#confirm').submit(function() {
	var span1=$("#code_span");
	var span2=$("#npsw_span");
	var span3=$("#cpsw_span");
　　if ($('#code').val() == '') {
　　　　span1.html("请输入验证码")
　　　　return false;
　　}
　　if ($('#newPassword').val() == '') {
　　　　span2.html("请设置新密码")
　　　　return false;
　　}
　　if ($('#confirmPassword').val() != $('#newPassword').val()) {
　　　　span3.html("两次输入不一致，请重新输入")
　　　　return false;
　　}
　　$.ajax({
　　　　type : 'post',
　　　　dataType : 'json',
		url : url,
　　　　data : {
　　　　　　'paramMap.verCode' : $("#paramMap_verCode").val(),
　　　　　　'paramMap.userName' : $("#user_name").val(),
　　　　　　'paramMap.mobile' : $("#mobile").val(),
　　　　　　'paramMap.userPassword' : $("#user_password").val()
　　　　},
　　　　success : function(data) {
　　　　　　if ('200' == data.statusCode) {
　　　　　　　　alert("密码修改成功");
　　　　　　　　window.location.href = "login.html";
　　　　　　} else {
　　　　　　　　alert("操作失败" + data.message);
　　　　　　}
　　　　}
　　});
　　return false;
});