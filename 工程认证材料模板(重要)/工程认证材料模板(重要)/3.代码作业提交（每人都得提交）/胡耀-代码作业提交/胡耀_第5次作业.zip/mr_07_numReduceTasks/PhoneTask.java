package com.mr_07_numReduceTasks;

import lombok.Data;
import org.apache.hadoop.io.Writable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

@Data

public class PhoneTask implements Writable
{
    private String phone;
    private long up;
    private long down;
    private long total;

    public PhoneTask() {}

    public PhoneTask(String phone, long up, long down)
    {
        this.phone = phone;
        this.up = up;
        this.down = down;
        this.total = up + down;
    }

    @Override
    public void write(DataOutput out)
    {
        try {
            out.writeUTF(phone);
            out.writeLong(up);
            out.writeLong(down);
            out.writeLong(total);
        }
        catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void readFields(DataInput in)
    {
        try {
            phone = in.readUTF();
            up = in.readLong();
            down = in.readLong();
            total = in.readLong();
        }
        catch (IOException e) {
            e.printStackTrace();
        }

    }
}
