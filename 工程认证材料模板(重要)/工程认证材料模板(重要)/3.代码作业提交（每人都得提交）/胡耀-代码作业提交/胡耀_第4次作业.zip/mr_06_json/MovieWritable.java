package com.mr_06_json;

import com.google.gson.Gson;
import lombok.Data;
import org.apache.hadoop.io.Writable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

@Data
public class MovieWritable implements Writable, Cloneable
{
    private static Gson gson = new Gson();

    private String movie;
    private float rate;
    private long timeStamp;
    private String uid;

    @Override
    public void write(DataOutput out) throws IOException
    {
        out.writeUTF(movie);
        out.writeFloat(rate);
        out.writeLong(timeStamp);
        out.writeUTF(uid);
    }

    @Override
    public void readFields(DataInput in) throws IOException
    {
        movie = in.readUTF();
        rate = in.readFloat();
        timeStamp = in.readLong();
        uid = in.readUTF();
    }

    @Override
    public String toString()
    {
        return gson.toJson(this);
    }

    @Override
    protected MovieWritable clone()
    {
        MovieWritable movieWritable = gson.fromJson(toString(), MovieWritable.class);

        return movieWritable;
    }
}
