package com.mr_06_json;

import org.apache.commons.io.FileUtils;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.codehaus.jackson.map.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

/**
 * 每个电影的评分的前20个数据(全局topn)
 */
public class MoveTopnWithAll
{
    /**
     * Map端
     * 输入参数(前两个, 固定):
     * LongWritable: 偏移量
     * Text(StringWritable)
     *
     * 输出参数(后两个): (keyOut，valueOut)
     * Text, IntWritable
     */
    public static class MapTask extends Mapper<LongWritable, Text, Text, MovieWritable>
    {
        ObjectMapper mapper = new ObjectMapper();

        @Override
        protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException
        {
            MovieWritable movieWritable = mapper.readValue(value.toString(), MovieWritable.class);

            context.write(new Text(movieWritable.getMovie() + "\t" + movieWritable.getUid()), movieWritable);
        }
    }

    public static class CombinerTask extends Reducer<Text, MovieWritable, Text, MovieWritable>
    {
        @Override
        protected void reduce(Text key, Iterable<MovieWritable> values, Context context) throws IOException, InterruptedException
        {
            String movie = key.toString().split("\t")[0];
            MovieWritable movieWritable = new MovieWritable();
            for (MovieWritable m : values) {
                movieWritable = movieWritable.getRate() > m.getRate() ? movieWritable : m;
            }

            context.write(new Text("1"), movieWritable);
        }
    }

    public static class ReduceTask extends Reducer<Text, MovieWritable, NullWritable, Text>
    {
        final int count = 20;

        @Override
        protected void reduce(Text key, Iterable<MovieWritable> values, Context context) throws IOException, InterruptedException
        {
            List<MovieWritable> movies = new LinkedList<>();

            for (MovieWritable movie : values) {
//                movies.add(movie.clone());

                int index = 0;
                for (; index < movies.size(); index++) {
                    if (movies.get(index).getRate() < movie.getRate()) {
                        break;
                    }
                }

                movies.add(index, movie.clone());

                if (movies.size() > count) {
                    movies.remove(count);
                }
            }

            movies.stream()
//                    .sorted((m1, m2) -> m2.getRate() - m1.getRate() > 0 ? 1 : -1)
//                    .limit(count)
                    .forEach(movie -> {
                        try {
                            context.write(null, new Text(movie.toString()));
                        }
                        catch (Exception e) {
                            e.printStackTrace();
                        }
                    });
        }
    }

    //主函数
    public static void main(String[] args) throws Exception
    {
        String inputStr = "C:\\Users\\86135\\Desktop\\ls\\movie.json";
        String outputStr = "C:\\Users\\86135\\Desktop\\ls\\topn\\movie_all_out";

        //1、在 mapReduce 中有一个专门提交任务的对象 => job
        final Job job = Job.getInstance();
        //声明map端
        job.setMapperClass(MapTask.class);
        //声明reduce端
        job.setReducerClass(ReduceTask.class);
        //声明jar包
        job.setJarByClass(MoveTopnWithAll.class);



        //2、告诉job所有输出类型
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(MovieWritable.class);

        //声明中间件
        job.setCombinerClass(CombinerTask.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(NullWritable.class);

        //3、告诉输入、输入路径
        File file = new File(outputStr);
        if (file.exists()) {
            FileUtils.deleteDirectory(file);
        }
        FileInputFormat.addInputPath(job, new Path(inputStr));
        FileOutputFormat.setOutputPath(job, new Path(outputStr));

        final boolean success = job.waitForCompletion(true);
        System.out.println(success ? "success" : "false");
    }
}
