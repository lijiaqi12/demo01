package com.mr_04_friend;

import org.apache.commons.io.FileUtils;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class Friend
{
    /**
     * Map端
     * 输入参数(前两个, 固定):
     * LongWritable: 偏移量
     * Text(StringWritable)
     *
     * 输出参数(后两个): (keyOut，valueOut)
     * Text, IntWritable
     */
    public static class MapTask extends Mapper<LongWritable, Text, Text, Text>
    {
        /**
         * 自动读取每一行数据
         * 没处理一行数据, map被执行一次
         *
         * @param key     偏移量
         * @param value   数据(每一行数据)
         * @param context 输出对象
         */
        @Override
        protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException
        {
            final String[] split = value.toString().split(":");
            if (split.length >= 2) {
                String pre = split[0];
                String friends = split[1];
                for (String s : friends.split(",")) {
                    context.write(new Text(s), new Text(pre));
                }
            }
        }


    }

    /**
     * reduce端
     *
     * 输入(前两个参数):
     * 同map端的输出
     * 输出
     */
    public static class ReduceTask extends Reducer<Text, Text, Text, Text>
    {
        Map<String, StringBuffer> map = new HashMap<>();

        /**
         * 每个key都执行一次reduce
         *
         * @param key     (hadoop)
         * @param values  (1,1,1,1,1,...)
         * @param context
         * @throws IOException
         * @throws InterruptedException
         */
        @Override
        protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException
        {
            List<String> friends = new LinkedList<>();
            for (Text value : values) {
                friends.add(value.toString());
            }

            Collections.sort(friends);

            for (int i = 0; i < friends.size(); i++) {
                for (int j = i + 1; j < friends.size(); j++) {
                    String k = friends.get(i) + "->" + friends.get(j);
                    StringBuffer value = map.get(k);
                    if (value == null) {
                        value = new StringBuffer();
                    }
                    map.put(k, value.append(key.toString()).append(","));
                }
            }

//            context.write(key, new Text(friends.toString()));
        }


        @Override
        protected void cleanup(Context context) throws IOException, InterruptedException
        {
            for (Map.Entry<String, StringBuffer> entry : map.entrySet()) {
                context.write(new Text(entry.getKey()), new Text(entry.getValue().toString()));
            }
        }
    }

    //主函数
    public static void main(String[] args) throws Exception
    {
        //1、在 mapReduce 中有一个专门提交任务的对象 => job
        final Job job = Job.getInstance();
        //声明map端
        job.setMapperClass(MapTask.class);
        //声明reduce端
        job.setReducerClass(ReduceTask.class);
        //声明jar包
        job.setJarByClass(Friend.class);


        //2、告诉job所有输出类型
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(Text.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        //3、告诉输入、输入路径
        File file = new File("C:\\Users\\86135\\Desktop\\ls\\friend_out");
        if (file.exists()) {
            FileUtils.deleteDirectory(file);
        }
        FileInputFormat.addInputPath(job, new Path("C:\\Users\\86135\\Desktop\\ls\\friend.txt"));
        FileOutputFormat.setOutputPath(job, new Path("C:\\Users\\86135\\Desktop\\ls\\friend_out"));


        final boolean success = job.waitForCompletion(true);
        System.out.println(success ? "success" : "false");
    }
}
