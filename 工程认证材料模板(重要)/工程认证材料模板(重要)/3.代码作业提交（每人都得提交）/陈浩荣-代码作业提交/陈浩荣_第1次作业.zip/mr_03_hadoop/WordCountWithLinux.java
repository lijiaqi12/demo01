package com.mr_03_hadoop;

import com.mr_02_hadoop.WordCount;
import org.apache.commons.httpclient.URI;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class WordCountWithLinux
{
    /**
     * Map端
     * 输入参数(前两个, 固定):
     * LongWritable: 偏移量
     * Text(StringWritable)
     *
     * 输出参数(后两个): (keyOut，valueOut)
     * Text, IntWritable
     */
    public static class MapTask extends Mapper<LongWritable, Text, Text, IntWritable>
    {
        Map<String, Integer> map = new HashMap<>();

        String regex = "[a-zA-Z-]+";

        Pattern pattern = Pattern.compile(regex);
        Matcher matcher;

        /**
         * 自动读取每一行数据
         * 没处理一行数据, map被执行一次
         *
         * @param key     偏移量
         * @param value   数据(每一行数据)
         * @param context 输出对象
         */
        @Override
        protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException
        {
            matcher = pattern.matcher(value.toString());
            //循环获取匹配项
            while (matcher.find()) {
                Text k = new Text(matcher.group());
                IntWritable v = new IntWritable(1);
                context.write(k, v);
            }
        }
    }

    /**
     * reduce端
     *
     * 输入(前两个参数):
     * 同map端的输出
     * 输出
     */
    public static class ReduceTask extends Reducer<Text, IntWritable, Text, IntWritable>
    {
        /**
         * 每个key都执行一次reduce
         *
         * @param key     (hadoop)
         * @param values  (1,1,1,1,1,...)
         * @param context
         * @throws IOException
         * @throws InterruptedException
         */
        @Override
        protected void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException
        {
            int count = 0;
            for (IntWritable value : values) {
                count += value.get();
            }
            IntWritable v = new IntWritable(count);
            context.write(key, v);
            System.out.println("==================");
            System.out.println("key => "+key);
            System.out.println("v => "+v);
        }
    }

    //主函数
    public static void main(String[] args) throws Exception
    {
        //1、配置
        //设置使用的用户
        System.setProperty("HADOOP_USER_NAME", "root");
        //连接hadoop
        final Configuration conf = new Configuration();
        conf.set("fs.defaultFS", "hdfs://hadoop01:9000");


        //2、在 mapReduce 中有一个专门提交任务的对象 => job
        final Job job = Job.getInstance(conf);
        //声明map端
        job.setMapperClass(MapTask.class);
        //声明reduce端
        job.setReducerClass(ReduceTask.class);
        //声明jar包
        job.setJarByClass(WordCountWithLinux.class);


        //3、告诉job所有输出类型
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(IntWritable.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);

        //4、告诉输入、输入路径
        String inputStr = "/rt/1/main/share/wc.txt";
        String outputStr = "/rt/1/main/output/wc";
        FileSystem fileSystem = FileSystem.get(conf);
        Path input = new Path(inputStr);
        Path output = new Path(outputStr);
        //输出文件存在则删除
        if (fileSystem.exists(output)) {
            fileSystem.delete(output, true);
        }
        FileInputFormat.addInputPath(job, input);
        FileOutputFormat.setOutputPath(job, output);


        final boolean success = job.waitForCompletion(true);
        System.out.println(success ? "success" : "false");
    }
}
