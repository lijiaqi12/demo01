package com.mr_05_price;

import org.apache.commons.io.FileUtils;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 统计每个省农产品种类总数，找出排名前3的省份
 */
public class Homework_2_1
{
    /**
     * Map端
     * 输入参数(前两个, 固定):
     * LongWritable: 偏移量
     * Text(StringWritable)
     *
     * 输出参数(后两个): (keyOut，valueOut)
     * Text, IntWritable
     */
    public static class MapTask extends Mapper<LongWritable, Text, Text, BeanWritable>
    {
        /**
         * 自动读取每一行数据
         * 没处理一行数据, map被执行一次
         *
         * @param key     偏移量
         * @param value   数据(每一行数据)
         * @param context 输出对象
         */
        @Override
        protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException
        {
            BeanWritable bean = new BeanWritable(value.toString());
            if (bean.isCreateSuccess()) {
                context.write(new Text(bean.getProvince()), bean);
            }
        }
    }

    /**
     * reduce端
     *
     * 输入(前两个参数):
     * 同map端的输出
     * 输出
     */
    public static class ReduceTask extends Reducer<Text, BeanWritable, Text, IntWritable>
    {
        Map<String, List<String>> map = new HashMap<>();


        /**
         * 每个key都执行一次reduce
         *
         * @param key     (hadoop)
         * @param values  (1,1,1,1,1,...)
         * @param context
         * @throws IOException
         * @throws InterruptedException
         */
        @Override
        protected void reduce(Text key, Iterable<BeanWritable> values, Context context) throws IOException, InterruptedException
        {
            List<String> names = new LinkedList<>();
            for (BeanWritable bean : values) {
                names.add(bean.getName());
            }
            final List<String> result = names
                    .stream()
                    .distinct()
                    .collect(Collectors.toList());
            map.put(key.toString(), result);
        }

        @Override
        protected void cleanup(Context context) throws IOException, InterruptedException
        {
            map.entrySet()
                    .stream()
                    .sorted((m1, m2) -> m2.getValue().size() - m1.getValue().size())
                    .limit(3)
                    .forEach(entry -> {
                        try {
                            context.write(new Text(entry.getKey()), new IntWritable(entry.getValue().size()));
                        }
                        catch (Exception e) {
                            e.printStackTrace();
                        }
                    });
        }
    }

    //主函数
    public static void main(String[] args) throws Exception
    {
        //1、在 mapReduce 中有一个专门提交任务的对象 => job
        final Job job = Job.getInstance();
        //声明map端
        job.setMapperClass(MapTask.class);
        //声明reduce端
        job.setReducerClass(ReduceTask.class);
        //声明jar包
        job.setJarByClass(Homework_2_1.class);


        //2、告诉job所有输出类型
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(BeanWritable.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);

        //3、告诉输入、输入路径
        String inputStr = "C:\\Users\\86135\\Desktop\\ls\\0817今日作业\\farm.TXT";
        String outputStr = "C:\\Users\\86135\\Desktop\\ls\\0817今日作业\\2_1";
        File file = new File(outputStr);
        if (file.exists()) {
            FileUtils.deleteDirectory(file);
        }
        FileInputFormat.addInputPath(job, new Path(inputStr));
        FileOutputFormat.setOutputPath(job, new Path(outputStr));


        final boolean success = job.waitForCompletion(true);
        System.out.println(success ? "success" : "false");
    }
}

