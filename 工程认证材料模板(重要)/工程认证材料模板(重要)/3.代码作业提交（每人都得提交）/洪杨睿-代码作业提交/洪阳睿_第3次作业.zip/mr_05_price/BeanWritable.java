package com.mr_05_price;

import lombok.Data;
import org.apache.hadoop.io.Writable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@Data
public class BeanWritable implements Writable
{
    private String name;
    private float price;
    private long crawlTime;
    private String market;
    private String province;
    private String city;
    private boolean createSuccess;

    public BeanWritable() {}

    public BeanWritable(String data)
    {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        final String[] split = data.split("\t");

        try {
            name = split[0];
            price = Float.parseFloat(split[2]);
            crawlTime = sdf.parse(split[1]).getTime();
            market = split[3];
            province = split[4];
            city = split[5];
            createSuccess = true;
        }
        catch (Exception e) {
            //e.printStackTrace();
            createSuccess = false;
        }
    }


    @Override
    public void write(DataOutput out) throws IOException
    {
        out.writeUTF(name);
        out.writeFloat(price);
        out.writeLong(crawlTime);
        out.writeUTF(market);
        out.writeUTF(province);
        out.writeUTF(city);
    }

    @Override
    public void readFields(DataInput in) throws IOException
    {
        name = in.readUTF();
        price = in.readFloat();
        crawlTime = in.readLong();
        market = in.readUTF();
        province = in.readUTF();
        city = in.readUTF();
    }
}
