package com.mr_05_price;

import org.apache.commons.io.FileUtils;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 统计排名前 3 的省份共同拥有的农产品类型
 */
public class Homework_2_2
{
    public static class MapTask1 extends Mapper<LongWritable, Text, Text, BeanWritable>
    {
        @Override
        protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException
        {
            BeanWritable bean = new BeanWritable(value.toString());
            if (bean.isCreateSuccess()) {
                context.write(new Text(bean.getProvince()), bean);
            }
        }
    }

    public static class ReduceTask1 extends Reducer<Text, BeanWritable, Text, Text>
    {
        Map<String, List<String>> map = new HashMap<>();

        @Override
        protected void reduce(Text key, Iterable<BeanWritable> values, Context context) throws IOException, InterruptedException
        {
            List<String> names = new LinkedList<>();
            for (BeanWritable bean : values) {
                names.add(bean.getName());
            }
            final List<String> result = names
                    .stream()
                    .distinct()
                    .collect(Collectors.toList());
            map.put(key.toString(), result);
            System.out.println(key.toString() + " ==> " + result.size());
        }

        @Override
        protected void cleanup(Context context)
        {
            map.entrySet()
                    .stream()
                    .sorted((m1, m2) -> m2.getValue().size() - m1.getValue().size())
                    .limit(3)
                    .forEach(entry -> {
                        for (String s : entry.getValue()) {
                            try {
                                context.write(new Text(entry.getKey()), new Text(s));
                            }
                            catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
        }
    }

    public static class MapTask2 extends Mapper<LongWritable, Text, Text, Text>
    {
        @Override
        protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException
        {
            final String[] split = value.toString().split("\t");
            String province = split[0];
            String name = split[1];
            context.write(new Text(name), new Text(province));
        }
    }

    public static class ReduceTask2 extends Reducer<Text, Text, Text, Text>
    {
        @Override
        protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException
        {
            List<String> cities = new LinkedList<>();
            for (Text value : values) {
                cities.add(value.toString());
            }
            if (cities.size() == 3) {
                context.write(key, new Text(cities.toString()));
            }
        }
    }

    //主函数
    public static void main(String[] args) throws Exception
    {
        String inputStr1 = "C:\\Users\\86135\\Desktop\\ls\\0817今日作业\\farm.TXT";
        String outputStr1 = "C:\\Users\\86135\\Desktop\\ls\\0817今日作业\\2_2\\1";
        String inputStr2 = outputStr1 + "\\part-r-00000";
        String outputStr2 = "C:\\Users\\86135\\Desktop\\ls\\0817今日作业\\2_2\\2";


        /*******************************************************************/
        //1、在 mapReduce 中有一个专门提交任务的对象 => job
        final Job job1 = Job.getInstance();

        //声明map端
        job1.setMapperClass(MapTask1.class);
        //声明reduce端
        job1.setReducerClass(ReduceTask1.class);
        //声明jar包
        job1.setJarByClass(Homework_2_2.class);


        //2、告诉job所有输出类型
        job1.setMapOutputKeyClass(Text.class);
        job1.setMapOutputValueClass(BeanWritable.class);
        job1.setOutputKeyClass(Text.class);
        job1.setOutputValueClass(IntWritable.class);

        //3、告诉输入、输入路径
        File file1 = new File(outputStr1);
        if (file1.exists()) {
            FileUtils.deleteDirectory(file1);
        }
        FileInputFormat.addInputPath(job1, new Path(inputStr1));
        FileOutputFormat.setOutputPath(job1, new Path(outputStr1));


        final boolean success1 = job1.waitForCompletion(true);
        System.out.println(success1 ? "success" : "false");

        /*******************************************************************/
        final Job job2 = Job.getInstance();

        //声明map端
        job2.setMapperClass(MapTask2.class);
        //声明reduce端
        job2.setReducerClass(ReduceTask2.class);
        //声明jar包
        job2.setJarByClass(Homework_2_2.class);


        //2、告诉job所有输出类型
        job2.setMapOutputKeyClass(Text.class);
        job2.setMapOutputValueClass(Text.class);
        job2.setOutputKeyClass(Text.class);
        job2.setOutputValueClass(Text.class);

        //3、告诉输入、输入路径
        File file2 = new File(outputStr2);
        if (file2.exists()) {
            FileUtils.deleteDirectory(file2);
        }
        FileInputFormat.addInputPath(job2, new Path(inputStr2));
        FileOutputFormat.setOutputPath(job2, new Path(outputStr2));


        final boolean success2 = job2.waitForCompletion(true);
        System.out.println(success2 ? "success" : "false");
    }
}

