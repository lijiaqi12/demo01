package com.mr_05_price;

import org.apache.commons.io.FileUtils;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import java.io.File;
import java.io.IOException;

/**
 * 统计排名前 3 的省份共同拥有的农产品类型
 */
public class Homework_2_2_1
{
    public static class MapTask extends Mapper<LongWritable, Text, Text, IntWritable>
    {
        @Override
        protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException
        {
            BeanWritable bean = new BeanWritable(value.toString());
            if (bean.isCreateSuccess()) {
                context.write(new Text(bean.getName() + "\t" + bean.getProvince()), new IntWritable(1));
            }
        }
    }


    //Combiner
    public static class CombinerTask extends Reducer<Text, IntWritable, Text, IntWritable>
    {
        @Override
        protected void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException
        {
            String name = key.toString().split("\t")[0];
            context.write(new Text(name), new IntWritable(1));
        }
    }

    public static class ReduceTask extends Reducer<Text, IntWritable, Text, NullWritable>
    {
        @Override
        protected void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException
        {
            int count = 0;
            for (IntWritable value : values) {
                count++;
            }

            if (count == 3) {
                context.write(key, null);
            }
        }
    }


    //主函数
    public static void main(String[] args) throws Exception
    {
        String inputStr = "C:\\Users\\86135\\Desktop\\ls\\0817今日作业\\farm.TXT";
        String outputStr = "C:\\Users\\86135\\Desktop\\ls\\0817今日作业\\2_2_1";


        /*******************************************************************/
        //1、在 mapReduce 中有一个专门提交任务的对象 => job
        final Job job = Job.getInstance();

        //声明map端
        job.setMapperClass(MapTask.class);
        //声明reduce端
        job.setReducerClass(ReduceTask.class);
        //声明jar包
        job.setJarByClass(Homework_2_2_1.class);

        job.setCombinerClass(CombinerTask.class);


        //2、告诉job所有输出类型
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(IntWritable.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(NullWritable.class);

        //3、告诉输入、输入路径
        File file = new File(outputStr);
        if (file.exists()) {
            FileUtils.deleteDirectory(file);
        }
        FileInputFormat.addInputPath(job, new Path(inputStr));
        FileOutputFormat.setOutputPath(job, new Path(outputStr));


        final boolean success1 = job.waitForCompletion(true);
        System.out.println(success1 ? "success" : "false");

    }
}

